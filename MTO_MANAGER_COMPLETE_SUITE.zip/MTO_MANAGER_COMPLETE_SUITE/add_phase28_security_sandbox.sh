#!/bin/bash
set -e

echo "[+] Initializing Phase 28 Security Sandbox & Analyzer Generation..."

BASE_DIR="mto-manager/feature/advanced/src/main/java/com/mto/advanced/sandbox"
mkdir -p "$BASE_DIR"

# -----------------------------------------------------------------------------
# FILE 1: Static Vulnerability & Risk Scanner Module
# -----------------------------------------------------------------------------
echo "[1/4] Writing VulnerabilityScanner.kt..."
cat << 'EOF' > "$BASE_DIR/VulnerabilityScanner.kt"
package com.mto.advanced.sandbox

import java.io.File

enum class RiskLevel { HIGH, MEDIUM, LOW, INFO }

data class VulnerabilityIssue(
    val title: String,
    val description: String,
    val riskLevel: RiskLevel,
    val recommendation: String
)

class VulnerabilityScanner {

    fun scanArtifact(targetFile: File): List<VulnerabilityIssue> {
        val issues = mutableListOf<VulnerabilityIssue>()
        if (!targetFile.exists()) return issues

        // Analyze basic flags and configuration properties
        val fileName = targetFile.name.lowercase()
        if (fileName.contains("debug")) {
            issues.add(
                VulnerabilityIssue(
                    title = "Debug Flag Enabled",
                    description = "Application binary contains debug symbols.",
                    riskLevel = RiskLevel.MEDIUM,
                    recommendation = "Disable android:debuggable in production builds."
                )
            )
        }

        issues.add(
            VulnerabilityIssue(
                title = "Implicit Cleartext Traffic Check",
                description = "Verify HTTP cleartext network communication policies.",
                riskLevel = RiskLevel.INFO,
                recommendation = "Enforce Network Security Configuration with cleartextTrafficPermitted=false."
            )
        )

        return issues
    }
}
EOF

# -----------------------------------------------------------------------------
# FILE 2: Hardcoded Secret & Token Extractor Module
# -----------------------------------------------------------------------------
echo "[2/4] Writing HardcodedSecretExtractor.kt..."
cat << 'EOF' > "$BASE_DIR/HardcodedSecretExtractor.kt"
package com.mto.advanced.sandbox

import java.io.File
import java.util.regex.Pattern

data class DetectedSecret(
    val type: String,
    val matchedPattern: String,
    val lineOffset: Int
)

class HardcodedSecretExtractor {

    private val patterns = mapOf(
        "Generic API Key" to Pattern.compile("(?i)(api_key|apikey|secret|token)\\s*=\\s*['\"]([a-zA-Z0-9_\\-]{16,64})['\"]"),
        "Google API Key" to Pattern.compile("AIzaSy[A-Za-z0-9_\\-]{35}")
    )

    fun extractSecrets(targetFile: File): List<DetectedSecret> {
        val results = mutableListOf<DetectedSecret>()
        if (!targetFile.exists() || targetFile.isDirectory) return results

        try {
            val lines = targetFile.readLines()
            lines.forEachIndexed { index, line ->
                patterns.forEach { (type, pattern) ->
                    val matcher = pattern.matcher(line)
                    if (matcher.find()) {
                        results.add(DetectedSecret(type, matcher.group(0) ?: "Matched", index + 1))
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return results
    }
}
EOF

# -----------------------------------------------------------------------------
# FILE 3: Behavioral Intent & API Analyzer Module
# -----------------------------------------------------------------------------
echo "[3/4] Writing BehavioralAnalyzer.kt..."
cat << 'EOF' > "$BASE_DIR/BehavioralAnalyzer.kt"
package com.mto.advanced.sandbox

import java.io.File

data class BehavioralProfile(
    val requestsSMSPermissions: Boolean,
    val requestsLocationPermissions: Boolean,
    val usesCameraHardware: Boolean,
    val overallRiskScore: Int
)

class BehavioralAnalyzer {

    fun analyzeBehavior(manifestOrSource: File): BehavioralProfile {
        if (!manifestOrSource.exists()) return BehavioralProfile(false, false, false, 0)

        val content = try { manifestOrSource.readText() } catch (e: Exception) { "" }

        val hasSms = content.contains("SEND_SMS") || content.contains("RECEIVE_SMS")
        val hasLoc = content.contains("ACCESS_FINE_LOCATION") || content.contains("ACCESS_COARSE_LOCATION")
        val hasCam = content.contains("CAMERA")

        var score = 0
        if (hasSms) score += 40
        if (hasLoc) score += 30
        if (hasCam) score += 20

        return BehavioralProfile(
            requestsSMSPermissions = hasSms,
            requestsLocationPermissions = hasLoc,
            usesCameraHardware = hasCam,
            overallRiskScore = score
        )
    }
}
EOF

# -----------------------------------------------------------------------------
# FILE 4: Phase 28 Master Facade Orchestrator
# -----------------------------------------------------------------------------
echo "[4/4] Writing Phase28SandboxFacade.kt..."
cat << 'EOF' > "$BASE_DIR/Phase28SandboxFacade.kt"
package com.mto.advanced.sandbox

import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class Phase28SandboxFacade private constructor(
    private val workspaceDir: File
) {
    val vulnScanner = VulnerabilityScanner()
    val secretExtractor = HardcodedSecretExtractor()
    val behaviorAnalyzer = BehavioralAnalyzer()

    private val listeners = CopyOnWriteArrayList<SandboxEventListener>()
    private val threadPool = Executors.newFixedThreadPool(4)
    private val activeTasks = ConcurrentHashMap<String, AtomicBoolean>()

    data class SecurityAnalysisReport(
        val taskId: String,
        val vulnerabilities: List<VulnerabilityIssue>,
        val secretsFound: List<DetectedSecret>,
        val behavior: BehavioralProfile,
        val executionTimeMs: Long
    )

    interface SandboxEventListener {
        fun onProgressUpdate(taskId: String, stepMessage: String, percent: Int)
        fun onAnalysisCompleted(report: SecurityAnalysisReport)
    }

    fun addListener(listener: SandboxEventListener) { listeners.add(listener) }
    fun removeListener(listener: SandboxEventListener) { listeners.remove(listener) }

    fun runSecurityAnalysis(taskId: String = UUID.randomUUID().toString(), targetFile: File) {
        val isRunning = AtomicBoolean(true)
        activeTasks[taskId] = isRunning

        threadPool.execute {
            val startTime = System.currentTimeMillis()

            notifyProgress(taskId, "Scanning configuration vulnerabilities...", 25)
            val vulns = vulnScanner.scanArtifact(targetFile)

            notifyProgress(taskId, "Extracting hardcoded parameters & patterns...", 60)
            val secrets = secretExtractor.extractSecrets(targetFile)

            notifyProgress(taskId, "Evaluating permission behavioral profiles...", 90)
            val profile = behaviorAnalyzer.analyzeBehavior(targetFile)

            notifyProgress(taskId, "Analysis Completed Successfully", 100)

            val report = SecurityAnalysisReport(
                taskId = taskId,
                vulnerabilities = vulns,
                secretsFound = secrets,
                behavior = profile,
                executionTimeMs = System.currentTimeMillis() - startTime
            )

            listeners.forEach { it.onAnalysisCompleted(report) }
            activeTasks.remove(taskId)
        }
    }

    private fun notifyProgress(taskId: String, message: String, percent: Int) {
        listeners.forEach { it.onProgressUpdate(taskId, message, percent) }
    }

    fun shutdown() { threadPool.shutdown() }

    companion object {
        @Volatile
        private var instance: Phase28SandboxFacade? = null

        fun getInstance(workspaceDir: File): Phase28SandboxFacade {
            return instance ?: synchronized(this) {
                instance ?: Phase28SandboxFacade(workspaceDir).also { instance = it }
            }
        }
    }
}
EOF

echo "[+] Phase 28 Security Sandbox Engine Built Successfully!"
