#!/bin/bash
set -e

echo "[+] Writing Phase 12 Dynamic Theme & Terminal Customization Engine (Full Production Implementation)..."

mkdir -p mto-manager/feature/advanced/src/main/java/com/mto/advanced/theme

cat << 'EOF' > mto-manager/feature/advanced/src/main/java/com/mto/advanced/theme/ThemeCustomizer.kt
package com.mto.advanced.theme

import java.io.File
import java.io.FileReader
import java.io.FileWriter
import java.util.concurrent.ConcurrentHashMap

class ThemeCustomizer(private val configDir: File) {

    data class ColorScheme(
        val name: String,
        val primaryColorHex: String,
        val backgroundColorHex: String,
        val textColorHex: String,
        val cursorColorHex: String,
        val selectionColorHex: String,
        val isDarkTheme: Boolean
    )

    private val themeRegistry = ConcurrentHashMap<String, ColorScheme>()
    private var activeTheme: ColorScheme

    init {
        if (!configDir.exists()) {
            configDir.mkdirs()
        }
        loadDefaultThemes()
        activeTheme = themeRegistry["matrix"] ?: defaultScheme()
        restoreSavedTheme()
    }

    private fun defaultScheme(): ColorScheme {
        return ColorScheme(
            name = "DefaultDark",
            primaryColorHex = "#00FF00",
            backgroundColorHex = "#000000",
            textColorHex = "#FFFFFF",
            cursorColorHex = "#00FF00",
            selectionColorHex = "#333333",
            isDarkTheme = true
        )
    }

    private fun loadDefaultThemes() {
        themeRegistry["matrix"] = ColorScheme("Matrix", "#00FF00", "#000000", "#00FF00", "#00FF00", "#005500", true)
        themeRegistry["dracula"] = ColorScheme("Dracula", "#BD93F9", "#282A36", "#F8F8F2", "#FF79C6", "#44475A", true)
        themeRegistry["monokai"] = ColorScheme("Monokai", "#F92672", "#272822", "#F8F8F2", "#66D9EF", "#49483E", true)
        themeRegistry["solarized_dark"] = ColorScheme("SolarizedDark", "#268BD2", "#002B36", "#839496", "#2AA198", "#073642", true)
        themeRegistry["cyberpunk"] = ColorScheme("Cyberpunk", "#FF0055", "#080811", "#00F0FF", "#FFE600", "#2A085C", true)
    }

    fun registerCustomTheme(theme: ColorScheme): Boolean {
        themeRegistry[theme.name.lowercase()] = theme
        return saveThemeToFile(theme)
    }

    fun applyTheme(themeName: String): ColorScheme? {
        val theme = themeRegistry[themeName.lowercase()]
        if (theme != null) {
            activeTheme = theme
            saveActiveThemeState(theme.name)
        }
        return theme
    }

    fun getActiveTheme(): ColorScheme = activeTheme

    fun getAllThemes(): List<ColorScheme> = themeRegistry.values.toList().sortedBy { it.name }

    private fun saveActiveThemeState(themeName: String) {
        val stateFile = File(configDir, "active_theme.txt")
        try {
            FileWriter(stateFile).use { writer ->
                writer.write(themeName)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun restoreSavedTheme() {
        val stateFile = File(configDir, "active_theme.txt")
        if (stateFile.exists()) {
            try {
                val savedName = FileReader(stateFile).use { it.readText().trim() }
                themeRegistry[savedName.lowercase()]?.let {
                    activeTheme = it
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun saveThemeToFile(theme: ColorScheme): Boolean {
        val file = File(configDir, "theme_${theme.name.lowercase()}.json")
        return try {
            FileWriter(file).use { writer ->
                val json = """
                    {
                      "name": "${theme.name}",
                      "primary": "${theme.primaryColorHex}",
                      "background": "${theme.backgroundColorHex}",
                      "text": "${theme.textColorHex}",
                      "cursor": "${theme.cursorColorHex}",
                      "selection": "${theme.selectionColorHex}",
                      "isDark": ${theme.isDarkTheme}
                    }
                """.trimIndent()
                writer.write(json)
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}
EOF

cat << 'EOF' > mto-manager/feature/advanced/src/main/java/com/mto/advanced/theme/TerminalFontEngine.kt
package com.mto.advanced.theme

import java.io.File
import java.util.concurrent.ConcurrentHashMap

class TerminalFontEngine(private val fontStorageDir: File) {

    data class FontDescriptor(
        val fontName: String,
        val fontPath: String,
        val isMonospaced: Boolean,
        val fileSizeByte: Long
    )

    private val availableFonts = ConcurrentHashMap<String, FontDescriptor>()
    private var currentFontSizeSp: Float = 14.0f

    init {
        if (!fontStorageDir.exists()) {
            fontStorageDir.mkdirs()
        }
        scanFontDirectory()
    }

    fun scanFontDirectory() {
        availableFonts.clear()
        val files = fontStorageDir.listFiles() ?: arrayOf()
        for (file in files) {
            if (file.isFile && (file.name.endsWith(".ttf") || file.name.endsWith(".otf"))) {
                val fontName = file.nameWithoutExtension
                availableFonts[fontName] = FontDescriptor(
                    fontName = fontName,
                    fontPath = file.absolutePath,
                    isMonospaced = true,
                    fileSizeByte = file.length()
                )
            }
        }
    }

    fun getFontList(): List<FontDescriptor> = availableFonts.values.toList().sortedBy { it.fontName }

    fun setFontSize(sizeSp: Float): Float {
        currentFontSizeSp = sizeSp.coerceIn(8.0f, 32.0f)
        return currentFontSizeSp
    }

    fun getFontSize(): Float = currentFontSizeSp

    fun loadFontDescriptor(fontName: String): FontDescriptor? {
        return availableFonts[fontName]
    }
}
EOF

cat << 'EOF' > mto-manager/feature/advanced/src/main/java/com/mto/advanced/theme/ShellPromptFormatter.kt
package com.mto.advanced.theme

class ShellPromptFormatter {

    enum class PromptStyle {
        MINIMAL,
        POWERLINE,
        GIT_AWARE,
        VERBOSE
    }

    fun generatePs1Prompt(
        username: String,
        hostname: String,
        currentPath: String,
        gitBranch: String? = null,
        style: PromptStyle = PromptStyle.POWERLINE
    ): String {
        val sanitizedPath = currentPath.replace(System.getProperty("user.home") ?: "", "~")

        return when (style) {
            PromptStyle.MINIMAL -> "\\[\\e[1;32m\\]$sanitizedPath\\[\\e[0m\\] \\$ "
            PromptStyle.POWERLINE -> {
                val branchPart = if (!gitBranch.isNullOrEmpty()) " \uE0A0 $gitBranch" else ""
                "\\[\\e[1;34m\\]$username@$hostname\\[\\e[0m\\]:\\[\\e[1;33m\\]$sanitizedPath\\[\\e[1;35m\\]$branchPart\\[\\e[0m\\]\\$ "
            }
            PromptStyle.GIT_AWARE -> {
                val gitInfo = if (!gitBranch.isNullOrEmpty()) " (git: $gitBranch)" else ""
                "\\[\\e[32m\\]$username\\[\\e[0m\\] in \\[\\e[36m\\]$sanitizedPath\\[\\e[33m\\]$gitInfo\\[\\e[0m\\]\n\u276F "
            }
            PromptStyle.VERBOSE -> {
                "\\[\\e[1;31m\\][MTO-SH]\\[\\e[0m\\] \\[\\e[1;32m\\]$username@$hostname\\[\\e[0m\\]:\\[\\e[1;34m\\]$sanitizedPath\\[\\e[0m\\]\\$ "
            }
        }
    }

    fun formatAnsiColor(text: String, colorCode: Int): String {
        return "\u001B[${colorCode}m$text\u001B[0m"
    }
}
EOF

cat << 'EOF' > mto-manager/feature/advanced/src/main/java/com/mto/advanced/theme/TerminalUiConfiguration.kt
package com.mto.advanced.theme

class TerminalUiConfiguration {

    data class UiSettings(
        val cursorBlinkRateMs: Long = 500L,
        val backgroundOpacity: Float = 0.95f,
        val scrollbackHistoryLines: Int = 5000,
        val enableVibrationFeedback: Boolean = true,
        val keepScreenOn: Boolean = true
    )

    private var currentSettings = UiSettings()

    fun updateSettings(newSettings: UiSettings) {
        currentSettings = newSettings
    }

    fun getSettings(): UiSettings = currentSettings
}
EOF

echo "[+] Phase 12 Full Dynamic Theme & Customization Engine Successfully Written!"
