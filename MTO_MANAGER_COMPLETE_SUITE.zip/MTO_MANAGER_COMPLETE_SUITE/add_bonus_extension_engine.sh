#!/bin/bash
set -e

echo "[+] Initializing M.T.O MANAGER Bonus Optimization & Plugin Host Extension..."

BASE_DIR="mto-manager/feature/advanced/src/main/java/com/mto/advanced/extension"
mkdir -p "$BASE_DIR"

# -----------------------------------------------------------------------------
# FILE 1: Performance & Cache Cleaner Engine
# -----------------------------------------------------------------------------
echo "[1/2] Writing PerformanceOptimizerEngine.kt..."
cat << 'EOF' > "$BASE_DIR/PerformanceOptimizerEngine.kt"
package com.mto.advanced.extension

import java.io.File

class PerformanceOptimizerEngine {

    fun optimizeWorkspaceMemory(workspaceDir: File): Long {
        var reclaimedBytes = 0L
        if (!workspaceDir.exists()) return reclaimedBytes

        val tempFiles = workspaceDir.walkTopDown().filter { file ->
            file.name.startsWith("temp_") || file.name.endsWith(".tmp") || file.name.endsWith(".bak")
        }

        tempFiles.forEach { file ->
            val size = file.length()
            if (file.delete()) {
                reclaimedBytes += size
            }
        }

        System.gc() // Trigger System Garbage Collector
        return reclaimedBytes
    }
}
EOF

# -----------------------------------------------------------------------------
# FILE 2: Dynamic Plugin Manager Framework
# -----------------------------------------------------------------------------
echo "[2/2] Writing DynamicPluginManager.kt..."
cat << 'EOF' > "$BASE_DIR/DynamicPluginManager.kt"
package com.mto.advanced.extension

import java.io.File
import java.util.concurrent.ConcurrentHashMap

interface MtoPlugin {
    val pluginId: String
    val version: String
    fun onInitialize(workspaceDir: File)
    fun onExecute(args: List<String>): String
}

class DynamicPluginManager(private val workspaceDir: File) {

    private val activePlugins = ConcurrentHashMap<String, MtoPlugin>()

    fun registerPlugin(plugin: MtoPlugin) {
        plugin.onInitialize(workspaceDir)
        activePlugins[plugin.pluginId] = plugin
    }

    fun executePluginCommand(pluginId: String, args: List<String>): String? {
        val plugin = activePlugins[pluginId] ?: return null
        return plugin.onExecute(args)
    }

    fun getRegisteredPlugins(): List<String> {
        return activePlugins.keys.toList()
    }
}
EOF

echo "[+] Bonus Optimization & Plugin Host Engine Built Successfully!"
