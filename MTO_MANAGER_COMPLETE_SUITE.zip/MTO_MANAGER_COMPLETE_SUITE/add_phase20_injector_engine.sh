#!/bin/bash
set -e

echo "[+] Generating Phase 20: File Injector & Universal File Exchanger Engine..."

mkdir -p mto-manager/feature/advanced/src/main/java/com/mto/advanced/injector

cat << 'EOF' > mto-manager/feature/advanced/src/main/java/com/mto/advanced/injector/Phase20InjectorEngine.kt
package com.mto.advanced.injector

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.channels.FileChannel
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * M.T.O MANAGER - PHASE 20 INJECTOR & EXCHANGER ENGINE
 * Implements Direct ZIP/APK File Injection, Native Asset Exchange,
 * and Universal Safe Storage File Swapping Architecture.
 */
class Phase20InjectorEngine private constructor(
    private val workingDirectory: File
) {

    data class InjectRequest(
        val taskId: String,
        val targetZipOrApk: File,
        val sourceFileToInject: File,
        val relativeZipPath: String,
        val overwriteExisting: Boolean = true
    )

    data class ExchangePayload(
        val taskId: String,
        val primaryFile: File,
        val secondaryFile: File,
        val createAtomicBackup: Boolean = true
    )

    data class InjectorProgressReport(
        val taskId: String,
        val bytesProcessed: Long,
        val totalBytes: Long,
        val currentEntryName: String,
        val percent: Int
    )

    data class InjectionResult(
        val isSuccess: Boolean,
        val outputArtifact: File?,
        val logs: List<String>,
        val executionTimeMs: Long,
        val errorMessage: String? = null
    )

    interface InjectorEventListener {
        fun onProgressUpdate(report: InjectorProgressReport)
        fun onOperationCompleted(taskId: String, result: InjectionResult)
    }

    private val listeners = CopyOnWriteArrayList<InjectorEventListener>()
    private val threadPool = Executors.newFixedThreadPool(4)
    private val activeTasks = ConcurrentHashMap<String, AtomicBoolean>()

    init {
        if (!workingDirectory.exists()) {
            workingDirectory.mkdirs()
        }
    }

    fun addListener(listener: InjectorEventListener) {
        listeners.add(listener)
    }

    fun removeListener(listener: InjectorEventListener) {
        listeners.remove(listener)
    }

    // =========================================================================
    // FEATURE 1 & 5: DYNAMIC ZIP/APK FILE INJECTOR & ASSET EXCHANGER
    // =========================================================================

    fun injectFileIntoContainer(request: InjectRequest) {
        val isRunning = AtomicBoolean(true)
        activeTasks[request.taskId] = isRunning

        threadPool.execute {
            val logs = mutableListOf<String>()
            val startTime = System.currentTimeMillis()

            if (!request.targetZipOrApk.exists() || !request.sourceFileToInject.exists()) {
                notifyCompletion(
                    request.taskId,
                    InjectionResult(false, null, logs, 0, "Target container or source file missing.")
                )
                return@execute
            }

            logs.add("Initiating File Injection for target: ${request.targetZipOrApk.name}")
            logs.add("Source payload to inject: ${request.sourceFileToInject.name} -> Target path: ${request.relativeZipPath}")

            val tempOutput = File(workingDirectory, "temp_inject_${System.currentTimeMillis()}.apk")

            try {
                var isReplaced = false
                val totalBytes = request.targetZipOrApk.length() + request.sourceFileToInject.length()
                var processedBytes = 0L

                ZipInputStream(BufferedInputStream(FileInputStream(request.targetZipOrApk))).use { zipIn ->
                    ZipOutputStream(BufferedOutputStream(FileOutputStream(tempOutput))).use { zipOut ->
                        var entry = zipIn.nextEntry
                        val buffer = ByteArray(65536)

                        while (entry != null && isRunning.get()) {
                            val entryName = entry.name

                            if (entryName == request.relativeZipPath) {
                                if (request.overwriteExisting) {
                                    logs.add("Overwriting existing archive entry: $entryName")
                                    val newZipEntry = ZipEntry(request.relativeZipPath)
                                    zipOut.putNextEntry(newZipEntry)
                                    FileInputStream(request.sourceFileToInject).use { srcIn ->
                                        var len: Int
                                        while (srcIn.read(buffer).also { len = it } != -1) {
                                            zipOut.write(buffer, 0, len)
                                            processedBytes += len
                                        }
                                    }
                                    zipOut.closeEntry()
                                    isReplaced = true
                                } else {
                                    logs.add("Skipping injection as entry already exists and overwrite set to false.")
                                    zipOut.putNextEntry(ZipEntry(entryName))
                                    zipIn.copyTo(zipOut)
                                    zipOut.closeEntry()
                                }
                            } else {
                                val newEntry = ZipEntry(entryName)
                                zipOut.putNextEntry(newEntry)
                                var len: Int
                                while (zipIn.read(buffer).also { len = it } != -1) {
                                    zipOut.write(buffer, 0, len)
                                    processedBytes += len
                                }
                                zipOut.closeEntry()
                            }

                            val progress = if (totalBytes > 0) ((processedBytes * 100) / totalBytes).toInt() else 0
                            notifyProgress(InjectorProgressReport(request.taskId, processedBytes, totalBytes, entryName, progress))

                            zipIn.closeEntry()
                            entry = zipIn.nextEntry
                        }

                        // If file was not in container, append it as a new entry
                        if (!isReplaced && isRunning.get()) {
                            logs.add("Appending new payload entry to container: ${request.relativeZipPath}")
                            zipOut.putNextEntry(ZipEntry(request.relativeZipPath))
                            FileInputStream(request.sourceFileToInject).use { srcIn ->
                                var len: Int
                                while (srcIn.read(buffer).also { len = it } != -1) {
                                    zipOut.write(buffer, 0, len)
                                }
                            }
                            zipOut.closeEntry()
                        }
                    }
                }

                if (isRunning.get()) {
                    if (request.targetZipOrApk.delete()) {
                        tempOutput.renameTo(request.targetZipOrApk)
                        logs.add("Injection completed and container safely updated!")
                        notifyCompletion(
                            request.taskId,
                            InjectionResult(true, request.targetZipOrApk, logs, System.currentTimeMillis() - startTime)
                        )
                    } else {
                        notifyCompletion(
                            request.taskId,
                            InjectionResult(false, null, logs, System.currentTimeMillis() - startTime, "Failed to update target container.")
                        )
                    }
                }

            } catch (e: Exception) {
                logs.add("Error during injection: ${e.localizedMessage}")
                notifyCompletion(
                    request.taskId,
                    InjectionResult(false, null, logs, System.currentTimeMillis() - startTime, e.localizedMessage)
                )
            } finally {
                if (tempOutput.exists()) tempOutput.delete()
                activeTasks.remove(request.taskId)
            }
        }
    }

    // =========================================================================
    // FEATURE 6: UNIVERSAL SYSTEM & STORAGE FILE EXCHANGER (SWAP ENGINE)
    // =========================================================================

    fun exchangeUniversalFiles(payload: ExchangePayload) {
        val isRunning = AtomicBoolean(true)
        activeTasks[payload.taskId] = isRunning

        threadPool.execute {
            val logs = mutableListOf<String>()
            val startTime = System.currentTimeMillis()

            if (!payload.primaryFile.exists() || !payload.secondaryFile.exists()) {
                notifyCompletion(
                    payload.taskId,
                    InjectionResult(false, null, logs, 0, "One or both swap files do not exist.")
                )
                return@execute
            }

            val backupPrimary = File(workingDirectory, "bak_primary_${System.currentTimeMillis()}.tmp")
            val backupSecondary = File(workingDirectory, "bak_secondary_${System.currentTimeMillis()}.tmp")

            try {
                logs.add("Executing Universal Atomic Swap between: ${payload.primaryFile.name} <-> ${payload.secondaryFile.name}")

                if (payload.createAtomicBackup) {
                    copyFileChannel(payload.primaryFile, backupPrimary)
                    copyFileChannel(payload.secondaryFile, backupSecondary)
                }

                val tempSwapFile = File(workingDirectory, "swap_temp_${System.currentTimeMillis()}.tmp")
                
                copyFileChannel(payload.primaryFile, tempSwapFile)
                copyFileChannel(payload.secondaryFile, payload.primaryFile)
                copyFileChannel(tempSwapFile, payload.secondaryFile)

                tempSwapFile.delete()
                if (payload.createAtomicBackup) {
                    backupPrimary.delete()
                    backupSecondary.delete()
                }

                logs.add("Universal File Swap completed successfully!")
                notifyCompletion(
                    payload.taskId,
                    InjectionResult(true, payload.primaryFile, logs, System.currentTimeMillis() - startTime)
                )

            } catch (e: Exception) {
                logs.add("Exchange error: ${e.localizedMessage}")
                // Rollback if backup exists
                if (backupPrimary.exists() && backupSecondary.exists()) {
                    copyFileChannel(backupPrimary, payload.primaryFile)
                    copyFileChannel(backupSecondary, payload.secondaryFile)
                    backupPrimary.delete()
                    backupSecondary.delete()
                    logs.add("Rollback applied successfully!")
                }
                notifyCompletion(
                    payload.taskId,
                    InjectionResult(false, null, logs, System.currentTimeMillis() - startTime, e.localizedMessage)
                )
            } finally {
                activeTasks.remove(payload.taskId)
            }
        }
    }

    private fun copyFileChannel(source: File, dest: File) {
        FileInputStream(source).channel.use { srcChannel ->
            FileOutputStream(dest).channel.use { destChannel ->
                srcChannel.transferTo(0, srcChannel.size(), destChannel)
            }
        }
    }

    private fun notifyProgress(report: InjectorProgressReport) {
        listeners.forEach { it.onProgressUpdate(report) }
    }

    private fun notifyCompletion(taskId: String, result: InjectionResult) {
        listeners.forEach { it.onOperationCompleted(taskId, result) }
    }

    fun cancelTask(taskId: String): Boolean {
        val task = activeTasks.remove(taskId)
        task?.set(false)
        return task != null
    }

    fun shutdown() {
        threadPool.shutdown()
    }

    companion object {
        @Volatile
        private var instance: Phase20InjectorEngine? = null

        fun getInstance(workingDir: File): Phase20InjectorEngine {
            return instance ?: synchronized(this) {
                instance ?: Phase20InjectorEngine(workingDir).also { instance = it }
            }
        }
    }
}
EOF

echo "[+] Phase 20 File Injector & Exchanger Engine Written Successfully!"
