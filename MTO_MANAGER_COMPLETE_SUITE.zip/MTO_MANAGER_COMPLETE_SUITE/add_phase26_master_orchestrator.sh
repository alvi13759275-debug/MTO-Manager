#!/bin/bash
set -e

echo "[+] Initializing Phase 26 Enterprise Core Generation (Multi-File Production Architecture)..."

BASE_DIR="mto-manager/feature/advanced/src/main/java/com/mto/advanced/entry"
mkdir -p "$BASE_DIR"

# -----------------------------------------------------------------------------
# FILE 1: Console Logger & Dynamic Formatter Engine
# -----------------------------------------------------------------------------
echo "[1/4] Writing ConsoleLoggerEngine.kt..."
cat << 'EOF' > "$BASE_DIR/ConsoleLoggerEngine.kt"
package com.mto.advanced.entry

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class LogLevel { INFO, WARN, ERROR, DEBUG, TRACE }

object ConsoleLoggerEngine {
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)
    var isDebugEnabled: Boolean = true

    fun log(level: LogLevel, tag: String, message: String, throwable: Throwable? = null) {
        val timestamp = dateFormat.format(Date())
        val colorCode = when (level) {
            LogLevel.INFO -> "\u001B[32m"  // Green
            LogLevel.WARN -> "\u001B[33m"  // Yellow
            LogLevel.ERROR -> "\u001B[31m" // Red
            LogLevel.DEBUG -> "\u001B[36m" // Cyan
            LogLevel.TRACE -> "\u001B[35m" // Purple
        }
        val resetCode = "\u001B[0m"
        println("$colorCode[$timestamp] [${level.name}] [$tag] $message$resetCode")
        throwable?.printStackTrace()
    }

    fun info(tag: String, message: String) = log(LogLevel.INFO, tag, message)
    fun warn(tag: String, message: String) = log(LogLevel.WARN, tag, message)
    fun error(tag: String, message: String, t: Throwable? = null) = log(LogLevel.ERROR, tag, message, t)
    fun debug(tag: String, message: String) { if (isDebugEnabled) log(LogLevel.DEBUG, tag, message) }

    fun printBanner() {
        println("""
        ================================================================
        *   M.T.O MANAGER - PHASE 26 ENTERPRISE CLI ORCHESTRATOR       *
        *   Full Modular Infrastructure & System Health Controller     *
        ================================================================
        """.trimIndent())
    }
}
EOF

# -----------------------------------------------------------------------------
# FILE 2: System Health & Diagnostic Analytics Module
# -----------------------------------------------------------------------------
echo "[2/4] Writing SystemDiagnosticsCollector.kt..."
cat << 'EOF' > "$BASE_DIR/SystemDiagnosticsCollector.kt"
package com.mto.advanced.entry

import com.mto.advanced.integration.Phase25MasterSuiteEngine
import java.io.File

class SystemDiagnosticsCollector(private val masterEngine: Phase25MasterSuiteEngine) {

    data class DiagnosticSnapshot(
        val timestamp: Long,
        val workspacePath: String,
        val activePhases: Int,
        val freeMemoryMb: Long,
        val maxMemoryMb: Long,
        val totalMemoryMb: Long,
        val availableCores: Int,
        val moduleStates: Map<String, String>
    )

    fun captureSnapshot(): DiagnosticSnapshot {
        val runtime = Runtime.getRuntime()
        val report = masterEngine.getDiagnosticsReport()

        val map = mutableMapOf<String, String>()
        report.registeredModules.forEach { (k, v) -> map[k] = v.name }

        return DiagnosticSnapshot(
            timestamp = System.currentTimeMillis(),
            workspacePath = report.workspacePath,
            activePhases = report.activePhaseCount,
            freeMemoryMb = runtime.freeMemory() / (1024 * 1024),
            maxMemoryMb = runtime.maxMemory() / (1024 * 1024),
            totalMemoryMb = runtime.totalMemory() / (1024 * 1024),
            availableCores = runtime.availableProcessors(),
            moduleStates = map
        )
    }

    fun renderFormattedReport() {
        val snapshot = captureSnapshot()
        ConsoleLoggerEngine.info("Diagnostics", "=== M.T.O SYSTEM DIAGNOSTIC REPORT ===")
        println(" Workspace Path   : ${snapshot.workspacePath}")
        println(" Available Cores  : ${snapshot.availableCores}")
        println(" Memory Status    : Free ${snapshot.freeMemoryMb} MB / Total ${snapshot.totalMemoryMb} MB (Max${snapshot.maxMemoryMb} MB)")
        println(" Active Sub-Phases: ${snapshot.activePhases}")
        println(" Module Statuses  :")
        snapshot.moduleStates.forEach { (mod, state) ->
            println("   - $mod ->$state")
        }
        println("==================================================")
    }
}
EOF

# -----------------------------------------------------------------------------
# FILE 3: CLI Command Registry & Action Dispatcher
# -----------------------------------------------------------------------------
echo "[3/4] Writing CliCommandRegistry.kt..."
cat << 'EOF' > "$BASE_DIR/CliCommandRegistry.kt"
package com.mto.advanced.entry

import com.mto.advanced.integration.Phase25MasterSuiteEngine
import com.mto.advanced.system.Phase22SystemEngine
import java.util.concurrent.ConcurrentHashMap

data class CommandSpec(
    val name: String,
    val aliases: List<String>,
    val description: String,
    val handler: (args: List<String>) -> Unit
)

class CliCommandRegistry(
    private val masterEngine: Phase25MasterSuiteEngine,
    private val diagnostics: SystemDiagnosticsCollector
) {
    private val registry = ConcurrentHashMap<String, CommandSpec>()

    init {
        registerBuiltInCommands()
    }

    fun register(command: CommandSpec) {
        registry[command.name.lowercase()] = command
        command.aliases.forEach { alias -> registry[alias.lowercase()] = command }
    }

    fun dispatch(rawInput: String) {
        val parts = rawInput.trim().split("\\s+".toRegex())
        if (parts.isEmpty() || parts[0].isEmpty()) return

        val cmdName = parts[0].lowercase()
        val args = if (parts.size > 1) parts.subList(1, parts.size) else emptyList()

        val spec = registry[cmdName]
        if (spec != null) {
            try {
                spec.handler(args)
            } catch (e: Exception) {
                ConsoleLoggerEngine.error("CliRegistry", "Failed to execute command '$cmdName'", e)
            }
        } else {
            ConsoleLoggerEngine.warn("CliRegistry", "Unknown command '$cmdName'. Type 'help' for available commands.")
        }
    }

    private fun registerBuiltInCommands() {
        register(CommandSpec(
            name = "status",
            aliases = listOf("diag", "health"),
            description = "Displays live system diagnostics and memory statistics."
        ) {
            diagnostics.renderFormattedReport()
        })

        register(CommandSpec(
            name = "root",
            aliases = listOf("su", "check-root"),
            description = "Verifies Root Superuser shell access."
        ) {
            val sysEngine = Phase22SystemEngine.getInstance()
            val hasRoot = sysEngine.checkRootAccess()
            ConsoleLoggerEngine.info("RootCheck", "Root Superuser Access Granted: $hasRoot")
        })

        register(CommandSpec(
            name = "help",
            aliases = listOf("?", "h"),
            description = "Displays the command reference list."
        ) {
            println("\n--- COMMAND REFERENCE LIST ---")
            registry.values.distinctBy { it.name }.forEach { spec ->
                println("${spec.name.padEnd(12)} :${spec.description}")
                println("  Aliases    : ${spec.aliases.joinToString(", ")}")
            }
            println("-------------------------------\n")
        })
    }
}
EOF

# -----------------------------------------------------------------------------
# FILE 4: Application Main Entry Point & Orchestrator Runner
# -----------------------------------------------------------------------------
echo "[4/4] Writing Phase26MainAppEntry.kt..."
cat << 'EOF' > "$BASE_DIR/Phase26MainAppEntry.kt"
package com.mto.advanced.entry

import com.mto.advanced.integration.Phase25MasterSuiteEngine
import java.io.File
import java.util.Scanner
import java.util.concurrent.atomic.AtomicBoolean

class Phase26MainAppEntry {

    private val workspace = File(System.getProperty("user.home"), "mto_workspace")
    private lateinit var masterEngine: Phase25MasterSuiteEngine
    private lateinit var diagnostics: SystemDiagnosticsCollector
    private lateinit var commandRegistry: CliCommandRegistry
    private val isRunning = AtomicBoolean(true)

    fun start(args: Array<String>) {
        ConsoleLoggerEngine.printBanner()
        ConsoleLoggerEngine.info("AppEntry", "Initializing Master Engine in Workspace: ${workspace.absolutePath}")

        masterEngine = Phase25MasterSuiteEngine.getInstance(workspace)
        diagnostics = SystemDiagnosticsCollector(masterEngine)
        commandRegistry = CliCommandRegistry(masterEngine, diagnostics)

        attachSystemListeners()

        if (args.isNotEmpty()) {
            ConsoleLoggerEngine.info("AppEntry", "Non-Interactive Mode Activated.")
            commandRegistry.dispatch(args.joinToString(" "))
            masterEngine.shutdownMasterSuite()
        } else {
            ConsoleLoggerEngine.info("AppEntry", "Interactive Terminal Shell Shell Ready.")
            enterInteractiveShell()
        }
    }

    private fun attachSystemListeners() {
        masterEngine.addListener(object : Phase25MasterSuiteEngine.MasterSuiteEventListener {
            override fun onModuleStateChanged(moduleName: String, newState: Phase25MasterSuiteEngine.CoreModuleState) {
                ConsoleLoggerEngine.debug("ModuleState", "$moduleName ->$newState")
            }

            override fun onOrchestrationProgress(taskId: String, stepMessage: String, percent: Int) {
                ConsoleLoggerEngine.info("Orchestrator", "[$taskId] ($percent\%)$stepMessage")
            }

            override fun onOrchestrationCompleted(result: Phase25MasterSuiteEngine.MasterExecutionResult) {
                ConsoleLoggerEngine.info("Orchestrator", "Task ${result.taskId} execution completed with success=${result.isSuccess}")
            }
        })
    }

    private fun enterInteractiveShell() {
        val scanner = Scanner(System.`in`)
        println("\nType 'help' to inspect commands, or 'exit' to terminate.\n")

        while (isRunning.get()) {
            print("MTO-MANAGER-PHASE26> ")
            if (!scanner.hasNextLine()) break
            val line = scanner.nextLine().trim()

            if (line.equalsIgnoreCase("exit") || line.equalsIgnoreCase("quit")) {
                ConsoleLoggerEngine.info("AppEntry", "Shutting down M.T.O MANAGER Engine Pipeline...")
                masterEngine.shutdownMasterSuite()
                isRunning.set(false)
                break
            }

            if (line.isNotEmpty()) {
                commandRegistry.dispatch(line)
            }
        }
    }

    private fun String.equalsIgnoreCase(other: String) = this.equals(other, ignoreCase = true)
}

fun main(args: Array<String>) {
    val entry = Phase26MainAppEntry()
    entry.start(args)
}
EOF

echo "[+] Phase 26 Enterprise Generation Fully Completed with Zero Syntax Conflicts!"
