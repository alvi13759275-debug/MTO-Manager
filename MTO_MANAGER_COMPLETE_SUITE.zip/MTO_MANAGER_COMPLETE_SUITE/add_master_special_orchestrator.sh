#!/bin/bash
set -e

echo "[+] Initializing M.T.O MANAGER Master CLI Dashboard Suite..."

BASE_DIR="mto-manager/feature/advanced/src/main/java/com/mto/advanced/dashboard"
mkdir -p "$BASE_DIR"

# -----------------------------------------------------------------------------
# FILE 1: Terminal Color & Theme Engine
# -----------------------------------------------------------------------------
echo "[1/2] Writing TerminalThemeEngine.kt..."
cat << 'EOF' > "$BASE_DIR/TerminalThemeEngine.kt"
package com.mto.advanced.dashboard

enum class TerminalTheme(val nameTitle: String, val primaryColor: String, val accentColor: String, val reset: String) {
    CYBERPUNK("Cyberpunk Green", "\u001B[32m", "\u001B[36m", "\u001B[0m"),
    MATRIX("Matrix Red/Green", "\u001B[31m", "\u001B[32m", "\u001B[0m"),
    NEON_BLUE("Neon Blue", "\u001B[34m", "\u001B[35m", "\u001B[0m"),
    CLASSIC_MONO("Classic Mono", "\u001B[37m", "\u001B[33m", "\u001B[0m")
}

class TerminalThemeEngine {
    var activeTheme: TerminalTheme = TerminalTheme.CYBERPUNK

    fun colorize(text: String, useAccent: Boolean = false): String {
        val color = if (useAccent) activeTheme.accentColor else activeTheme.primaryColor
        return "$color$text${activeTheme.reset}"
    }
}
EOF

# -----------------------------------------------------------------------------
# FILE 2: Interactive Terminal Orchestration Suite
# -----------------------------------------------------------------------------
echo "[2/2] Writing MasterCliDashboard.kt..."
cat << 'EOF' > "$BASE_DIR/MasterCliDashboard.kt"
package com.mto.advanced.dashboard

import com.mto.advanced.release.Phase30ReleaseFacade
import com.mto.advanced.storage.Phase29StorageFacade
import com.mto.advanced.extension.PerformanceOptimizerEngine
import com.mto.advanced.extension.DynamicPluginManager
import java.io.File
import java.lang.management.ManagementFactory

class MasterCliDashboard(private val workspaceDir: File) {

    private val themeEngine = TerminalThemeEngine()
    private val storageFacade = Phase29StorageFacade.getInstance(workspaceDir)
    private val releaseFacade = Phase30ReleaseFacade.getInstance(workspaceDir)
    private val optimizerEngine = PerformanceOptimizerEngine()
    private val pluginManager = DynamicPluginManager(workspaceDir)

    fun renderHeaderBanner() {
        val banner = """
            ====================================================================
               __  __   _____   ____    __  __                          _____  
              |  \/  | |_   _| / __ \  |  \/  |                        |  __ \ 
              | \  / |   | |  | |  | | | \  / |  __ _  _ __   __ _  __ _| |__) |
              | |\/| |   | |  | |  | | | |\/| | / _` || '_ \ / _` |/ _` |  _  / 
              | |  | |   | |  | |__| | | |  | || (_| || | | | (_| | (_| | | \ \ 
              |_|  |_|   |_|   \____/  |_|  |_| \__,_||_| |_|\__,_|\__, |_|  \_\
                                                                    __/ |      
                                                                   |___/       
            ====================================================================
            [ M.T.O MANAGER - ENTERPRISE ORCHESTRATION & CONTROL SUITE ]
            ====================================================================
        """.trimIndent()
        println(themeEngine.colorize(banner, false))
    }

    fun displaySystemStats() {
        val runtime = Runtime.getRuntime()
        val totalMemoryMb = runtime.totalMemory() / (1024 * 1024)
        val freeMemoryMb = runtime.freeMemory() / (1024 * 1024)
        val usedMemoryMb = totalMemoryMb - freeMemoryMb

        println(themeEngine.colorize(">>> REAL-TIME SYSTEM MONITOR <<<", true))
        println("Active Theme    : ${themeEngine.activeTheme.nameTitle}")
        println("Memory Allocated: ${usedMemoryMb}MB / ${totalMemoryMb}MB")
        println("Workspace Path  : ${workspaceDir.absolutePath}")
        println("Active Modules  : 30 Integrated Phases + 2 Extensions")
        println("--------------------------------------------------------------------")
    }

    fun executeQuickOptimization() {
        println(themeEngine.colorize("[*] Running Workspace Cache Optimization...", true))
        val reclaimedBytes = optimizerEngine.optimizeWorkspaceMemory(workspaceDir)
        println(themeEngine.colorize("[+] Optimization Complete. Reclaimed Memory: ${reclaimedBytes / 1024} KB", false))
    }

    fun launchFileBridge() {
        println(themeEngine.colorize("[*] Starting Local HTTP File Bridge on Port 8080...", true))
        val success = releaseFacade.launchFileBridgeServer()
        if (success) {
            println(themeEngine.colorize("[+] Server Active. Access via browser at http://localhost:8080", false))
        } else {
            println(themeEngine.colorize("[-] Failed to initialize HTTP File Bridge.", true))
        }
    }
}
EOF

echo "[+] M.T.O MANAGER Master CLI Dashboard Engine Built Successfully!"
