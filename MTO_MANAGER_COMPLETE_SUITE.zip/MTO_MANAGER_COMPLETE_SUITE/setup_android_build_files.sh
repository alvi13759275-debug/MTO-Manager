#!/bin/bash
set -e

echo "[+] Generating Gradle build configuration and AndroidManifest..."

# 1. Root settings.gradle
cat << 'EOF' > settings.gradle
rootProject.name = "MTO_MANAGER_COMPLETE_SUITE"
include ':app'
EOF

# 2. Root build.gradle
cat << 'EOF' > build.gradle
buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath 'com.android.tools.build:gradle:8.1.1'
        classpath 'org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.0'
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}
EOF

# 3. App module structure and build.gradle
mkdir -p app/src/main/java
mkdir -p app/src/main/res

cat << 'EOF' > app/build.gradle
plugins {
    id 'com.android.application'
    id 'org.jetbrains.kotlin.android'
}

android {
    namespace 'com.mto.advanced'
    compileSdk 33

    defaultConfig {
        applicationId "com.mto.advanced"
        minSdk 24
        targetSdk 33
        versionCode 1
        versionName "1.0.0"
    }

    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = '17'
    }
}

dependencies {
    implementation 'androidx.core:core-ktx:1.10.1'
    implementation 'androidx.appcompat:appcompat:1.6.1'
}
EOF

# 4. AndroidManifest.xml
cat << 'EOF' > app/src/main/AndroidManifest.xml
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/xml/android">
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />

    <application
        android:allowBackup="true"
        android:label="M.T.O MANAGER"
        android:supportsRtl="true"
        android:theme="@style/Theme.AppCompat.Light">
    </application>
</manifest>
EOF

# 5. Move Kotlin code inside app module
cp -r mto-manager/feature/advanced/src/main/java/* app/src/main/java/ 2>/dev/null || true

echo "[+] Gradle configuration files generated successfully!"
