#!/bin/bash
set -e

echo "[+] Writing Phase 2 Cyber Security & Integrity Modules..."

# Create package directory
mkdir -p mto-manager/feature/terminal/src/main/java/com/mto/terminal/security

# 1. Advanced Cyber Crypto Vault (AES-256-GCM + PBKDF2)
cat << 'EOF' > mto-manager/feature/terminal/src/main/java/com/mto/terminal/security/CyberCryptoVault.kt
package com.mto.terminal.security

import android.util.Base64
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.spec.KeySpec
import java.util.concurrent.ConcurrentHashMap
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

object CyberCryptoVault {

    private const val AES_KEY_SIZE_BITS = 256
    private const val GCM_IV_LENGTH_BYTES = 12
    private const val GCM_TAG_LENGTH_BITS = 128
    private const val PBKDF2_ITERATIONS = 100000
    private const val SALT_LENGTH_BYTES = 32
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val KEY_DERIVATION_ALGORITHM = "PBKDF2WithHmacSHA256"
    private const val BUFFER_SIZE = 65536

    data class EncryptedPayload(
        val saltBase64: String,
        val ivBase64: String,
        val cipherTextBase64: String,
        val checksumSha256: String,
        val timestamp: Long
    )

    data class KeyMetadata(
        val keyAlias: String,
        val creationTimestamp: Long,
        val iterations: Int,
        val algorithm: String
    )

    private val activeKeyStore = ConcurrentHashMap<String, SecretKey>()
    private val keyMetadataStore = ConcurrentHashMap<String, KeyMetadata>()

    fun generateSecureRandomBytes(length: Int): ByteArray {
        val randomBytes = ByteArray(length)
        SecureRandom().nextBytes(randomBytes)
        return randomBytes
    }

    fun deriveKeyFromPassword(password: CharArray, salt: ByteArray): SecretKey {
        val factory = SecretKeyFactory.getInstance(KEY_DERIVATION_ALGORITHM)
        val spec: KeySpec = PBEKeySpec(password, salt, PBKDF2_ITERATIONS, AES_KEY_SIZE_BITS)
        val secretKeyBytes = factory.generateSecret(spec).encoded
        return SecretKeySpec(secretKeyBytes, "AES")
    }

    fun registerManagedKey(alias: String, password: CharArray, salt: ByteArray): Boolean {
        return try {
            val derivedKey = deriveKeyFromPassword(password, salt)
            activeKeyStore[alias] = derivedKey
            keyMetadataStore[alias] = KeyMetadata(
                keyAlias = alias,
                creationTimestamp = System.currentTimeMillis(),
                iterations = PBKDF2_ITERATIONS,
                algorithm = KEY_DERIVATION_ALGORITHM
            )
            true
        } catch (e: Exception) {
            false
        }
    }

    fun revokeKey(alias: String): Boolean {
        return if (activeKeyStore.containsKey(alias)) {
            activeKeyStore.remove(alias)
            keyMetadataStore.remove(alias)
            true
        } else {
            false
        }
    }

    fun encryptTextWithKey(plainText: String, secretKey: SecretKey): EncryptedPayload {
        val salt = generateSecureRandomBytes(SALT_LENGTH_BYTES)
        val iv = generateSecureRandomBytes(GCM_IV_LENGTH_BYTES)

        val cipher = Cipher.getInstance(TRANSFORMATION)
        val parameterSpec = GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv)
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, parameterSpec)

        val plainBytes = plainText.toByteArray(Charsets.UTF_8)
        val cipherTextBytes = cipher.doFinal(plainBytes)

        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest(cipherTextBytes)
        val checksum = hashBytes.joinToString("") { "%02x".format(it) }

        return EncryptedPayload(
            saltBase64 = Base64.encodeToString(salt, Base64.NO_WRAP),
            ivBase64 = Base64.encodeToString(iv, Base64.NO_WRAP),
            cipherTextBase64 = Base64.encodeToString(cipherTextBytes, Base64.NO_WRAP),
            checksumSha256 = checksum,
            timestamp = System.currentTimeMillis()
        )
    }

    fun decryptTextWithKey(payload: EncryptedPayload, secretKey: SecretKey): String {
        val iv = Base64.decode(payload.ivBase64, Base64.NO_WRAP)
        val cipherText = Base64.decode(payload.cipherTextBase64, Base64.NO_WRAP)

        val digest = MessageDigest.getInstance("SHA-256")
        val calculatedHash = digest.digest(cipherText).joinToString("") { "%02x".format(it) }

        if (calculatedHash != payload.checksumSha256) {
            throw SecurityException("Payload checksum verification failed. File corrupted or tampered.")
        }

        val cipher = Cipher.getInstance(TRANSFORMATION)
        val parameterSpec = GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv)
        cipher.init(Cipher.DECRYPT_MODE, secretKey, parameterSpec)

        val plainTextBytes = cipher.doFinal(cipherText)
        return String(plainTextBytes, Charsets.UTF_8)
    }

    fun encryptFileNio(inputFile: File, outputFile: File, password: CharArray): Boolean {
        if (!inputFile.exists() || !inputFile.canRead()) return false

        try {
            val salt = generateSecureRandomBytes(SALT_LENGTH_BYTES)
            val iv = generateSecureRandomBytes(GCM_IV_LENGTH_BYTES)
            val secretKey = deriveKeyFromPassword(password, salt)

            val cipher = Cipher.getInstance(TRANSFORMATION)
            val parameterSpec = GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv)
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, parameterSpec)

            FileOutputStream(outputFile).use { fos ->
                fos.write(salt)
                fos.write(iv)

                FileInputStream(inputFile).use { fis ->
                    val inChannel: FileChannel = fis.channel
                    val buffer = ByteBuffer.allocateDirect(BUFFER_SIZE)

                    while (inChannel.read(buffer) != -1) {
                        buffer.flip()
                        val chunk = ByteArray(buffer.remaining())
                        buffer.get(chunk)
                        val encryptedChunk = cipher.update(chunk)
                        if (encryptedChunk != null) {
                            fos.write(encryptedChunk)
                        }
                        buffer.clear()
                    }

                    val finalBytes = cipher.doFinal()
                    if (finalBytes != null) {
                        fos.write(finalBytes)
                    }
                }
            }
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }

    fun decryptFileNio(inputFile: File, outputFile: File, password: CharArray): Boolean {
        if (!inputFile.exists() || !inputFile.canRead()) return false

        try {
            FileInputStream(inputFile).use { fis ->
                val salt = ByteArray(SALT_LENGTH_BYTES)
                val iv = ByteArray(GCM_IV_LENGTH_BYTES)

                if (fis.read(salt) != SALT_LENGTH_BYTES || fis.read(iv) != GCM_IV_LENGTH_BYTES) {
                    return false
                }

                val secretKey = deriveKeyFromPassword(password, salt)
                val cipher = Cipher.getInstance(TRANSFORMATION)
                val parameterSpec = GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv)
                cipher.init(Cipher.DECRYPT_MODE, secretKey, parameterSpec)

                FileOutputStream(outputFile).use { fos ->
                    val inChannel: FileChannel = fis.channel
                    val buffer = ByteBuffer.allocateDirect(BUFFER_SIZE)

                    while (inChannel.read(buffer) != -1) {
                        buffer.flip()
                        val chunk = ByteArray(buffer.remaining())
                        buffer.get(chunk)
                        val decryptedChunk = cipher.update(chunk)
                        if (decryptedChunk != null) {
                            fos.write(decryptedChunk)
                        }
                        buffer.clear()
                    }

                    val finalBytes = cipher.doFinal()
                    if (finalBytes != null) {
                        fos.write(finalBytes)
                    }
                }
            }
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }

    fun wipeFileSecurely(file: File, passes: Int = 3): Boolean {
        if (!file.exists() || !file.isFile) return false

        return try {
            val length = file.length()
            val random = SecureRandom()
            RandomAccessFile(file, "rws").use { raf ->
                for (pass in 0 until passes) {
                    raf.seek(0)
                    var currentPosition: Long = 0
                    val buffer = ByteArray(BUFFER_SIZE)

                    while (currentPosition < length) {
                        val bytesToWrite = Math.min(BUFFER_SIZE.toLong(), length - currentPosition).toInt()
                        random.nextBytes(buffer)
                        raf.write(buffer, 0, bytesToWrite)
                        currentPosition += bytesToWrite
                    }
                }
            }
            file.delete()
        } catch (e: Exception) {
            false
        }
    }
}
EOF

# 2. Anti-Tamper Security Guard
cat << 'EOF' > mto-manager/feature/terminal/src/main/java/com/mto/terminal/security/AntiTamperGuard.kt
package com.mto.terminal.security

import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

object AntiTamperGuard {

    private val fileRegistry = ConcurrentHashMap<String, String>()
    private val criticalPaths = mutableListOf<File>()

    fun registerCriticalFile(file: File): Boolean {
        if (!file.exists() || !file.isFile) return false
        val hash = computeFileHash(file)
        fileRegistry[file.absolutePath] = hash
        if (!criticalPaths.contains(file)) {
            criticalPaths.add(file)
        }
        return true
    }

    fun computeFileHash(file: File, algorithm: String = "SHA-256"): String {
        val digest = MessageDigest.getInstance(algorithm)
        val buffer = ByteArray(65536)

        FileInputStream(file).use { fis ->
            var bytesRead: Int
            while (fis.read(buffer).also { bytesRead = it } != -1) {
                digest.update(buffer, 0, bytesRead)
            }
        }

        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    fun auditIntegrity(): List<String> {
        val auditReport = mutableListOf<String>()

        for (file in criticalPaths) {
            val expectedHash = fileRegistry[file.absolutePath]
            if (!file.exists()) {
                auditReport.add("MISSING: ${file.name}")
                continue
            }

            val currentHash = computeFileHash(file)
            if (expectedHash != currentHash) {
                auditReport.add("TAMPERED: ${file.name}")
            } else {
                auditReport.add("INTEACT: ${file.name}")
            }
        }

        return auditReport
    }
}
EOF

echo "[+] Phase 2 Modules Generated Successfully!"
