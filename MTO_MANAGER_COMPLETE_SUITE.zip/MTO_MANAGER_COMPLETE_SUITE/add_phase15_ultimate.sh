#!/bin/bash
set -e

echo "[+] Generating Phase 15: Advanced Plugin Engine (Complete & Uncut Implementation)..."

mkdir -p mto-manager/feature/advanced/src/main/java/com/mto/advanced/plugins

cat << 'EOF' > mto-manager/feature/advanced/src/main/java/com/mto/advanced/plugins/PluginDexLoader.kt
package com.mto.advanced.plugins

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.lang.reflect.Method
import java.lang.reflect.Modifier
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.PriorityBlockingQueue
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

class PluginDexLoader private constructor(
    private val basePluginStorageDir: File,
    private val optimizedDexCacheDir: File,
    private val securityPolicy: PluginSecurityPolicy = PluginSecurityPolicy()
) {

    data class PluginSecurityPolicy(
        val allowUnsignedPlugins: Boolean = false,
        val enforceSandboxIsolation: Boolean = true,
        val maxMemoryAllocationMb: Long = 128L,
        val allowedPermissions: Set<String> = setOf("READ_STORAGE", "WRITE_STORAGE", "NETWORK_ACCESS"),
        val maxExecutionTimeoutMs: Long = 30000L
    )

    enum class PluginLifecycleState {
        UNVERIFIED,
        VERIFYING_SIGNATURE,
        OPTIMIZING_DEX,
        LOADED,
        INITIALIZING,
        RUNNING,
        PAUSED,
        UNLOADING,
        QUARANTINED,
        FAILED
    }

    enum class ExecutionPriority(val weight: Int) {
        BACKGROUND(1),
        NORMAL(2),
        HIGH(3),
        REALTIME_CRITICAL(4)
    }

    data class PluginManifest(
        val pluginId: String = UUID.randomUUID().toString(),
        val packageName: String,
        val version: String,
        val entryClassName: String,
        val sourceDexFile: File,
        val expectedSha256Checksum: String,
        val priority: ExecutionPriority = ExecutionPriority.NORMAL,
        var currentState: PluginLifecycleState = PluginLifecycleState.UNVERIFIED,
        val loadedTimestamp: Long = System.currentTimeMillis(),
        var executionTimeTotalMs: AtomicLong = AtomicLong(0L),
        var faultCount: AtomicInteger = AtomicInteger(0)
    ) : Comparable<PluginManifest> {
        override fun compareTo(other: PluginManifest): Int {
            return other.priority.weight.compareTo(this.priority.weight)
        }
    }

    interface PluginEventListener {
        fun onPluginStateChanged(plugin: PluginManifest, previousState: PluginLifecycleState, newState: PluginLifecycleState)
        fun onPluginExecutionError(plugin: PluginManifest, errorMsg: String, cause: Throwable?)
        fun onSecurityViolationDetected(plugin: PluginManifest, violationDetails: String)
    }

    private val activePluginRegistry = ConcurrentHashMap<String, PluginManifest>()
    private val classLoaderCache = ConcurrentHashMap<String, ClassLoader>()
    private val instantiatedPluginMap = ConcurrentHashMap<String, Any>()
    private val executionQueue = PriorityBlockingQueue<PluginManifest>()
    private val eventListeners = CopyOnWriteArrayList<PluginEventListener>()

    private val threadPoolExecutor = Executors.newFixedThreadPool(4)
    private val monitorScheduler: ScheduledExecutorService = Executors.newScheduledThreadPool(2)
    private val isEngineRunning = AtomicBoolean(true)

    init {
        require(basePluginStorageDir.exists() || basePluginStorageDir.mkdirs()) {
            "Failed to create base plugin storage directory: ${basePluginStorageDir.absolutePath}"
        }
        require(optimizedDexCacheDir.exists() || optimizedDexCacheDir.mkdirs()) {
            "Failed to create optimized DEX cache directory: ${optimizedDexCacheDir.absolutePath}"
        }

        startRealTimeWatcher()
        startHealthCheckMonitor()
    }

    fun registerListener(listener: PluginEventListener) {
        eventListeners.add(listener)
    }

    fun unregisterListener(listener: PluginEventListener) {
        eventListeners.remove(listener)
    }

    fun loadAndInitializePlugin(
        pluginFile: File,
        packageName: String,
        entryClass: String,
        version: String,
        priority: ExecutionPriority = ExecutionPriority.NORMAL
    ): String {
        validateFileIntegrity(pluginFile)

        val fileChecksum = calculateSha256(pluginFile)
        val manifest = PluginManifest(
            packageName = packageName,
            version = version,
            entryClassName = entryClass,
            sourceDexFile = pluginFile,
            expectedSha256Checksum = fileChecksum,
            priority = priority
        )

        activePluginRegistry[manifest.pluginId] = manifest
        transitionState(manifest, PluginLifecycleState.VERIFYING_SIGNATURE)

        threadPoolExecutor.execute {
            processPluginPipeline(manifest)
        }

        return manifest.pluginId
    }

    private fun validateFileIntegrity(file: File) {
        require(file.exists()) { "Target plugin file does not exist: ${file.absolutePath}" }
        require(file.isFile) { "Target path is a directory: ${file.absolutePath}" }
        require(file.length() > 0) { "Target plugin file is empty." }
    }

    private fun processPluginPipeline(manifest: PluginManifest) {
        try {
            if (!verifyPluginSecurityAndSignature(manifest)) {
                transitionState(manifest, PluginLifecycleState.QUARANTINED)
                notifySecurityViolation(manifest, "Signature validation or checksum verification failed.")
                return
            }

            transitionState(manifest, PluginLifecycleState.OPTIMIZING_DEX)
            val parentLoader = this.javaClass.classLoader
            
            // Runtime Dex Class Loading Mechanism Simulation
            val customLoader = dalvik.system.DexClassLoader(
                manifest.sourceDexFile.absolutePath,
                optimizedDexCacheDir.absolutePath,
                null,
                parentLoader
            )

            classLoaderCache[manifest.pluginId] = customLoader
            transitionState(manifest, PluginLifecycleState.LOADED)

            transitionState(manifest, PluginLifecycleState.INITIALIZING)
            val loadedClass = customLoader.loadClass(manifest.entryClassName)

            validateClassSecurityConstraints(loadedClass)

            val pluginInstance = loadedClass.getDeclaredConstructor().newInstance()
            instantiatedPluginMap[manifest.pluginId] = pluginInstance

            transitionState(manifest, PluginLifecycleState.RUNNING)

        } catch (e: Exception) {
            manifest.faultCount.incrementAndGet()
            transitionState(manifest, PluginLifecycleState.FAILED)
            notifyError(manifest, "Failed to complete plugin initialization pipeline: ${e.message}", e)
        }
    }

    private fun verifyPluginSecurityAndSignature(manifest: PluginManifest): Boolean {
        val calculatedChecksum = calculateSha256(manifest.sourceDexFile)
        if (calculatedChecksum != manifest.expectedSha256Checksum) {
            return false
        }

        if (!securityPolicy.allowUnsignedPlugins) {
            return verifyJarOrZipSignature(manifest.sourceDexFile)
        }

        return true
    }

    private fun verifyJarOrZipSignature(file: File): Boolean {
        return try {
            ZipInputStream(FileInputStream(file)).use { zipIn ->
                var entry: ZipEntry? = zipIn.nextEntry
                var hasCertificates = false
                while (entry != null) {
                    if (entry.name.startsWith("META-INF/") && (entry.name.endsWith(".RSA") || entry.name.endsWith(".DSA") || entry.name.endsWith(".EC"))) {
                        hasCertificates = true
                        break
                    }
                    entry = zipIn.nextEntry
                }
                hasCertificates
            }
        } catch (e: Exception) {
            false
        }
    }

    private fun validateClassSecurityConstraints(clazz: Class<*>) {
        if (Modifier.isAbstract(clazz.modifiers) || Modifier.isInterface(clazz.modifiers)) {
            throw IllegalArgumentException("Entry class must be a concrete, instantiable class.")
        }
    }

    fun executePluginMethod(pluginId: String, methodName: String, vararg parameters: Any): Any? {
        val manifest = activePluginRegistry[pluginId] ?: throw IllegalArgumentException("Plugin ID not registered: $pluginId")
        if (manifest.currentState != PluginLifecycleState.RUNNING) {
            throw IllegalStateException("Plugin $pluginId is not in RUNNING state. Current state: ${manifest.currentState}")
        }

        val instance = instantiatedPluginMap[pluginId] ?: throw IllegalStateException("Plugin instance missing for ID: $pluginId")
        val startTime = System.currentTimeMillis()

        return try {
            val paramTypes = parameters.map { it.javaClass }.toTypedArray()
            val method = findMatchingMethod(instance.javaClass, methodName, paramTypes)
                ?: throw NoSuchMethodException("Method $methodName with specified parameters not found in ${manifest.entryClassName}")

            val result = method.invoke(instance, *parameters)
            val elapsed = System.currentTimeMillis() - startTime
            manifest.executionTimeTotalMs.addAndGet(elapsed)

            result
        } catch (e: Exception) {
            manifest.faultCount.incrementAndGet()
            notifyError(manifest, "Exception thrown during execution of method $methodName: ${e.message}", e)
            if (manifest.faultCount.get() >= 5) {
                transitionState(manifest, PluginLifecycleState.QUARANTINED)
            }
            null
        }
    }

    private fun findMatchingMethod(clazz: Class<*>, methodName: String, paramTypes: Array<Class<*>>): Method? {
        for (method in clazz.declaredMethods) {
            if (method.name == methodName && method.parameterCount == paramTypes.size) {
                method.isAccessible = true
                return method
            }
        }
        return null
    }

    fun pausePlugin(pluginId: String): Boolean {
        val manifest = activePluginRegistry[pluginId] ?: return false
        if (manifest.currentState == PluginLifecycleState.RUNNING) {
            transitionState(manifest, PluginLifecycleState.PAUSED)
            return true
        }
        return false
    }

    fun resumePlugin(pluginId: String): Boolean {
        val manifest = activePluginRegistry[pluginId] ?: return false
        if (manifest.currentState == PluginLifecycleState.PAUSED) {
            transitionState(manifest, PluginLifecycleState.RUNNING)
            return true
        }
        return false
    }

    fun unloadPlugin(pluginId: String): Boolean {
        val manifest = activePluginRegistry[pluginId] ?: return false
        transitionState(manifest, PluginLifecycleState.UNLOADING)

        instantiatedPluginMap.remove(pluginId)
        classLoaderCache.remove(pluginId)
        activePluginRegistry.remove(pluginId)

        return true
    }

    private fun transitionState(manifest: PluginManifest, newState: PluginLifecycleState) {
        val oldState = manifest.currentState
        manifest.currentState = newState
        eventListeners.forEach { listener ->
            listener.onPluginStateChanged(manifest, oldState, newState)
        }
    }

    private fun notifyError(manifest: PluginManifest, message: String, cause: Throwable?) {
        eventListeners.forEach { listener ->
            listener.onPluginExecutionError(manifest, message, cause)
        }
    }

    private fun notifySecurityViolation(manifest: PluginManifest, details: String) {
        eventListeners.forEach { listener ->
            listener.onSecurityViolationDetected(manifest, details)
        }
    }

    private fun calculateSha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { fis ->
            val buffer = ByteArray(65536)
            var read: Int
            while (fis.read(buffer).also { read = it } != -1) {
                digest.update(buffer, 0, read)
            }
        }
        val hash = digest.digest()
        val builder = StringBuilder()
        for (b in hash) {
            builder.append(String.format("%02x", b))
        }
        return builder.toString()
    }

    private fun startRealTimeWatcher() {
        monitorScheduler.scheduleAtFixedRate({
            if (!isEngineRunning.get()) return@scheduleAtFixedRate

            val files = basePluginStorageDir.listFiles() ?: return@scheduleAtFixedRate
            for (file in files) {
                if (file.name.endsWith(".dex") || file.name.endsWith(".apk") || file.name.endsWith(".jar")) {
                    val alreadyLoaded = activePluginRegistry.values.any { it.sourceDexFile.absolutePath == file.absolutePath }
                    if (!alreadyLoaded) {
                        loadAndInitializePlugin(
                            pluginFile = file,
                            packageName = "com.mto.extension." + file.nameWithoutExtension,
                            entryClass = "com.mto.extension.MainPluginEntry",
                            version = "1.0.0"
                        )
                    }
                }
            }
        }, 2, 5, TimeUnit.SECONDS)
    }

    private fun startHealthCheckMonitor() {
        monitorScheduler.scheduleAtFixedRate({
            if (!isEngineRunning.get()) return@scheduleAtFixedRate

            for (manifest in activePluginRegistry.values) {
                if (manifest.faultCount.get() > 10) {
                    transitionState(manifest, PluginLifecycleState.QUARANTINED)
                }
            }
        }, 10, 30, TimeUnit.SECONDS)
    }

    fun shutdownEngine() {
        isEngineRunning.set(false)
        threadPoolExecutor.shutdown()
        monitorScheduler.shutdown()
    }

    companion object {
        @Volatile
        private var INSTANCE: PluginDexLoader? = null

        fun getInstance(
            storageDir: File,
            cacheDir: File,
            policy: PluginSecurityPolicy = PluginSecurityPolicy()
        ): PluginDexLoader {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: PluginDexLoader(storageDir, cacheDir, policy).also { INSTANCE = it }
            }
        }
    }
}
EOF

echo "[+] Phase 15 PluginDexLoader.kt Written Successfully!"
