#!/bin/bash
set -e

echo "[+] Fixing code syntax and compatibility issues..."

# 1. Fix FileChecksumEngine.kt syntax error
CHECKSUM_FILE="app/src/main/java/com/mto/advanced/storage/FileChecksumEngine.kt"
if [ -f "$CHECKSUM_FILE" ]; then
    sed -i 's/e.printStackTrace Torch/e.printStackTrace()/g' "$CHECKSUM_FILE"
    sed -i 's/e.printStackTrace()/e.printStackTrace()/g' "$CHECKSUM_FILE"
fi

# 2. Fix String Escape issue in Phase26MainAppEntry.kt if exists
PHASE26_FILE="app/src/main/java/com/mto/advanced/entry/Phase26MainAppEntry.kt"
if [ -f "$PHASE26_FILE" ]; then
    sed -i 's/(\$percent\\%)/(\$percent\%)/g' "$PHASE26_FILE" 2>/dev/null || true
fi

# 3. Exclude Android-only PluginDexLoader from Desktop JVM compile path temporarily
DEX_LOADER="app/src/main/java/com/mto/advanced/plugins/PluginDexLoader.kt"
if [ -f "$DEX_LOADER" ]; then
    mv "$DEX_LOADER" "${DEX_LOADER}.bak"
fi

echo "[+] Compiling M.T.O MANAGER into standalone executable JAR..."

# 4. Compile cleanly
kotlinc $(find app/src/main/java -name "*.kt") -include-runtime -d mto_manager_app.jar

echo "[+] Compilation Successful! mto_manager_app.jar is ready."
