#!/bin/bash
set -e

echo "[+] Initializing Phase 29 Mega Storage & File Processing Engine Generation..."

BASE_DIR="mto-manager/feature/advanced/src/main/java/com/mto/advanced/storage"
mkdir -p "$BASE_DIR"

# -----------------------------------------------------------------------------
# FILE 1: Multi-Threaded Parallel Search Engine Module
# -----------------------------------------------------------------------------
echo "[1/4] Writing ParallelFileSearchEngine.kt..."
cat << 'EOF' > "$BASE_DIR/ParallelFileSearchEngine.kt"
package com.mto.advanced.storage

import java.io.File
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors

data class SearchResult(
    val file: File,
    val sizeBytes: Long,
    val lastModified: Long
)

class ParallelFileSearchEngine {

    private val threadPool = Executors.newFixedThreadPool(8)

    fun searchFiles(
        rootDirectory: File,
        queryName: String,
        onComplete: (List<SearchResult>) -> Unit
    ) {
        val matches = ConcurrentLinkedQueue<SearchResult>()
        
        threadPool.execute {
            if (rootDirectory.exists() && rootDirectory.isDirectory) {
                traverseAndMatch(rootDirectory, queryName.lowercase(), matches)
            }
            onComplete(matches.toList())
        }
    }

    private fun traverseAndMatch(
        dir: File,
        query: String,
        results: ConcurrentLinkedQueue<SearchResult>
    ) {
        val files = dir.listFiles() ?: return
        for (file in files) {
            if (file.name.lowercase().contains(query)) {
                results.add(SearchResult(file, file.length(), file.lastModified()))
            }
            if (file.isDirectory) {
                traverseAndMatch(file, query, results)
            }
        }
    }

    fun shutdown() {
        threadPool.shutdown()
    }
}
EOF

# -----------------------------------------------------------------------------
# FILE 2: Archive Manager Module (Zip & Tar Processing)
# -----------------------------------------------------------------------------
echo "[2/4] Writing ArchiveManagerEngine.kt..."
cat << 'EOF' > "$BASE_DIR/ArchiveManagerEngine.kt"
package com.mto.advanced.storage

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class ArchiveManagerEngine {

    fun compressToZip(sourceFiles: List<File>, outputZipFile: File): Boolean {
        return try {
            ZipOutputStream(FileOutputStream(outputZipFile)).use { zos ->
                for (file in sourceFiles) {
                    if (file.exists() && file.isFile) {
                        val entry = ZipEntry(file.name)
                        zos.putNextEntry(entry)
                        file.inputStream().use { input -> input.copyTo(zos) }
                        zos.closeEntry()
                    }
                }
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun extractZip(zipFile: File, targetDir: File): Boolean {
        if (!zipFile.exists()) return false
        if (!targetDir.exists()) targetDir.mkdirs()

        return try {
            ZipInputStream(FileInputStream(zipFile)).use { zis ->
                var entry: ZipEntry? = zis.nextEntry
                while (entry != null) {
                    val newFile = File(targetDir, entry.name)
                    if (entry.isDirectory) {
                        newFile.mkdirs()
                    } else {
                        newFile.parentFile?.mkdirs()
                        FileOutputStream(newFile).use { fos -> zis.copyTo(fos) }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
EOF

# -----------------------------------------------------------------------------
# FILE 3: File Checksum & Integrity Calculator Module
# -----------------------------------------------------------------------------
echo "[3/4] Writing FileChecksumEngine.kt..."
cat << 'EOF' > "$BASE_DIR/FileChecksumEngine.kt"
package com.mto.advanced.storage

import java.io.File
import java.security.MessageDigest

data class ChecksumResult(
    val md5: String,
    val sha1: String,
    val sha256: String
)

class FileChecksumEngine {

    fun calculateChecksums(file: File): ChecksumResult? {
        if (!file.exists() || !file.isFile) return null

        return try {
            val md5Digest = MessageDigest.getInstance("MD5")
            val sha1Digest = MessageDigest.getInstance("SHA-1")
            val sha256Digest = MessageDigest.getInstance("SHA-256")

            file.inputStream().use { fis ->
                val buffer = ByteArray(8192)
                var bytesRead = fis.read(buffer)
                while (bytesRead != -1) {
                    md5Digest.update(buffer, 0, bytesRead)
                    sha1Digest.update(buffer, 0, bytesRead)
                    sha256Digest.update(buffer, 0, bytesRead)
                    bytesRead = fis.read(buffer)
                }
            }

            ChecksumResult(
                md5 = bytesToHex(md5Digest.digest()),
                sha1 = bytesToHex(sha1Digest.digest()),
                sha256 = bytesToHex(sha256Digest.digest())
            )
        } catch (e: Exception) {
            e.printStackTrace Torch
            null
        }
    }

    private fun bytesToHex(bytes: ByteArray): String {
        val sb = StringBuilder()
        for (b in bytes) {
            sb.append(String.format("%02x", b))
        }
        return sb.toString()
    }
}
EOF

# -----------------------------------------------------------------------------
# FILE 4: Phase 29 Master Storage Facade Orchestrator
# -----------------------------------------------------------------------------
echo "[4/4] Writing Phase29StorageFacade.kt..."
cat << 'EOF' > "$BASE_DIR/Phase29StorageFacade.kt"
package com.mto.advanced.storage

import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

class Phase29StorageFacade private constructor(
    private val workspaceDir: File
) {
    val searchEngine = ParallelFileSearchEngine()
    val archiveEngine = ArchiveManagerEngine()
    val checksumEngine = FileChecksumEngine()

    private val threadPool = Executors.newFixedThreadPool(4)

    data class StorageTaskResult(
        val taskId: String,
        val isSuccess: Boolean,
        val message: String,
        val executionTimeMs: Long
    )

    interface StorageEventListener {
        fun onTaskCompleted(result: StorageTaskResult)
    }

    private val listeners = CopyOnWriteArrayList<StorageEventListener>()

    fun addListener(listener: StorageEventListener) { listeners.add(listener) }
    fun removeListener(listener: StorageEventListener) { listeners.remove(listener) }

    fun runParallelSearch(query: String, rootDir: File = workspaceDir, onFound: (List<SearchResult>) -> Unit) {
        searchEngine.searchFiles(rootDir, query, onFound)
    }

    fun createArchiveAsync(taskId: String = UUID.randomUUID().toString(), files: List<File>, outputZip: File) {
        val startTime = System.currentTimeMillis()
        threadPool.execute {
            val success = archiveEngine.compressToZip(files, outputZip)
            val result = StorageTaskResult(
                taskId = taskId,
                isSuccess = success,
                message = if (success) "Zip archive created: ${outputZip.name}" else "Compression failed",
                executionTimeMs = System.currentTimeMillis() - startTime
            )
            listeners.forEach { it.onTaskCompleted(result) }
        }
    }

    fun shutdown() {
        searchEngine.shutdown()
        threadPool.shutdown()
    }

    companion object {
        @Volatile
        private var instance: Phase29StorageFacade? = null

        fun getInstance(workspaceDir: File): Phase29StorageFacade {
            return instance ?: synchronized(this) {
                instance ?: Phase29StorageFacade(workspaceDir).also { instance = it }
            }
        }
    }
}
EOF

echo "[+] Phase 29 Mega Storage & File Processing Engine Built Successfully!"
