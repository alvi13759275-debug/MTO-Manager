#!/bin/bash
set -e

echo "[+] Writing Phase 4 Developer & HUD Modules..."

# 1. Shell Command Execution Runner Engine
cat << 'EOF' > mto-manager/feature/terminal/src/main/java/com/mto/terminal/runner/TerminalRunnerEngine.kt
package com.mto.terminal.runner

import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.util.concurrent.Executors

object TerminalRunnerEngine {

    data class ExecutionResult(
        val exitCode: Int,
        val output: String,
        val error: String,
        val executionTimeMs: Long
    )

    fun executeCommand(command: String, workingDir: File? = null): ExecutionResult {
        val startTime = System.currentTimeMillis()
        return try {
            val process = ProcessBuilder(*command.split("\\s+".toRegex()).toTypedArray())
                .directory(workingDir)
                .redirectErrorStream(false)
                .start()

            val stdoutBuilder = StringBuilder()
            val stderrBuilder = StringBuilder()

            val threadPool = Executors.newFixedThreadPool(2)

            threadPool.submit {
                BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        stdoutBuilder.append(line).append("\n")
                    }
                }
            }

            threadPool.submit {
                BufferedReader(InputStreamReader(process.errorStream)).use { reader ->
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        stderrBuilder.append(line).append("\n")
                    }
                }
            }

            val exitCode = process.waitFor()
            threadPool.shutdown()

            val elapsedTime = System.currentTimeMillis() - startTime
            ExecutionResult(
                exitCode = exitCode,
                output = stdoutBuilder.toString().trim(),
                error = stderrBuilder.toString().trim(),
                executionTimeMs = elapsedTime
            )
        } catch (e: Exception) {
            val elapsedTime = System.currentTimeMillis() - startTime
            ExecutionResult(
                exitCode = -1,
                output = "",
                error = e.localizedMessage ?: "Execution Failure",
                executionTimeMs = elapsedTime
            )
        }
    }
}
EOF

# 2. Acode & External Workspace Sync Bridge
cat << 'EOF' > mto-manager/feature/terminal/src/main/java/com/mto/terminal/runner/AcodeWorkspaceBridge.kt
package com.mto.terminal.runner

import java.io.File
import org.json.JSONObject

object AcodeWorkspaceBridge {

    fun generateAcodeProjectConfig(projectRootDir: File): Boolean {
        if (!projectRootDir.exists()) return false

        val acodeDir = File(projectRootDir, ".acode")
        if (!acodeDir.exists()) acodeDir.mkdirs()

        val jsonConfig = JSONObject().apply {
            put("name", "M.T.O MANAGER")
            put("type", "android_multi_module")
            put("main_language", "kotlin")
            put("native_support", true)
            put("build_tool", "gradle")
            put("created_at", System.currentTimeMillis())
        }

        val configFile = File(acodeDir, "project.json")
        return try {
            configFile.writeText(jsonConfig.toString(4))
            true
        } catch (e: Exception) {
            false
        }
    }
}
EOF

# 3. Matrix Digital Rain HUD Visualizer Engine
cat << 'EOF' > mto-manager/feature/terminal/src/main/java/com/mto/terminal/ui/MatrixHudEngine.kt
package com.mto.terminal.ui

import java.util.Random

class MatrixHudEngine(private val width: Int = 80, private val height: Int = 24) {

    private val glyphSet = "0123456789ABCDEFABCDEFGHIJKLMNOPQRSTUVWXYZ@#$%&*".toCharArray()
    private val random = Random()
    private val drops = IntArray(width) { random.nextInt(height) }

    fun renderFrame(): String {
        val buffer = Array(height) { CharArray(width) { ' ' } }

        for (x in 0 until width) {
            val y = drops[x]
            if (y in 0 until height) {
                buffer[y][x] = glyphSet[random.nextInt(glyphSet.size)]
            }
            drops[x] = (drops[x] + 1) % height
        }

        val frameBuilder = StringBuilder()
        for (row in buffer) {
            frameBuilder.append(String(row)).append("\n")
        }

        return frameBuilder.toString()
    }
}
EOF

echo "[+] Phase 4 Modules Generated Successfully!"
