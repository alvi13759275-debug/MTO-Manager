#!/bin/bash
set -e

echo "[+] Writing Phase 3 High-Performance Modules (Network & System Core)..."

# 1. P2P Mesh Network Engine
cat << 'EOF' > mto-manager/feature/terminal/src/main/java/com/mto/terminal/network/MeshNetworkNode.kt
package com.mto.terminal.network

import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.concurrent.thread

class MeshNetworkNode(private val listeningPort: Int = 8888) {

    private var isRunning = false
    private var serverSocket: ServerSocket? = null
    private val connectedPeers = ConcurrentHashMap<String, Socket>()
    private val threadPool = Executors.newCachedThreadPool()

    data class PeerMessage(
        val senderIp: String,
        val payload: String,
        val timestamp: Long
    )

    fun startNode(onMessageReceived: (PeerMessage) -> Unit) {
        if (isRunning) return
        isRunning = true

        thread {
            try {
                serverSocket = ServerSocket()
                serverSocket?.reuseAddress = true
                serverSocket?.bind(InetSocketAddress(listeningPort))

                while (isRunning) {
                    val clientSocket = serverSocket?.accept() ?: break
                    val remoteAddress = clientSocket.inetAddress.hostAddress ?: "Unknown"
                    connectedPeers[remoteAddress] = clientSocket

                    threadPool.submit {
                        handleClientConnection(clientSocket, remoteAddress, onMessageReceived)
                    }
                }
            } catch (e: Exception) {
                System.err.println("Mesh Node Socket Exception: ${e.localizedMessage}")
            } finally {
                stopNode()
            }
        }
    }

    private fun handleClientConnection(
        socket: Socket,
        remoteAddress: String,
        onMessageReceived: (PeerMessage) -> Unit
    ) {
        try {
            val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
            var incomingLine: String?

            while (socket.isConnected && !socket.isClosed) {
                incomingLine = reader.readLine() ?: break
                val message = PeerMessage(
                    senderIp = remoteAddress,
                    payload = incomingLine,
                    timestamp = System.currentTimeMillis()
                )
                onMessageReceived(message)
            }
        } catch (e: Exception) {
            System.err.println("Peer connection lost with $remoteAddress: ${e.localizedMessage}")
        } finally {
            connectedPeers.remove(remoteAddress)
            try {
                socket.close()
            } catch (ignored: Exception) {}
        }
    }

    fun broadcastMessage(message: String): Int {
        var successCount = 0
        connectedPeers.forEach { (ip, socket) ->
            if (sendDirectPayload(socket, message)) {
                successCount++
            }
        }
        return successCount
    }

    fun sendPayloadToHost(targetIp: String, targetPort: Int, payload: String): Boolean {
        return try {
            val socket = Socket()
            socket.connect(InetSocketAddress(targetIp, targetPort), 3000)
            val success = sendDirectPayload(socket, payload)
            socket.close()
            success
        } catch (e: Exception) {
            false
        }
    }

    private fun sendDirectPayload(socket: Socket, payload: String): Boolean {
        return try {
            val writer = PrintWriter(socket.getOutputStream(), true)
            writer.println(payload)
            !writer.checkError()
        } catch (e: Exception) {
            false
        }
    }

    fun getActivePeerCount(): Int = connectedPeers.size

    fun stopNode() {
        isRunning = false
        try {
            serverSocket?.close()
        } catch (ignored: Exception) {}

        connectedPeers.forEach { (_, socket) ->
            try {
                socket.close()
            } catch (ignored: Exception) {}
        }
        connectedPeers.clear()
        threadPool.shutdown()
    }
}
EOF

# 2. Auto-Healer & Recovery System Engine
cat << 'EOF' > mto-manager/feature/terminal/src/main/java/com/mto/terminal/system/AutoHealerEngine.kt
package com.mto.terminal.system

import java.io.File
import java.io.FileOutputStream

object AutoHealerEngine {

    data class DiagnosticReport(
        val totalChecked: Int,
        val repairedPaths: List<String>,
        val failedPaths: List<String>,
        val isHealthy: Boolean
    )

    fun performSystemAuditAndRepair(projectRootDir: File): DiagnosticReport {
        val repairedList = mutableListOf<String>()
        val failedList = mutableListOf<String>()
        var totalCheckedCount = 0

        if (!projectRootDir.exists()) {
            projectRootDir.mkdirs()
            repairedList.add(projectRootDir.absolutePath)
        }

        val requiredDirectories = listOf(
            "app/src/main/java/com/mto/manager",
            "feature/terminal/src/main/cpp",
            "feature/terminal/src/main/java/com/mto/terminal/core",
            "feature/terminal/src/main/java/com/mto/terminal/ai",
            "feature/terminal/src/main/java/com/mto/terminal/security",
            "feature/terminal/src/main/java/com/mto/terminal/network",
            "feature/terminal/src/main/java/com/mto/terminal/system",
            "feature/terminal/src/main/res/values"
        )

        for (dirPath in requiredDirectories) {
            totalCheckedCount++
            val dirFile = File(projectRootDir, dirPath)
            if (!dirFile.exists()) {
                if (dirFile.mkdirs()) {
                    repairedList.add(dirPath)
                } else {
                    failedList.add(dirPath)
                }
            }
        }

        val essentialFilesMap = mapOf(
            "feature/terminal/src/main/cpp/CMakeLists.txt" to getMinimalCmakeContent(),
            "feature/terminal/src/main/res/values/strings.xml" to getMinimalStringsXml()
        )

        for ((filePath, defaultContent) in essentialFilesMap) {
            totalCheckedCount++
            val targetFile = File(projectRootDir, filePath)
            if (!targetFile.exists() || targetFile.length() == 0L) {
                try {
                    targetFile.parentFile?.mkdirs()
                    FileOutputStream(targetFile).use { fos ->
                        fos.write(defaultContent.toByteArray(Charsets.UTF_8))
                    }
                    repairedList.add(filePath)
                } catch (e: Exception) {
                    failedList.add(filePath)
                }
            }
        }

        return DiagnosticReport(
            totalChecked = totalCheckedCount,
            repairedPaths = repairedList,
            failedPaths = failedList,
            isHealthy = failedList.isEmpty()
        )
    }

    private fun getMinimalCmakeContent(): String {
        return """
            cmake_minimum_required(VERSION 3.22.1)
            project("cyberkernel")
            set(CMAKE_CXX_STANDARD 20)
            add_library(cyberkernel SHARED cyber_kernel.cpp)
            find_library(log-lib log)
            target_link_libraries(cyberkernel ${'$'}{log-lib})
        """.trimIndent()
    }

    private fun getMinimalStringsXml(): String {
        return """
            <resources>
                <string name="app_name">M.T.O MANAGER</string>
            </resources>
        """.trimIndent()
    }
}
EOF

# 3. Background Task Scheduler Engine
cat << 'EOF' > mto-manager/feature/terminal/src/main/java/com/mto/terminal/system/TaskSchedulerEngine.kt
package com.mto.terminal.system

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

class TaskSchedulerEngine {

    private val scheduler = Executors.newScheduledThreadPool(4)
    private val scheduledTasksMap = ConcurrentHashMap<String, ScheduledFuture<*>>()

    fun scheduleCronJob(
        jobId: String,
        initialDelaySeconds: Long,
        intervalSeconds: Long,
        action: () -> Unit
    ): Boolean {
        if (scheduledTasksMap.containsKey(jobId)) {
            cancelCronJob(jobId)
        }

        return try {
            val future = scheduler.scheduleAtFixedRate({
                try {
                    action()
                } catch (e: Exception) {
                    System.err.println("Scheduled Task Execution Error [$jobId]: ${e.localizedMessage}")
                }
            }, initialDelaySeconds, intervalSeconds, TimeUnit.SECONDS)

            scheduledTasksMap[jobId] = future
            true
        } catch (e: Exception) {
            false
        }
    }

    fun cancelCronJob(jobId: String): Boolean {
        val future = scheduledTasksMap.remove(jobId)
        return if (future != null) {
            future.cancel(true)
            true
        } else {
            false
        }
    }

    fun getActiveJobIds(): List<String> = scheduledTasksMap.keys().toList()

    fun shutdownAllTasks() {
        scheduledTasksMap.forEach { (jobId, future) ->
            future.cancel(true)
        }
        scheduledTasksMap.clear()
        scheduler.shutdown()
    }
}
EOF

echo "[+] Phase 3 Modules Generated Successfully!"
