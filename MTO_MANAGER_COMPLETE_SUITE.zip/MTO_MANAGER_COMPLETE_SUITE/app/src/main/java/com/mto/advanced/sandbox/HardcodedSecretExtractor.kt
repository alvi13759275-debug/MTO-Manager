package com.mto.advanced.sandbox

import java.io.File
import java.util.regex.Pattern

data class DetectedSecret(
    val type: String,
    val matchedPattern: String,
    val lineOffset: Int
)

class HardcodedSecretExtractor {

    private val patterns = mapOf(
        "Generic API Key" to Pattern.compile("(?i)(api_key|apikey|secret|token)\\s*=\\s*['\"]([a-zA-Z0-9_\\-]{16,64})['\"]"),
        "Google API Key" to Pattern.compile("AIzaSy[A-Za-z0-9_\\-]{35}")
    )

    fun extractSecrets(targetFile: File): List<DetectedSecret> {
        val results = mutableListOf<DetectedSecret>()
        if (!targetFile.exists() || targetFile.isDirectory) return results

        try {
            val lines = targetFile.readLines()
            lines.forEachIndexed { index, line ->
                patterns.forEach { (type, pattern) ->
                    val matcher = pattern.matcher(line)
                    if (matcher.find()) {
                        results.add(DetectedSecret(type, matcher.group(0) ?: "Matched", index + 1))
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return results
    }
}
