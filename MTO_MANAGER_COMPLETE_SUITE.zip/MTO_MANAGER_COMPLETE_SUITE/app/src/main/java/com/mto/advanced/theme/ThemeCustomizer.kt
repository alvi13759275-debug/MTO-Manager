package com.mto.advanced.theme

import java.io.File
import java.io.FileReader
import java.io.FileWriter
import java.util.concurrent.ConcurrentHashMap

class ThemeCustomizer(private val configDir: File) {

    data class ColorScheme(
        val name: String,
        val primaryColorHex: String,
        val backgroundColorHex: String,
        val textColorHex: String,
        val cursorColorHex: String,
        val selectionColorHex: String,
        val isDarkTheme: Boolean
    )

    private val themeRegistry = ConcurrentHashMap<String, ColorScheme>()
    private var activeTheme: ColorScheme

    init {
        if (!configDir.exists()) {
            configDir.mkdirs()
        }
        loadDefaultThemes()
        activeTheme = themeRegistry["matrix"] ?: defaultScheme()
        restoreSavedTheme()
    }

    private fun defaultScheme(): ColorScheme {
        return ColorScheme(
            name = "DefaultDark",
            primaryColorHex = "#00FF00",
            backgroundColorHex = "#000000",
            textColorHex = "#FFFFFF",
            cursorColorHex = "#00FF00",
            selectionColorHex = "#333333",
            isDarkTheme = true
        )
    }

    private fun loadDefaultThemes() {
        themeRegistry["matrix"] = ColorScheme("Matrix", "#00FF00", "#000000", "#00FF00", "#00FF00", "#005500", true)
        themeRegistry["dracula"] = ColorScheme("Dracula", "#BD93F9", "#282A36", "#F8F8F2", "#FF79C6", "#44475A", true)
        themeRegistry["monokai"] = ColorScheme("Monokai", "#F92672", "#272822", "#F8F8F2", "#66D9EF", "#49483E", true)
        themeRegistry["solarized_dark"] = ColorScheme("SolarizedDark", "#268BD2", "#002B36", "#839496", "#2AA198", "#073642", true)
        themeRegistry["cyberpunk"] = ColorScheme("Cyberpunk", "#FF0055", "#080811", "#00F0FF", "#FFE600", "#2A085C", true)
    }

    fun registerCustomTheme(theme: ColorScheme): Boolean {
        themeRegistry[theme.name.lowercase()] = theme
        return saveThemeToFile(theme)
    }

    fun applyTheme(themeName: String): ColorScheme? {
        val theme = themeRegistry[themeName.lowercase()]
        if (theme != null) {
            activeTheme = theme
            saveActiveThemeState(theme.name)
        }
        return theme
    }

    fun getActiveTheme(): ColorScheme = activeTheme

    fun getAllThemes(): List<ColorScheme> = themeRegistry.values.toList().sortedBy { it.name }

    private fun saveActiveThemeState(themeName: String) {
        val stateFile = File(configDir, "active_theme.txt")
        try {
            FileWriter(stateFile).use { writer ->
                writer.write(themeName)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun restoreSavedTheme() {
        val stateFile = File(configDir, "active_theme.txt")
        if (stateFile.exists()) {
            try {
                val savedName = FileReader(stateFile).use { it.readText().trim() }
                themeRegistry[savedName.lowercase()]?.let {
                    activeTheme = it
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun saveThemeToFile(theme: ColorScheme): Boolean {
        val file = File(configDir, "theme_${theme.name.lowercase()}.json")
        return try {
            FileWriter(file).use { writer ->
                val json = """
                    {
                      "name": "${theme.name}",
                      "primary": "${theme.primaryColorHex}",
                      "background": "${theme.backgroundColorHex}",
                      "text": "${theme.textColorHex}",
                      "cursor": "${theme.cursorColorHex}",
                      "selection": "${theme.selectionColorHex}",
                      "isDark": ${theme.isDarkTheme}
                    }
                """.trimIndent()
                writer.write(json)
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}
