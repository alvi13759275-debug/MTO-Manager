package com.mto.advanced.extension

import java.io.File
import java.util.concurrent.ConcurrentHashMap

interface MtoPlugin {
    val pluginId: String
    val version: String
    fun onInitialize(workspaceDir: File)
    fun onExecute(args: List<String>): String
}

class DynamicPluginManager(private val workspaceDir: File) {

    private val activePlugins = ConcurrentHashMap<String, MtoPlugin>()

    fun registerPlugin(plugin: MtoPlugin) {
        plugin.onInitialize(workspaceDir)
        activePlugins[plugin.pluginId] = plugin
    }

    fun executePluginCommand(pluginId: String, args: List<String>): String? {
        val plugin = activePlugins[pluginId] ?: return null
        return plugin.onExecute(args)
    }

    fun getRegisteredPlugins(): List<String> {
        return activePlugins.keys.toList()
    }
}
