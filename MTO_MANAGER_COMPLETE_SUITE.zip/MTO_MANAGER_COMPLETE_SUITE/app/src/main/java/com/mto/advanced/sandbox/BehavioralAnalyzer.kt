package com.mto.advanced.sandbox

import java.io.File

data class BehavioralProfile(
    val requestsSMSPermissions: Boolean,
    val requestsLocationPermissions: Boolean,
    val usesCameraHardware: Boolean,
    val overallRiskScore: Int
)

class BehavioralAnalyzer {

    fun analyzeBehavior(manifestOrSource: File): BehavioralProfile {
        if (!manifestOrSource.exists()) return BehavioralProfile(false, false, false, 0)

        val content = try { manifestOrSource.readText() } catch (e: Exception) { "" }

        val hasSms = content.contains("SEND_SMS") || content.contains("RECEIVE_SMS")
        val hasLoc = content.contains("ACCESS_FINE_LOCATION") || content.contains("ACCESS_COARSE_LOCATION")
        val hasCam = content.contains("CAMERA")

        var score = 0
        if (hasSms) score += 40
        if (hasLoc) score += 30
        if (hasCam) score += 20

        return BehavioralProfile(
            requestsSMSPermissions = hasSms,
            requestsLocationPermissions = hasLoc,
            usesCameraHardware = hasCam,
            overallRiskScore = score
        )
    }
}
