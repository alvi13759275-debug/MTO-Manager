package com.mto.advanced.tools

import java.io.File
import java.lang.management.ManagementFactory

data class MemoryMetrics(
    val totalMemoryBytes: Long,
    val freeMemoryBytes: Long,
    val usedMemoryBytes: Long,
    val maxMemoryBytes: Long
)

class SystemMonitorEngine {

    fun getRealtimeMemoryMetrics(): MemoryMetrics {
        val runtime = Runtime.getRuntime()
        val total = runtime.totalMemory()
        val free = runtime.freeMemory()
        val used = total - free
        val max = runtime.maxMemory()
        return MemoryMetrics(total, free, used, max)
    }

    fun getActiveThreadCount(): Int {
        return Thread.activeCount()
    }

    fun getSystemUpTimeMs(): Long {
        return ManagementFactory.getRuntimeMXBean().uptime
    }

    fun inspectProcFsStatus(): Map<String, String> {
        val info = mutableMapOf<String, String>()
        val memInfoFile = File("/proc/meminfo")
        if (memInfoFile.exists()) {
            memInfoFile.useLines { lines ->
                lines.take(5).forEach { line ->
                    val parts = line.split(":")
                    if (parts.size == 2) {
                        info[parts[0].trim()] = parts[1].trim()
                    }
                }
            }
        }
        return info
    }
}
