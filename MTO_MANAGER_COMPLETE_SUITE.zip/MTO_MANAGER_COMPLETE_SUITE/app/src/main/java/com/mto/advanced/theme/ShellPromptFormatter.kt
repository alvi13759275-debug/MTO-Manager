package com.mto.advanced.theme

class ShellPromptFormatter {

    enum class PromptStyle {
        MINIMAL,
        POWERLINE,
        GIT_AWARE,
        VERBOSE
    }

    fun generatePs1Prompt(
        username: String,
        hostname: String,
        currentPath: String,
        gitBranch: String? = null,
        style: PromptStyle = PromptStyle.POWERLINE
    ): String {
        val sanitizedPath = currentPath.replace(System.getProperty("user.home") ?: "", "~")

        return when (style) {
            PromptStyle.MINIMAL -> "\\[\\e[1;32m\\]$sanitizedPath\\[\\e[0m\\] \\$ "
            PromptStyle.POWERLINE -> {
                val branchPart = if (!gitBranch.isNullOrEmpty()) " \uE0A0 $gitBranch" else ""
                "\\[\\e[1;34m\\]$username@$hostname\\[\\e[0m\\]:\\[\\e[1;33m\\]$sanitizedPath\\[\\e[1;35m\\]$branchPart\\[\\e[0m\\]\\$ "
            }
            PromptStyle.GIT_AWARE -> {
                val gitInfo = if (!gitBranch.isNullOrEmpty()) " (git: $gitBranch)" else ""
                "\\[\\e[32m\\]$username\\[\\e[0m\\] in \\[\\e[36m\\]$sanitizedPath\\[\\e[33m\\]$gitInfo\\[\\e[0m\\]\n\u276F "
            }
            PromptStyle.VERBOSE -> {
                "\\[\\e[1;31m\\][MTO-SH]\\[\\e[0m\\] \\[\\e[1;32m\\]$username@$hostname\\[\\e[0m\\]:\\[\\e[1;34m\\]$sanitizedPath\\[\\e[0m\\]\\$ "
            }
        }
    }

    fun formatAnsiColor(text: String, colorCode: Int): String {
        return "\u001B[${colorCode}m$text\u001B[0m"
    }
}
