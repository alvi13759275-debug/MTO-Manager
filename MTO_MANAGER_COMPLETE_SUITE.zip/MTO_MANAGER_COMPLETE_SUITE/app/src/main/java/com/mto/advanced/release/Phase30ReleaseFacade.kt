package com.mto.advanced.release

import java.io.File

class Phase30ReleaseFacade private constructor(
    private val workspaceDir: File
) {
    val httpFileServer = LocalHttpFileServer(hostPort = 8080, serveDirectory = workspaceDir)
    val taskAutomation = ScheduledTaskAutomation()
    val releaseAssembly = MasterReleaseAssembly()

    fun launchFileBridgeServer(): Boolean {
        return httpFileServer.startServer()
    }

    fun stopFileBridgeServer() {
        httpFileServer.stopServer()
    }

    fun finalizeMasterRelease(): MasterBuildSummary {
        return releaseAssembly.generateBuildManifest(workspaceDir)
    }

    fun shutdown() {
        stopFileBridgeServer()
        taskAutomation.shutdownScheduler()
    }

    companion object {
        @Volatile
        private var instance: Phase30ReleaseFacade? = null

        fun getInstance(workspaceDir: File): Phase30ReleaseFacade {
            return instance ?: synchronized(this) {
                instance ?: Phase30ReleaseFacade(workspaceDir).also { instance = it }
            }
        }
    }
}
