package com.mto.advanced.extension

import java.io.File

class PerformanceOptimizerEngine {

    fun optimizeWorkspaceMemory(workspaceDir: File): Long {
        var reclaimedBytes = 0L
        if (!workspaceDir.exists()) return reclaimedBytes

        val tempFiles = workspaceDir.walkTopDown().filter { file ->
            file.name.startsWith("temp_") || file.name.endsWith(".tmp") || file.name.endsWith(".bak")
        }

        tempFiles.forEach { file ->
            val size = file.length()
            if (file.delete()) {
                reclaimedBytes += size
            }
        }

        System.gc() // Trigger System Garbage Collector
        return reclaimedBytes
    }
}
