package com.mto.advanced.tools

import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LogBackupEngine(private val logDirectory: File) {

    init {
        if (!logDirectory.exists()) {
            logDirectory.mkdirs()
        }
    }

    fun appendSystemLog(tag: String, message: String) {
        val timeStamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        val logFile = File(logDirectory, "mto_system_activity.log")
        val formattedEntry = "[$timeStamp] [$tag] : $message\n"
        logFile.appendText(formattedEntry)
    }

    fun purgeOldLogs(maxSizeBytes: Long = 5 * 1024 * 1024): Boolean {
        val logFile = File(logDirectory, "mto_system_activity.log")
        if (logFile.exists() && logFile.length() > maxSizeBytes) {
            return logFile.delete()
        }
        return false
    }
}
