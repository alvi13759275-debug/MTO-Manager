package com.mto.advanced.sandbox

import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class Phase28SandboxFacade private constructor(
    private val workspaceDir: File
) {
    val vulnScanner = VulnerabilityScanner()
    val secretExtractor = HardcodedSecretExtractor()
    val behaviorAnalyzer = BehavioralAnalyzer()

    private val listeners = CopyOnWriteArrayList<SandboxEventListener>()
    private val threadPool = Executors.newFixedThreadPool(4)
    private val activeTasks = ConcurrentHashMap<String, AtomicBoolean>()

    data class SecurityAnalysisReport(
        val taskId: String,
        val vulnerabilities: List<VulnerabilityIssue>,
        val secretsFound: List<DetectedSecret>,
        val behavior: BehavioralProfile,
        val executionTimeMs: Long
    )

    interface SandboxEventListener {
        fun onProgressUpdate(taskId: String, stepMessage: String, percent: Int)
        fun onAnalysisCompleted(report: SecurityAnalysisReport)
    }

    fun addListener(listener: SandboxEventListener) { listeners.add(listener) }
    fun removeListener(listener: SandboxEventListener) { listeners.remove(listener) }

    fun runSecurityAnalysis(taskId: String = UUID.randomUUID().toString(), targetFile: File) {
        val isRunning = AtomicBoolean(true)
        activeTasks[taskId] = isRunning

        threadPool.execute {
            val startTime = System.currentTimeMillis()

            notifyProgress(taskId, "Scanning configuration vulnerabilities...", 25)
            val vulns = vulnScanner.scanArtifact(targetFile)

            notifyProgress(taskId, "Extracting hardcoded parameters & patterns...", 60)
            val secrets = secretExtractor.extractSecrets(targetFile)

            notifyProgress(taskId, "Evaluating permission behavioral profiles...", 90)
            val profile = behaviorAnalyzer.analyzeBehavior(targetFile)

            notifyProgress(taskId, "Analysis Completed Successfully", 100)

            val report = SecurityAnalysisReport(
                taskId = taskId,
                vulnerabilities = vulns,
                secretsFound = secrets,
                behavior = profile,
                executionTimeMs = System.currentTimeMillis() - startTime
            )

            listeners.forEach { it.onAnalysisCompleted(report) }
            activeTasks.remove(taskId)
        }
    }

    private fun notifyProgress(taskId: String, message: String, percent: Int) {
        listeners.forEach { it.onProgressUpdate(taskId, message, percent) }
    }

    fun shutdown() { threadPool.shutdown() }

    companion object {
        @Volatile
        private var instance: Phase28SandboxFacade? = null

        fun getInstance(workspaceDir: File): Phase28SandboxFacade {
            return instance ?: synchronized(this) {
                instance ?: Phase28SandboxFacade(workspaceDir).also { instance = it }
            }
        }
    }
}
