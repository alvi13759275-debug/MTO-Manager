package com.mto.advanced.pipeline

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.PriorityBlockingQueue
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * M.T.O MANAGER - PHASE 23 BATCH PIPELINE & UI ORCHESTRATION ENGINE
 * Enterprise Grade Multi-Task Queue Controller, Multi-Threaded Batch Operations Engine,
 * System Event Bus & Real-Time Thread Synchronization Infrastructure.
 */
class Phase23BatchPipelineEngine private constructor(
    private val maxConcurrentWorkerThreads: Int = 8
) {

    enum class TaskPriority {
        LOW,
        NORMAL,
        HIGH,
        CRITICAL
    }

    enum class TaskState {
        QUEUED,
        RUNNING,
        PAUSED,
        CANCELLED,
        COMPLETED,
        FAILED
    }

    enum class BatchOperationType {
        BULK_HASH_CALCULATION,
        BULK_FILE_RENAME,
        BULK_ENCRYPTION_DECRYPTION,
        BULK_FILE_DELETION
    }

    data class PipelineTaskWrapper(
        val taskId: String = UUID.randomUUID().toString(),
        val taskName: String,
        val priority: TaskPriority = TaskPriority.NORMAL,
        val creationTimeMs: Long = System.currentTimeMillis(),
        val runnableWork: (progressCallback: (Int, String) -> Unit) -> Unit
    ) : Comparable<PipelineTaskWrapper> {
        override fun compareTo(other: PipelineTaskWrapper): Int {
            val priorityCompare = other.priority.ordinal.compareTo(this.priority.ordinal)
            return if (priorityCompare != 0) priorityCompare else this.creationTimeMs.compareTo(other.creationTimeMs)
        }
    }

    data class TaskProgressState(
        val taskId: String,
        val taskName: String,
        val state: TaskState,
        val percentProgress: Int,
        val statusMessage: String,
        val errorDetails: String? = null
    )

    data class BatchJobConfig(
        val jobId: String = UUID.randomUUID().toString(),
        val operationType: BatchOperationType,
        val targetFiles: List<File>,
        val parameterMap: Map<String, String> = emptyMap()
    )

    data class BatchJobResult(
        val jobId: String,
        val totalProcessed: Int,
        val failedCount: Int,
        val executionLogs: List<String>,
        val executionTimeMs: Long
    )

    interface PipelineEventListener {
        fun onTaskStateChanged(state: TaskProgressState)
        fun onBatchJobCompleted(result: BatchJobResult)
    }

    private val taskQueue = PriorityBlockingQueue<PipelineTaskWrapper>()
    private val threadPool = Executors.newFixedThreadPool(maxConcurrentWorkerThreads)
    private val listeners = CopyOnWriteArrayList<PipelineEventListener>()
    private val activeTaskMap = ConcurrentHashMap<String, TaskProgressState>()
    private val cancellationFlags = ConcurrentHashMap<String, AtomicBoolean>()
    private val isEngineRunning = AtomicBoolean(true)

    init {
        startQueueDispatcher()
    }

    fun addListener(listener: PipelineEventListener) {
        listeners.add(listener)
    }

    fun removeListener(listener: PipelineEventListener) {
        listeners.remove(listener)
    }

    // =========================================================================
    // MULTI-TASK QUEUE DISPATCHER ARCHITECTURE
    // =========================================================================

    private fun startQueueDispatcher() {
        Executors.newSingleThreadExecutor().execute {
            while (isEngineRunning.get()) {
                try {
                    val task = taskQueue.take()
                    if (cancellationFlags[task.taskId]?.get() == true) {
                        updateTaskState(
                            TaskProgressState(
                                taskId = task.taskId,
                                taskName = task.taskName,
                                state = TaskState.CANCELLED,
                                percentProgress = 0,
                                statusMessage = "Task cancelled prior to execution."
                            )
                        )
                        continue
                    }

                    threadPool.execute {
                        executeSingleTask(task)
                    }
                } catch (e: InterruptedException) {
                    Thread.currentThread().interrupt()
                    break
                }
            }
        }
    }

    fun submitTask(
        taskName: String,
        priority: TaskPriority = TaskPriority.NORMAL,
        work: (progressCallback: (Int, String) -> Unit) -> Unit
    ): String {
        val taskWrapper = PipelineTaskWrapper(
            taskName = taskName,
            priority = priority,
            runnableWork = work
        )
        cancellationFlags[taskWrapper.taskId] = AtomicBoolean(false)
        
        updateTaskState(
            TaskProgressState(
                taskId = taskWrapper.taskId,
                taskName = taskWrapper.taskName,
                state = TaskState.QUEUED,
                percentProgress = 0,
                statusMessage = "Queued in task pipeline."
            )
        )

        taskQueue.put(taskWrapper)
        return taskWrapper.taskId
    }

    private fun executeSingleTask(task: PipelineTaskWrapper) {
        val isCancelled = cancellationFlags[task.taskId] ?: AtomicBoolean(false)
        updateTaskState(
            TaskProgressState(
                taskId = task.taskId,
                taskName = task.taskName,
                state = TaskState.RUNNING,
                percentProgress = 0,
                statusMessage = "Started processing..."
            )
        )

        try {
            task.runnableWork { percent, message ->
                if (isCancelled.get()) {
                    throw RuntimeException("TASK_CANCELLED_BY_USER")
                }
                updateTaskState(
                    TaskProgressState(
                        taskId = task.taskId,
                        taskName = task.taskName,
                        state = TaskState.RUNNING,
                        percentProgress = percent,
                        statusMessage = message
                    )
                )
            }

            if (!isCancelled.get()) {
                updateTaskState(
                    TaskProgressState(
                        taskId = task.taskId,
                        taskName = task.taskName,
                        state = TaskState.COMPLETED,
                        percentProgress = 100,
                        statusMessage = "Execution completed successfully."
                    )
                )
            }
        } catch (e: Exception) {
            if (e.message == "TASK_CANCELLED_BY_USER") {
                updateTaskState(
                    TaskProgressState(
                        taskId = task.taskId,
                        taskName = task.taskName,
                        state = TaskState.CANCELLED,
                        percentProgress = 0,
                        statusMessage = "Task cancelled by user."
                    )
                )
            } else {
                updateTaskState(
                    TaskProgressState(
                        taskId = task.taskId,
                        taskName = task.taskName,
                        state = TaskState.FAILED,
                        percentProgress = 0,
                        statusMessage = "Execution failed.",
                        errorDetails = e.localizedMessage
                    )
                )
            }
        } finally {
            cancellationFlags.remove(task.taskId)
        }
    }

    // =========================================================================
    // HIGH-PERFORMANCE BATCH FILE OPERATIONS ENGINE
    // =========================================================================

    fun executeBatchJob(config: BatchJobConfig) {
        submitTask("Batch Job: ${config.operationType.name}", TaskPriority.HIGH) { progress ->
            val logs = mutableListOf<String>()
            val startTime = System.currentTimeMillis()
            val totalFiles = config.targetFiles.size
            val processedCounter = AtomicInteger(0)
            val failedCounter = AtomicInteger(0)

            logs.add("Initiating Batch Job ID: ${config.jobId} for $totalFiles files.")

            when (config.operationType) {
                BatchOperationType.BULK_HASH_CALCULATION -> {
                    config.targetFiles.forEachIndexed { index, file ->
                        if (file.exists() && file.isFile) {
                            val hash = computeSha256(file)
                            logs.add("FILE: ${file.name} | SHA-256: $hash")
                            processedCounter.incrementAndGet()
                        } else {
                            failedCounter.incrementAndGet()
                            logs.add("ERROR: File missing ${file.path}")
                        }
                        val percent = (((index + 1).toDouble() / totalFiles) * 100).toInt()
                        progress(percent, "Processed ${index + 1}/$totalFiles files...")
                    }
                }
                BatchOperationType.BULK_FILE_RENAME -> {
                    val prefix = config.parameterMap["prefix"] ?: "MTO_"
                    config.targetFiles.forEachIndexed { index, file ->
                        if (file.exists()) {
                            val newName = "${prefix}${System.currentTimeMillis()}_${file.name}"
                            val newFile = File(file.parentFile, newName)
                            if (file.renameTo(newFile)) {
                                processedCounter.incrementAndGet()
                                logs.add("RENAMED: ${file.name} -> $newName")
                            } else {
                                failedCounter.incrementAndGet()
                                logs.add("FAILED RENAME: ${file.name}")
                            }
                        }
                        val percent = (((index + 1).toDouble() / totalFiles) * 100).toInt()
                        progress(percent, "Renamed ${index + 1}/$totalFiles files...")
                    }
                }
                BatchOperationType.BULK_ENCRYPTION_DECRYPTION -> {
                    val key = config.parameterMap["key"]?.toByteArray() ?: "MTO_DEFAULT_KEY".toByteArray()
                    config.targetFiles.forEachIndexed { index, file ->
                        if (file.exists() && file.isFile) {
                            val outFile = File(file.parentFile, "${file.name}.enc")
                            xorEncryptDecrypt(file, outFile, key)
                            processedCounter.incrementAndGet()
                            logs.add("ENCRYPTED: ${file.name} -> ${outFile.name}")
                        } else {
                            failedCounter.incrementAndGet()
                        }
                        val percent = (((index + 1).toDouble() / totalFiles) * 100).toInt()
                        progress(percent, "Encrypted ${index + 1}/$totalFiles files...")
                    }
                }
                BatchOperationType.BULK_FILE_DELETION -> {
                    config.targetFiles.forEachIndexed { index, file ->
                        if (file.exists()) {
                            if (file.deleteRecursively()) {
                                processedCounter.incrementAndGet()
                                logs.add("DELETED: ${file.name}")
                            } else {
                                failedCounter.incrementAndGet()
                                logs.add("FAILED DELETION: ${file.name}")
                            }
                        }
                        val percent = (((index + 1).toDouble() / totalFiles) * 100).toInt()
                        progress(percent, "Deleted ${index + 1}/$totalFiles files...")
                    }
                }
            }

            val batchResult = BatchJobResult(
                jobId = config.jobId,
                totalProcessed = processedCounter.get(),
                failedCount = failedCounter.get(),
                executionLogs = logs,
                executionTimeMs = System.currentTimeMillis() - startTime
            )

            listeners.forEach { it.onBatchJobCompleted(batchResult) }
        }
    }

    private fun computeSha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { fis ->
            val buffer = ByteArray(65536)
            var bytesRead: Int
            while (fis.read(buffer).also { bytesRead = it } != -1) {
                digest.update(buffer, 0, bytesRead)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun xorEncryptDecrypt(inputFile: File, outputFile: File, key: ByteArray) {
        FileInputStream(inputFile).use { fis ->
            FileOutputStream(outputFile).use { fos ->
                val buffer = ByteArray(65536)
                var bytesRead: Int
                var keyIndex = 0
                while (fis.read(buffer).also { bytesRead = it } != -1) {
                    for (i in 0 until bytesRead) {
                        buffer[i] = (buffer[i].toInt() xor key[keyIndex % key.size].toInt()).toByte()
                        keyIndex++
                    }
                    fos.write(buffer, 0, bytesRead)
                }
            }
        }
    }

    private fun updateTaskState(state: TaskProgressState) {
        activeTaskMap[state.taskId] = state
        listeners.forEach { it.onTaskStateChanged(state) }
    }

    fun cancelTask(taskId: String): Boolean {
        val flag = cancellationFlags[taskId]
        if (flag != null) {
            flag.set(true)
            return true
        }
        return false
    }

    fun getActiveTaskStates(): List<TaskProgressState> {
        return activeTaskMap.values.toList()
    }

    fun shutdownEngine() {
        isEngineRunning.set(false)
        threadPool.shutdown()
    }

    companion object {
        @Volatile
        private var instance: Phase23BatchPipelineEngine? = null

        fun getInstance(): Phase23BatchPipelineEngine {
            return instance ?: synchronized(this) {
                instance ?: Phase23BatchPipelineEngine().also { instance = it }
            }
        }
    }
}
