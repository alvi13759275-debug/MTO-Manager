package com.mto.advanced.tools

import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

data class PortScanResult(
    val port: Int,
    val isOpen: Boolean,
    val serviceName: String
)

class NetworkScannerEngine {

    private val commonPorts = mapOf(
        21 to "FTP",
        22 to "SSH",
        80 to "HTTP",
        443 to "HTTPS",
        8080 to "MTO-HTTP-BRIDGE",
        9090 to "METRICS"
    )

    fun scanHostPorts(host: String, timeoutMs: Int = 300, onComplete: (List<PortScanResult>) -> Unit) {
        val threadPool = Executors.newFixedThreadPool(10)
        val results = ConcurrentHashMap<Int, PortScanResult>()

        commonPorts.forEach { (port, service) ->
            threadPool.execute {
                var isOpen = false
                try {
                    Socket().use { socket ->
                        socket.connect(InetSocketAddress(host, port), timeoutMs)
                        isOpen = true
                    }
                } catch (_: Exception) {
                    isOpen = false
                }
                results[port] = PortScanResult(port, isOpen, service)
            }
        }

        threadPool.shutdown()
        Thread {
            while (!threadPool.isTerminated) {
                Thread.sleep(50)
            }
            onComplete(results.values.sortedBy { it.port })
        }.start()
    }
}
