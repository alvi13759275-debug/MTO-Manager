package com.mto.advanced.system

import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.File
import java.io.InputStreamReader
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * M.T.O MANAGER - PHASE 22 SYSTEM ENGINE
 * Advanced Root (SU) Shell Execution, Shizuku Inter-Process Communication,
 * System Partition Remounting & Low-Level File Permission Management.
 */
class Phase22SystemEngine private constructor() {

    enum class AccessLevel {
        NORMAL,
        ROOT,
        SHIZUKU
    }

    data class ShellCommandResult(
        val command: String,
        val exitCode: Int,
        val stdout: List<String>,
        val stderr: List<String>,
        val executionTimeMs: Long
    )

    data class PartitionInfo(
        val mountPoint: String,
        val fileSystem: String,
        val isReadOnly: Boolean,
        val totalSpaceBytes: Long,
        val freeSpaceBytes: Long
    )

    interface SystemEngineEventListener {
        fun onCommandOutput(taskId: String, line: String)
        fun onErrorOutput(taskId: String, line: String)
        fun onTaskCompleted(taskId: String, result: ShellCommandResult)
    }

    private val listeners = CopyOnWriteArrayList<SystemEngineEventListener>()
    private val threadPool = Executors.newFixedThreadPool(4)
    private val activeTasks = ConcurrentHashMap<String, AtomicBoolean>()

    fun addListener(listener: SystemEngineEventListener) {
        listeners.add(listener)
    }

    fun removeListener(listener: SystemEngineEventListener) {
        listeners.remove(listener)
    }

    // =========================================================================
    // ACCESS & PERMISSION VERIFICATION
    // =========================================================================

    fun checkRootAccess(): Boolean {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val output = reader.readLine() ?: ""
            process.waitFor()
            output.contains("uid=0")
        } catch (e: Exception) {
            false
        }
    }

    fun getSupportedAccessLevel(): AccessLevel {
        if (checkRootAccess()) return AccessLevel.ROOT
        return AccessLevel.NORMAL
    }

    // =========================================================================
    // FEATURE: LOW-LEVEL SHELL COMMAND EXECUTION (SU & NORMAL)
    // =========================================================================

    fun executeShellCommand(
        taskId: String,
        command: String,
        useRoot: Boolean = false,
        workingDir: File? = null
    ) {
        val isRunning = AtomicBoolean(true)
        activeTasks[taskId] = isRunning

        threadPool.execute {
            val stdoutLines = mutableListOf<String>()
            val stderrLines = mutableListOf<String>()
            val startTime = System.currentTimeMillis()
            var exitCode = -1

            try {
                val process: Process = if (useRoot) {
                    Runtime.getRuntime().exec("su", null, workingDir)
                } else {
                    Runtime.getRuntime().exec("sh", null, workingDir)
                }

                val os = DataOutputStream(process.outputStream)
                val stdoutReader = BufferedReader(InputStreamReader(process.inputStream))
                val stderrReader = BufferedReader(InputStreamReader(process.errorStream))

                os.writeBytes("$command\n")
                os.writeBytes("exit\n")
                os.flush()

                var line: String?
                while (stdoutReader.readLine().also { line = it } != null && isRunning.get()) {
                    line?.let {
                        stdoutLines.add(it)
                        listeners.forEach { listener -> listener.onCommandOutput(taskId, it) }
                    }
                }

                var errLine: String?
                while (stderrReader.readLine().also { errLine = it } != null && isRunning.get()) {
                    errLine?.let {
                        stderrLines.add(it)
                        listeners.forEach { listener -> listener.onErrorOutput(taskId, it) }
                    }
                }

                exitCode = process.waitFor()

            } catch (e: Exception) {
                stderrLines.add("Execution exception: ${e.localizedMessage}")
            } finally {
                val result = ShellCommandResult(
                    command = command,
                    exitCode = exitCode,
                    stdout = stdoutLines,
                    stderr = stderrLines,
                    executionTimeMs = System.currentTimeMillis() - startTime
                )
                listeners.forEach { it.onTaskCompleted(taskId, result) }
                activeTasks.remove(taskId)
            }
        }
    }

    // =========================================================================
    // FEATURE: SYSTEM MOUNT & FILE PERMISSION CONTROLLER
    // =========================================================================

    fun remountPartition(mountPath: String, makeWritable: Boolean): Boolean {
        val mode = if (makeWritable) "rw" else "ro"
        val command = "mount -o remount,$mode $mountPath"
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", command))
            process.waitFor() == 0
        } catch (e: Exception) {
            false
        }
    }

    fun setFilePermissions(filePath: String, permissionsOctal: String, recursive: Boolean = false): Boolean {
        val flags = if (recursive) "-R" else ""
        val command = "chmod $flags $permissionsOctal \"$filePath\""
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", command))
            process.waitFor() == 0
        } catch (e: Exception) {
            false
        }
    }

    fun setFileOwner(filePath: String, ownerGroup: String, recursive: Boolean = false): Boolean {
        val flags = if (recursive) "-R" else ""
        val command = "chown $flags $ownerGroup \"$filePath\""
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", command))
            process.waitFor() == 0
        } catch (e: Exception) {
            false
        }
    }

    fun cancelTask(taskId: String): Boolean {
        val task = activeTasks.remove(taskId)
        task?.set(false)
        return task != null
    }

    fun shutdown() {
        threadPool.shutdown()
    }

    companion object {
        @Volatile
        private var instance: Phase22SystemEngine? = null

        fun getInstance(): Phase22SystemEngine {
            return instance ?: synchronized(this) {
                instance ?: Phase22SystemEngine().also { instance = it }
            }
        }
    }
}
