package com.mto.advanced.release

import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

data class AutomatedTaskSpec(
    val taskId: String,
    val description: String,
    val intervalSeconds: Long,
    val action: () -> Unit
)

class ScheduledTaskAutomation {

    private val scheduler = Executors.newScheduledThreadPool(2)

    fun scheduleRecurringTask(task: AutomatedTaskSpec) {
        scheduler.scheduleAtFixedRate(
            {
                try {
                    task.action()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            },
            0,
            task.intervalSeconds,
            TimeUnit.SECONDS
        )
    }

    fun shutdownScheduler() {
        scheduler.shutdown()
    }
}
