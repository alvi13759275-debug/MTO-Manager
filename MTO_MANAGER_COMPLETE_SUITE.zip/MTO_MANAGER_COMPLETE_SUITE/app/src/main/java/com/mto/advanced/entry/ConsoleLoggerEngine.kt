package com.mto.advanced.entry

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class LogLevel { INFO, WARN, ERROR, DEBUG, TRACE }

object ConsoleLoggerEngine {
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)
    var isDebugEnabled: Boolean = true

    fun log(level: LogLevel, tag: String, message: String, throwable: Throwable? = null) {
        val timestamp = dateFormat.format(Date())
        val colorCode = when (level) {
            LogLevel.INFO -> "\u001B[32m"  // Green
            LogLevel.WARN -> "\u001B[33m"  // Yellow
            LogLevel.ERROR -> "\u001B[31m" // Red
            LogLevel.DEBUG -> "\u001B[36m" // Cyan
            LogLevel.TRACE -> "\u001B[35m" // Purple
        }
        val resetCode = "\u001B[0m"
        println("$colorCode[$timestamp] [${level.name}] [$tag] $message$resetCode")
        throwable?.printStackTrace()
    }

    fun info(tag: String, message: String) = log(LogLevel.INFO, tag, message)
    fun warn(tag: String, message: String) = log(LogLevel.WARN, tag, message)
    fun error(tag: String, message: String, t: Throwable? = null) = log(LogLevel.ERROR, tag, message, t)
    fun debug(tag: String, message: String) { if (isDebugEnabled) log(LogLevel.DEBUG, tag, message) }

    fun printBanner() {
        println("""
        ================================================================
        *   M.T.O MANAGER - PHASE 26 ENTERPRISE CLI ORCHESTRATOR       *
        *   Full Modular Infrastructure & System Health Controller     *
        ================================================================
        """.trimIndent())
    }
}
