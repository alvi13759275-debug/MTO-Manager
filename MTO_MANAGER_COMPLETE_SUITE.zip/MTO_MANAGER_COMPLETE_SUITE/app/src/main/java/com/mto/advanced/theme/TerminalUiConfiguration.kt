package com.mto.advanced.theme

class TerminalUiConfiguration {

    data class UiSettings(
        val cursorBlinkRateMs: Long = 500L,
        val backgroundOpacity: Float = 0.95f,
        val scrollbackHistoryLines: Int = 5000,
        val enableVibrationFeedback: Boolean = true,
        val keepScreenOn: Boolean = true
    )

    private var currentSettings = UiSettings()

    fun updateSettings(newSettings: UiSettings) {
        currentSettings = newSettings
    }

    fun getSettings(): UiSettings = currentSettings
}
