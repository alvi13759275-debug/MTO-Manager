package com.mto.advanced.bypass

import java.io.File
import java.io.RandomAccessFile

enum class PackerType(val label: String) {
    JIAGU_360("360 Jiagu / IJag"),
    TENCENT_LEGU("Tencent Legu / SecShell"),
    BAIDU_PROTECT("Baidu Shield"),
    BANG_CLEANER("Bangcle / Secneo"),
    UNKNOWN_PACKER("Generic Dynamic Packer"),
    UNPROTECTED("None (Standard DEX/APK)")
}

data class PackerAnalysisReport(
    val file: File,
    val detectedPacker: PackerType,
    val hasCorruptedHeader: Boolean,
    val isAntiDebugPresent: Boolean,
    val detectedOpcodeJunkRatio: Float
)

class PackerDetectionEngine {

    fun analyzeFile(targetFile: File): PackerAnalysisReport {
        if (!targetFile.exists() || !targetFile.isFile) {
            return PackerAnalysisReport(targetFile, PackerType.UNPROTECTED, false, false, 0.0f)
        }

        var corruptedHeader = false
        var packerType = PackerType.UNPROTECTED

        try {
            RandomAccessFile(targetFile, "r").use { raf ->
                if (raf.length() >= 0x70) {
                    val magic = ByteArray(4)
                    raf.readFully(magic)
                    val magicStr = String(magic)

                    if (magicStr == "dex\n") {
                        raf.seek(36)
                        val headerSize = Integer.reverseBytes(raf.readInt())
                        if (headerSize != 0x70) {
                            corruptedHeader = true
                        }
                    }
                }
            }

            val lowerName = targetFile.name.lowercase()
            packerType = when {
                lowerName.contains("jiagu") || lowerName.contains("ijag") -> PackerType.JIAGU_360
                lowerName.contains("legu") || lowerName.contains("secshell") -> PackerType.TENCENT_LEGU
                lowerName.contains("baidu") -> PackerType.BAIDU_PROTECT
                lowerName.contains("bang") -> PackerType.BANG_CLEANER
                corruptedHeader -> PackerType.UNKNOWN_PACKER
                else -> PackerType.UNPROTECTED
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }

        return PackerAnalysisReport(
            file = targetFile,
            detectedPacker = packerType,
            hasCorruptedHeader = corruptedHeader,
            isAntiDebugPresent = packerType != PackerType.UNPROTECTED,
            detectedOpcodeJunkRatio = if (corruptedHeader) 0.18f else 0.0f
        )
    }
}
