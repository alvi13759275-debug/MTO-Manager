package com.mto.advanced.dashboard

enum class TerminalTheme(val nameTitle: String, val primaryColor: String, val accentColor: String, val reset: String) {
    CYBERPUNK("Cyberpunk Green", "\u001B[32m", "\u001B[36m", "\u001B[0m"),
    MATRIX("Matrix Red/Green", "\u001B[31m", "\u001B[32m", "\u001B[0m"),
    NEON_BLUE("Neon Blue", "\u001B[34m", "\u001B[35m", "\u001B[0m"),
    CLASSIC_MONO("Classic Mono", "\u001B[37m", "\u001B[33m", "\u001B[0m")
}

class TerminalThemeEngine {
    var activeTheme: TerminalTheme = TerminalTheme.CYBERPUNK

    fun colorize(text: String, useAccent: Boolean = false): String {
        val color = if (useAccent) activeTheme.accentColor else activeTheme.primaryColor
        return "$color$text${activeTheme.reset}"
    }
}
