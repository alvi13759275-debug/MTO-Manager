package com.mto.advanced.dashboard

import com.mto.advanced.release.Phase30ReleaseFacade
import com.mto.advanced.storage.Phase29StorageFacade
import com.mto.advanced.extension.PerformanceOptimizerEngine
import com.mto.advanced.extension.DynamicPluginManager
import java.io.File
import java.lang.management.ManagementFactory

class MasterCliDashboard(private val workspaceDir: File) {

    private val themeEngine = TerminalThemeEngine()
    private val storageFacade = Phase29StorageFacade.getInstance(workspaceDir)
    private val releaseFacade = Phase30ReleaseFacade.getInstance(workspaceDir)
    private val optimizerEngine = PerformanceOptimizerEngine()
    private val pluginManager = DynamicPluginManager(workspaceDir)

    fun renderHeaderBanner() {
        val banner = """
            ====================================================================
               __  __   _____   ____    __  __                          _____  
              |  \/  | |_   _| / __ \  |  \/  |                        |  __ \ 
              | \  / |   | |  | |  | | | \  / |  __ _  _ __   __ _  __ _| |__) |
              | |\/| |   | |  | |  | | | |\/| | / _` || '_ \ / _` |/ _` |  _  / 
              | |  | |   | |  | |__| | | |  | || (_| || | | | (_| | (_| | | \ \ 
              |_|  |_|   |_|   \____/  |_|  |_| \__,_||_| |_|\__,_|\__, |_|  \_\
                                                                    __/ |      
                                                                   |___/       
            ====================================================================
            [ M.T.O MANAGER - ENTERPRISE ORCHESTRATION & CONTROL SUITE ]
            ====================================================================
        """.trimIndent()
        println(themeEngine.colorize(banner, false))
    }

    fun displaySystemStats() {
        val runtime = Runtime.getRuntime()
        val totalMemoryMb = runtime.totalMemory() / (1024 * 1024)
        val freeMemoryMb = runtime.freeMemory() / (1024 * 1024)
        val usedMemoryMb = totalMemoryMb - freeMemoryMb

        println(themeEngine.colorize(">>> REAL-TIME SYSTEM MONITOR <<<", true))
        println("Active Theme    : ${themeEngine.activeTheme.nameTitle}")
        println("Memory Allocated: ${usedMemoryMb}MB / ${totalMemoryMb}MB")
        println("Workspace Path  : ${workspaceDir.absolutePath}")
        println("Active Modules  : 30 Integrated Phases + 2 Extensions")
        println("--------------------------------------------------------------------")
    }

    fun executeQuickOptimization() {
        println(themeEngine.colorize("[*] Running Workspace Cache Optimization...", true))
        val reclaimedBytes = optimizerEngine.optimizeWorkspaceMemory(workspaceDir)
        println(themeEngine.colorize("[+] Optimization Complete. Reclaimed Memory: ${reclaimedBytes / 1024} KB", false))
    }

    fun launchFileBridge() {
        println(themeEngine.colorize("[*] Starting Local HTTP File Bridge on Port 8080...", true))
        val success = releaseFacade.launchFileBridgeServer()
        if (success) {
            println(themeEngine.colorize("[+] Server Active. Access via browser at http://localhost:8080", false))
        } else {
            println(themeEngine.colorize("[-] Failed to initialize HTTP File Bridge.", true))
        }
    }
}
