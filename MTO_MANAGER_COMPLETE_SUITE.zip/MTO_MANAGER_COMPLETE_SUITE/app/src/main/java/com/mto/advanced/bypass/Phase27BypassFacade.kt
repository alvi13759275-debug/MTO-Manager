package com.mto.advanced.bypass

import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class Phase27BypassFacade private constructor(
    private val workspaceDir: File
) {
    val detectionEngine = PackerDetectionEngine()
    val repairEngine = DexHeaderRepairEngine()
    val cleanerEngine = AntiDisassemblyCleaner()

    private val listeners = CopyOnWriteArrayList<BypassEventListener>()
    private val threadPool = Executors.newFixedThreadPool(4)
    private val activeTasks = ConcurrentHashMap<String, AtomicBoolean>()

    data class BypassJobConfig(
        val taskId: String = UUID.randomUUID().toString(),
        val inputArtifact: File,
        val outputArtifact: File,
        val autoFixHeader: Boolean = true,
        val autoStripJunk: Boolean = true
    )

    data class BypassJobResult(
        val taskId: String,
        val isSuccess: Boolean,
        val logs: List<String>,
        val executionTimeMs: Long
    )

    interface BypassEventListener {
        fun onProgressUpdate(taskId: String, stepMessage: String, percent: Int)
        fun onJobCompleted(result: BypassJobResult)
    }

    fun addListener(listener: BypassEventListener) { listeners.add(listener) }
    fun removeListener(listener: BypassEventListener) { listeners.remove(listener) }

    fun executeBypassPipeline(config: BypassJobConfig) {
        val isRunning = AtomicBoolean(true)
        activeTasks[config.taskId] = isRunning

        threadPool.execute {
            val logs = mutableListOf<String>()
            val startTime = System.currentTimeMillis()

            try {
                notifyProgress(config.taskId, "Analyzing Protection Profile...", 10)
                val report = detectionEngine.analyzeFile(config.inputArtifact)
                logs.add("Analysis Result: Packer=${report.detectedPacker.label}, CorruptedHeader=${report.hasCorruptedHeader}")

                var currentFile = config.inputArtifact
                val tempRepaired = File(workspaceDir, "repaired_${config.inputArtifact.name}")

                if (config.autoFixHeader) {
                    notifyProgress(config.taskId, "Repairing DEX Header & Offset Alignment...", 50)
                    if (repairEngine.repairHeader(currentFile, tempRepaired)) {
                        currentFile = tempRepaired
                        logs.add("Header repair executed successfully.")
                    }
                }

                if (config.autoStripJunk) {
                    notifyProgress(config.taskId, "Stripping Anti-Disassembly Opcodes...", 80)
                    cleanerEngine.stripJunkOpcodes(currentFile, config.outputArtifact)
                    logs.add("Junk code cleaning completed.")
                }

                notifyProgress(config.taskId, "Pipeline Finished Successfully", 100)
                val result = BypassJobResult(config.taskId, true, logs, System.currentTimeMillis() - startTime)
                listeners.forEach { it.onJobCompleted(result) }

            } catch (e: Exception) {
                logs.add("Pipeline Error: ${e.localizedMessage}")
                val failedResult = BypassJobResult(config.taskId, false, logs, System.currentTimeMillis() - startTime)
                listeners.forEach { it.onJobCompleted(failedResult) }
            } finally {
                activeTasks.remove(config.taskId)
            }
        }
    }

    private fun notifyProgress(taskId: String, message: String, percent: Int) {
        listeners.forEach { it.onProgressUpdate(taskId, message, percent) }
    }

    fun shutdown() { threadPool.shutdown() }

    companion object {
        @Volatile
        private var instance: Phase27BypassFacade? = null

        fun getInstance(workspaceDir: File): Phase27BypassFacade {
            return instance ?: synchronized(this) {
                instance ?: Phase27BypassFacade(workspaceDir).also { instance = it }
            }
        }
    }
}
