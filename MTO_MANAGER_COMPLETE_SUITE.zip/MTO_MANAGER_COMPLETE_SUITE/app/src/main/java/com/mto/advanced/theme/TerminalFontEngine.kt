package com.mto.advanced.theme

import java.io.File
import java.util.concurrent.ConcurrentHashMap

class TerminalFontEngine(private val fontStorageDir: File) {

    data class FontDescriptor(
        val fontName: String,
        val fontPath: String,
        val isMonospaced: Boolean,
        val fileSizeByte: Long
    )

    private val availableFonts = ConcurrentHashMap<String, FontDescriptor>()
    private var currentFontSizeSp: Float = 14.0f

    init {
        if (!fontStorageDir.exists()) {
            fontStorageDir.mkdirs()
        }
        scanFontDirectory()
    }

    fun scanFontDirectory() {
        availableFonts.clear()
        val files = fontStorageDir.listFiles() ?: arrayOf()
        for (file in files) {
            if (file.isFile && (file.name.endsWith(".ttf") || file.name.endsWith(".otf"))) {
                val fontName = file.nameWithoutExtension
                availableFonts[fontName] = FontDescriptor(
                    fontName = fontName,
                    fontPath = file.absolutePath,
                    isMonospaced = true,
                    fileSizeByte = file.length()
                )
            }
        }
    }

    fun getFontList(): List<FontDescriptor> = availableFonts.values.toList().sortedBy { it.fontName }

    fun setFontSize(sizeSp: Float): Float {
        currentFontSizeSp = sizeSp.coerceIn(8.0f, 32.0f)
        return currentFontSizeSp
    }

    fun getFontSize(): Float = currentFontSizeSp

    fun loadFontDescriptor(fontName: String): FontDescriptor? {
        return availableFonts[fontName]
    }
}
