package com.mto.advanced.storage

import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

class Phase29StorageFacade private constructor(
    private val workspaceDir: File
) {
    val searchEngine = ParallelFileSearchEngine()
    val archiveEngine = ArchiveManagerEngine()
    val checksumEngine = FileChecksumEngine()

    private val threadPool = Executors.newFixedThreadPool(4)

    data class StorageTaskResult(
        val taskId: String,
        val isSuccess: Boolean,
        val message: String,
        val executionTimeMs: Long
    )

    interface StorageEventListener {
        fun onTaskCompleted(result: StorageTaskResult)
    }

    private val listeners = CopyOnWriteArrayList<StorageEventListener>()

    fun addListener(listener: StorageEventListener) { listeners.add(listener) }
    fun removeListener(listener: StorageEventListener) { listeners.remove(listener) }

    fun runParallelSearch(query: String, rootDir: File = workspaceDir, onFound: (List<SearchResult>) -> Unit) {
        searchEngine.searchFiles(rootDir, query, onFound)
    }

    fun createArchiveAsync(taskId: String = UUID.randomUUID().toString(), files: List<File>, outputZip: File) {
        val startTime = System.currentTimeMillis()
        threadPool.execute {
            val success = archiveEngine.compressToZip(files, outputZip)
            val result = StorageTaskResult(
                taskId = taskId,
                isSuccess = success,
                message = if (success) "Zip archive created: ${outputZip.name}" else "Compression failed",
                executionTimeMs = System.currentTimeMillis() - startTime
            )
            listeners.forEach { it.onTaskCompleted(result) }
        }
    }

    fun shutdown() {
        searchEngine.shutdown()
        threadPool.shutdown()
    }

    companion object {
        @Volatile
        private var instance: Phase29StorageFacade? = null

        fun getInstance(workspaceDir: File): Phase29StorageFacade {
            return instance ?: synchronized(this) {
                instance ?: Phase29StorageFacade(workspaceDir).also { instance = it }
            }
        }
    }
}
