package com.mto.advanced.entry

import com.mto.advanced.integration.Phase25MasterSuiteEngine
import java.io.File

class SystemDiagnosticsCollector(private val masterEngine: Phase25MasterSuiteEngine) {

    data class DiagnosticSnapshot(
        val timestamp: Long,
        val workspacePath: String,
        val activePhases: Int,
        val freeMemoryMb: Long,
        val maxMemoryMb: Long,
        val totalMemoryMb: Long,
        val availableCores: Int,
        val moduleStates: Map<String, String>
    )

    fun captureSnapshot(): DiagnosticSnapshot {
        val runtime = Runtime.getRuntime()
        val report = masterEngine.getDiagnosticsReport()

        val map = mutableMapOf<String, String>()
        report.registeredModules.forEach { (k, v) -> map[k] = v.name }

        return DiagnosticSnapshot(
            timestamp = System.currentTimeMillis(),
            workspacePath = report.workspacePath,
            activePhases = report.activePhaseCount,
            freeMemoryMb = runtime.freeMemory() / (1024 * 1024),
            maxMemoryMb = runtime.maxMemory() / (1024 * 1024),
            totalMemoryMb = runtime.totalMemory() / (1024 * 1024),
            availableCores = runtime.availableProcessors(),
            moduleStates = map
        )
    }

    fun renderFormattedReport() {
        val snapshot = captureSnapshot()
        ConsoleLoggerEngine.info("Diagnostics", "=== M.T.O SYSTEM DIAGNOSTIC REPORT ===")
        println(" Workspace Path   : ${snapshot.workspacePath}")
        println(" Available Cores  : ${snapshot.availableCores}")
        println(" Memory Status    : Free ${snapshot.freeMemoryMb} MB / Total ${snapshot.totalMemoryMb} MB (Max${snapshot.maxMemoryMb} MB)")
        println(" Active Sub-Phases: ${snapshot.activePhases}")
        println(" Module Statuses  :")
        snapshot.moduleStates.forEach { (mod, state) ->
            println("   - $mod ->$state")
        }
        println("==================================================")
    }
}
