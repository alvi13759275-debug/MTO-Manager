package com.mto.advanced.cloud

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.PriorityBlockingQueue
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.zip.CRC32
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

class CloudSyncEngine private constructor(
    private val localRootStorage: File,
    private val config: EngineConfiguration
) {

    data class EngineConfiguration(
        val maxConcurrentUploads: Int = 4,
        val maxConcurrentDownloads: Int = 4,
        val defaultChunkSizeByte: Int = 2 * 1024 * 1024, // 2MB
        val enableAesEncryption: Boolean = true,
        val enableDeduplication: Boolean = true,
        val maxRetryAttempts: Int = 5,
        val connectionTimeoutMs: Long = 15000L,
        val ioBufferSize: Int = 64 * 1024
    )

    enum class SyncPriority(val level: Int) {
        BACKGROUND(1),
        LOW(2),
        NORMAL(3),
        HIGH(4),
        CRITICAL(5)
    }

    enum class StorageProviderType {
        LOCAL_MIRROR,
        REST_GATEWAY,
        S3_COMPATIBLE,
        WEBDAV,
        SFTP_NODE,
        CUSTOM_P2P_NODE
    }

    enum class TaskState {
        CREATED,
        QUEUED,
        CALCULATING_HASH,
        ENCRYPTING,
        UPLOADING,
        DOWNLOADING,
        VERIFYING_INTEGRITY,
        PAUSED,
        COMPLETED,
        FAILED,
        CANCELLED
    }

    data class ChunkMetadata(
        val chunkIndex: Int,
        val startOffset: Long,
        val chunkSize: Int,
        val rawSha256: String,
        val encryptedSha256: String?,
        var isUploaded: Boolean = false,
        var uploadTimestamp: Long = 0L,
        var retryCount: Int = 0
    )

    data class SyncTask(
        val taskId: String = UUID.randomUUID().toString(),
        val localFile: File,
        val remoteRelativePath: String,
        val providerType: StorageProviderType,
        val priority: SyncPriority = SyncPriority.NORMAL,
        val totalBytes: Long = localFile.length(),
        val transferredBytes: AtomicLong = AtomicLong(0L),
        var state: TaskState = TaskState.CREATED,
        val chunks: CopyOnWriteArrayList<ChunkMetadata> = CopyOnWriteArrayList(),
        val creationTime: Long = System.currentTimeMillis(),
        var completionTime: Long = 0L,
        var fileSha384Hash: String = "",
        var failureReason: String? = null
    ) : Comparable<SyncTask> {
        override fun compareTo(other: SyncTask): Int {
            return other.priority.level.compareTo(this.priority.level)
        }
    }

    interface SyncStateListener {
        fun onTaskStateChanged(task: SyncTask, previousState: TaskState, newState: TaskState)
        fun onProgressUpdate(task: SyncTask, transferredBytes: Long, totalBytes: Long, currentSpeedBps: Long)
        fun onError(task: SyncTask, errorThrowable: Throwable)
    }

    private val taskQueue = PriorityBlockingQueue<SyncTask>()
    private val activeTasks = ConcurrentHashMap<String, SyncTask>()
    private val taskHistory = ConcurrentHashMap<String, SyncTask>()
    private val deduplicationTable = ConcurrentHashMap<String, String>() // ChunkHash -> RemoteRef
    private val listeners = CopyOnWriteArrayList<SyncStateListener>()

    private val workerExecutor = Executors.newFixedThreadPool(config.maxConcurrentUploads)
    private val schedulerExecutor: ScheduledExecutorService = Executors.newScheduledThreadPool(2)
    private val isRunning = AtomicBoolean(true)

    private val bytesTransferredInCurrentWindow = AtomicLong(0L)
    private val currentUploadSpeedBps = AtomicLong(0L)

    init {
        if (!localRootStorage.exists()) {
            localRootStorage.mkdirs()
        }
        startSpeedCalculatorScheduler()
        startQueueProcessor()
    }

    fun registerListener(listener: SyncStateListener) {
        listeners.add(listener)
    }

    fun unregisterListener(listener: SyncStateListener) {
        listeners.remove(listener)
    }

    fun submitUploadTask(
        file: File,
        remotePath: String,
        provider: StorageProviderType,
        priority: SyncPriority = SyncPriority.NORMAL
    ): String {
        validateFileForSync(file)
        val task = SyncTask(
            localFile = file,
            remoteRelativePath = remotePath,
            providerType = provider,
            priority = priority
        )

        activeTasks[task.taskId] = task
        changeTaskState(task, TaskState.QUEUED)
        taskQueue.put(task)
        return task.taskId
    }

    private fun validateFileForSync(file: File) {
        require(file.exists()) { "Source file does not exist: ${file.absolutePath}" }
        require(file.isFile) { "Path is a directory, expected a file: ${file.absolutePath}" }
        require(file.canRead()) { "File cannot be read due to permissions: ${file.absolutePath}" }
    }

    private fun startQueueProcessor() {
        schedulerExecutor.scheduleAtFixedRate({
            if (!isRunning.get()) return@scheduleAtFixedRate

            while (taskQueue.isNotEmpty()) {
                val task = taskQueue.poll() ?: break
                workerExecutor.execute {
                    processTaskPipeline(task)
                }
            }
        }, 100, 200, TimeUnit.MILLISECONDS)
    }

    private fun processTaskPipeline(task: SyncTask) {
        try {
            changeTaskState(task, TaskState.CALCULATING_HASH)
            task.fileSha384Hash = computeFileHashSha384(task.localFile)

            partitionFileIntoChunks(task)

            if (config.enableAesEncryption) {
                changeTaskState(task, TaskState.ENCRYPTING)
            }

            changeTaskState(task, TaskState.UPLOADING)
            uploadTaskChunks(task)

            changeTaskState(task, TaskState.VERIFYING_INTEGRITY)
            verifyRemoteIntegrity(task)

            task.completionTime = System.currentTimeMillis()
            changeTaskState(task, TaskState.COMPLETED)

        } catch (e: Exception) {
            task.failureReason = e.message ?: "Unknown Execution Error"
            changeTaskState(task, TaskState.FAILED)
            notifyError(task, e)
        } finally {
            activeTasks.remove(task.taskId)
            taskHistory[task.taskId] = task
        }
    }

    private fun partitionFileIntoChunks(task: SyncTask) {
        val totalLength = task.localFile.length()
        var offset = 0L
        var chunkIdx = 0

        RandomAccessFile(task.localFile, "r").use { raf ->
            while (offset < totalLength) {
                val remaining = totalLength - offset
                val currentChunkSize = if (remaining < config.defaultChunkSizeByte) remaining.toInt() else config.defaultChunkSizeByte
                
                val chunkBuffer = ByteArray(currentChunkSize)
                raf.seek(offset)
                raf.readFully(chunkBuffer)

                val chunkHash = computeByteArraySha256(chunkBuffer)

                val chunkMetadata = ChunkMetadata(
                    chunkIndex = chunkIdx,
                    startOffset = offset,
                    chunkSize = currentChunkSize,
                    rawSha256 = chunkHash,
                    encryptedSha256 = if (config.enableAesEncryption) "ENC_$chunkHash" else null
                )

                task.chunks.add(chunkMetadata)
                offset += currentChunkSize
                chunkIdx++
            }
        }
    }

    private fun uploadTaskChunks(task: SyncTask) {
        RandomAccessFile(task.localFile, "r").use { raf ->
            for (chunk in task.chunks) {
                if (!isRunning.get() || task.state == TaskState.CANCELLED || task.state == TaskState.PAUSED) {
                    return
                }

                if (config.enableDeduplication && deduplicationTable.containsKey(chunk.rawSha256)) {
                    chunk.isUploaded = true
                    task.transferredBytes.addAndGet(chunk.chunkSize.toLong())
                    notifyProgress(task)
                    continue
                }

                val buffer = ByteArray(chunk.chunkSize)
                raf.seek(chunk.startOffset)
                raf.readFully(buffer)

                var attempts = 0
                var success = false
                while (attempts < config.maxRetryAttempts && !success) {
                    attempts++
                    try {
                        simulateProviderTransmission(task.providerType, buffer)
                        chunk.isUploaded = true
                        chunk.uploadTimestamp = System.currentTimeMillis()
                        if (config.enableDeduplication) {
                            deduplicationTable[chunk.rawSha256] = "REMOTE_REF_${chunk.rawSha256}"
                        }
                        task.transferredBytes.addAndGet(chunk.chunkSize.toLong())
                        bytesTransferredInCurrentWindow.addAndGet(chunk.chunkSize.toLong())
                        notifyProgress(task)
                        success = true
                    } catch (e: Exception) {
                        chunk.retryCount = attempts
                        if (attempts >= config.maxRetryAttempts) {
                            throw IllegalStateException("Failed uploading chunk ${chunk.chunkIndex} after $attempts attempts.")
                        }
                        Thread.sleep(1000L * attempts)
                    }
                }
            }
        }
    }

    private fun simulateProviderTransmission(provider: StorageProviderType, data: ByteArray) {
        Thread.sleep(15) // Simulate high-speed network transmission
    }

    private fun verifyRemoteIntegrity(task: SyncTask) {
        val totalUploadedChunks = task.chunks.count { it.isUploaded }
        if (totalUploadedChunks != task.chunks.size) {
            throw IllegalStateException("Chunk upload count mismatch: $totalUploadedChunks / ${task.chunks.size}")
        }
    }

    fun pauseTask(taskId: String): Boolean {
        val task = activeTasks[taskId] ?: return false
        if (task.state == TaskState.UPLOADING || task.state == TaskState.QUEUED) {
            changeTaskState(task, TaskState.PAUSED)
            return true
        }
        return false
    }

    fun resumeTask(taskId: String): Boolean {
        val task = activeTasks[taskId] ?: taskHistory[taskId] ?: return false
        if (task.state == TaskState.PAUSED) {
            changeTaskState(task, TaskState.QUEUED)
            taskQueue.put(task)
            return true
        }
        return false
    }

    fun cancelTask(taskId: String): Boolean {
        val task = activeTasks[taskId] ?: return false
        changeTaskState(task, TaskState.CANCELLED)
        activeTasks.remove(taskId)
        taskHistory[taskId] = task
        return true
    }

    private fun changeTaskState(task: SyncTask, newState: TaskState) {
        val oldState = task.state
        task.state = newState
        listeners.forEach { listener ->
            listener.onTaskStateChanged(task, oldState, newState)
        }
    }

    private fun notifyProgress(task: SyncTask) {
        val speed = currentUploadSpeedBps.get()
        listeners.forEach { listener ->
            listener.onProgressUpdate(task, task.transferredBytes.get(), task.totalBytes, speed)
        }
    }

    private fun notifyError(task: SyncTask, throwable: Throwable) {
        listeners.forEach { listener ->
            listener.onError(task, throwable)
        }
    }

    private fun computeFileHashSha384(file: File): String {
        val md = MessageDigest.getInstance("SHA-384")
        FileInputStream(file).use { fis ->
            val buf = ByteArray(config.ioBufferSize)
            var read: Int
            while (fis.read(buf).also { read = it } != -1) {
                md.update(buf, 0, read)
            }
        }
        return bytesToHex(md.digest())
    }

    private fun computeByteArraySha256(data: ByteArray): String {
        val md = MessageDigest.getInstance("SHA-256")
        md.update(data)
        return bytesToHex(md.digest())
    }

    private fun bytesToHex(bytes: ByteArray): String {
        val sb = StringBuilder()
        for (b in bytes) {
            sb.append(String.format("%02x", b))
        }
        return sb.toString()
    }

    private fun startSpeedCalculatorScheduler() {
        schedulerExecutor.scheduleAtFixedRate({
            val bytesInWindow = bytesTransferredInCurrentWindow.getAndSet(0L)
            currentUploadSpeedBps.set(bytesInWindow)
        }, 1, 1, TimeUnit.SECONDS)
    }

    fun getTaskState(taskId: String): SyncTask? {
        return activeTasks[taskId] ?: taskHistory[taskId]
    }

    fun getAllActiveTasks(): List<SyncTask> = activeTasks.values.toList()

    fun getAllCompletedTasks(): List<SyncTask> = taskHistory.values.filter { it.state == TaskState.COMPLETED }

    fun shutdown() {
        isRunning.set(false)
        workerExecutor.shutdown()
        schedulerExecutor.shutdown()
    }

    companion object {
        @Volatile
        private var INSTANCE: CloudSyncEngine? = null

        fun getInstance(storageRoot: File, config: EngineConfiguration = EngineConfiguration()): CloudSyncEngine {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: CloudSyncEngine(storageRoot, config).also { INSTANCE = it }
            }
        }
    }
}
