package com.mto.advanced.storage

import java.io.File
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors

data class SearchResult(
    val file: File,
    val sizeBytes: Long,
    val lastModified: Long
)

class ParallelFileSearchEngine {

    private val threadPool = Executors.newFixedThreadPool(8)

    fun searchFiles(
        rootDirectory: File,
        queryName: String,
        onComplete: (List<SearchResult>) -> Unit
    ) {
        val matches = ConcurrentLinkedQueue<SearchResult>()
        
        threadPool.execute {
            if (rootDirectory.exists() && rootDirectory.isDirectory) {
                traverseAndMatch(rootDirectory, queryName.lowercase(), matches)
            }
            onComplete(matches.toList())
        }
    }

    private fun traverseAndMatch(
        dir: File,
        query: String,
        results: ConcurrentLinkedQueue<SearchResult>
    ) {
        val files = dir.listFiles() ?: return
        for (file in files) {
            if (file.name.lowercase().contains(query)) {
                results.add(SearchResult(file, file.length(), file.lastModified()))
            }
            if (file.isDirectory) {
                traverseAndMatch(file, query, results)
            }
        }
    }

    fun shutdown() {
        threadPool.shutdown()
    }
}
