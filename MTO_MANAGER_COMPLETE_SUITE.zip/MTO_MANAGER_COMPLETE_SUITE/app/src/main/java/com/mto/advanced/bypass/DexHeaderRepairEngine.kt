package com.mto.advanced.bypass

import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

class DexHeaderRepairEngine {

    fun repairHeader(inputFile: File, outputFile: File): Boolean {
        if (!inputFile.exists()) return false

        return try {
            val bytes = inputFile.readBytes()
            if (bytes.size < 0x70) return false

            // Standardize Magic to "dex\n035\0"
            bytes[0] = 'd'.code.toByte()
            bytes[1] = 'e'.code.toByte()
            bytes[2] = 'x'.code.toByte()
            bytes[3] = '\n'.code.toByte()
            bytes[4] = '0'.code.toByte()
            bytes[5] = '3'.code.toByte()
            bytes[6] = '5'.code.toByte()
            bytes[7] = 0.toByte()

            // Reset Standard Header Size to 0x70 (112 Bytes)
            val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            buffer.putInt(36, 0x70)

            outputFile.writeBytes(bytes)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
