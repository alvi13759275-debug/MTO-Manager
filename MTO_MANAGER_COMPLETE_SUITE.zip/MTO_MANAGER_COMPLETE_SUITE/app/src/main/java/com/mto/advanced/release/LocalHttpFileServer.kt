package com.mto.advanced.release

import java.io.File
import java.io.OutputStream
import java.net.ServerSocket
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class LocalHttpFileServer(
    private val hostPort: Int = 8080,
    private val serveDirectory: File
) {
    private var serverSocket: ServerSocket? = null
    private val isRunning = AtomicBoolean(false)
    private val threadPool = Executors.newFixedThreadPool(4)

    fun startServer(): Boolean {
        return try {
            serverSocket = ServerSocket(hostPort)
            isRunning.set(true)

            threadPool.execute {
                while (isRunning.get()) {
                    try {
                        val clientSocket = serverSocket?.accept() ?: break
                        threadPool.execute { handleClientRequest(clientSocket) }
                    } catch (e: Exception) {
                        if (!isRunning.get()) break
                    }
                }
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun handleClientRequest(socket: java.net.Socket) {
        socket.use { client ->
            val output: OutputStream = client.getOutputStream()
            val httpResponse = """
                HTTP/1.1 200 OK
                Content-Type: text/html; charset=UTF-8
                
                <html>
                <head><title>M.T.O MANAGER - Local File Server</title></head>
                <body style="font-family: sans-serif; background: #121212; color: #00FF66; padding: 20px;">
                    <h2>M.T.O MANAGER Local File Bridge</h2>
                    <p>Serving Directory: <b>${serveDirectory.absolutePath}</b></p>
                    <hr>
                    <p>Status: Active & Synchronized</p>
                </body>
                </html>
            """.trimIndent().replace("\n", "\r\n")

            output.write(httpResponse.toByteArray())
            output.flush()
        }
    }

    fun stopServer() {
        isRunning.set(false)
        try {
            serverSocket?.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        threadPool.shutdown()
    }
}
