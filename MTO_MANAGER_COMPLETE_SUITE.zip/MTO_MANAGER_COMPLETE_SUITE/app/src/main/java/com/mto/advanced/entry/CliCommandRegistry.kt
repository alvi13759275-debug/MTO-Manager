package com.mto.advanced.entry

import com.mto.advanced.integration.Phase25MasterSuiteEngine
import com.mto.advanced.system.Phase22SystemEngine
import java.util.concurrent.ConcurrentHashMap

data class CommandSpec(
    val name: String,
    val aliases: List<String>,
    val description: String,
    val handler: (args: List<String>) -> Unit
)

class CliCommandRegistry(
    private val masterEngine: Phase25MasterSuiteEngine,
    private val diagnostics: SystemDiagnosticsCollector
) {
    private val registry = ConcurrentHashMap<String, CommandSpec>()

    init {
        registerBuiltInCommands()
    }

    fun register(command: CommandSpec) {
        registry[command.name.lowercase()] = command
        command.aliases.forEach { alias -> registry[alias.lowercase()] = command }
    }

    fun dispatch(rawInput: String) {
        val parts = rawInput.trim().split("\\s+".toRegex())
        if (parts.isEmpty() || parts[0].isEmpty()) return

        val cmdName = parts[0].lowercase()
        val args = if (parts.size > 1) parts.subList(1, parts.size) else emptyList()

        val spec = registry[cmdName]
        if (spec != null) {
            try {
                spec.handler(args)
            } catch (e: Exception) {
                ConsoleLoggerEngine.error("CliRegistry", "Failed to execute command '$cmdName'", e)
            }
        } else {
            ConsoleLoggerEngine.warn("CliRegistry", "Unknown command '$cmdName'. Type 'help' for available commands.")
        }
    }

    private fun registerBuiltInCommands() {
        register(CommandSpec(
            name = "status",
            aliases = listOf("diag", "health"),
            description = "Displays live system diagnostics and memory statistics."
        ) {
            diagnostics.renderFormattedReport()
        })

        register(CommandSpec(
            name = "root",
            aliases = listOf("su", "check-root"),
            description = "Verifies Root Superuser shell access."
        ) {
            val sysEngine = Phase22SystemEngine.getInstance()
            val hasRoot = sysEngine.checkRootAccess()
            ConsoleLoggerEngine.info("RootCheck", "Root Superuser Access Granted: $hasRoot")
        })

        register(CommandSpec(
            name = "help",
            aliases = listOf("?", "h"),
            description = "Displays the command reference list."
        ) {
            println("\n--- COMMAND REFERENCE LIST ---")
            registry.values.distinctBy { it.name }.forEach { spec ->
                println("${spec.name.padEnd(12)} :${spec.description}")
                println("  Aliases    : ${spec.aliases.joinToString(", ")}")
            }
            println("-------------------------------\n")
        })
    }
}
