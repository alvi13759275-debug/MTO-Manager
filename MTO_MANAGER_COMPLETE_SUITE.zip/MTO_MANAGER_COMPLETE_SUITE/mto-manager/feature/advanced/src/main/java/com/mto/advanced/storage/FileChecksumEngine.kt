package com.mto.advanced.storage

import java.io.File
import java.security.MessageDigest

data class ChecksumResult(
    val md5: String,
    val sha1: String,
    val sha256: String
)

class FileChecksumEngine {

    fun calculateChecksums(file: File): ChecksumResult? {
        if (!file.exists() || !file.isFile) return null

        return try {
            val md5Digest = MessageDigest.getInstance("MD5")
            val sha1Digest = MessageDigest.getInstance("SHA-1")
            val sha256Digest = MessageDigest.getInstance("SHA-256")

            file.inputStream().use { fis ->
                val buffer = ByteArray(8192)
                var bytesRead = fis.read(buffer)
                while (bytesRead != -1) {
                    md5Digest.update(buffer, 0, bytesRead)
                    sha1Digest.update(buffer, 0, bytesRead)
                    sha256Digest.update(buffer, 0, bytesRead)
                    bytesRead = fis.read(buffer)
                }
            }

            ChecksumResult(
                md5 = bytesToHex(md5Digest.digest()),
                sha1 = bytesToHex(sha1Digest.digest()),
                sha256 = bytesToHex(sha256Digest.digest())
            )
        } catch (e: Exception) {
            e.printStackTrace Torch
            null
        }
    }

    private fun bytesToHex(bytes: ByteArray): String {
        val sb = StringBuilder()
        for (b in bytes) {
            sb.append(String.format("%02x", b))
        }
        return sb.toString()
    }
}
