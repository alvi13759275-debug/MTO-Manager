package com.mto.advanced.entry

import com.mto.advanced.integration.Phase25MasterSuiteEngine
import java.io.File
import java.util.Scanner
import java.util.concurrent.atomic.AtomicBoolean

class Phase26MainAppEntry {

    private val workspace = File(System.getProperty("user.home"), "mto_workspace")
    private lateinit var masterEngine: Phase25MasterSuiteEngine
    private lateinit var diagnostics: SystemDiagnosticsCollector
    private lateinit var commandRegistry: CliCommandRegistry
    private val isRunning = AtomicBoolean(true)

    fun start(args: Array<String>) {
        ConsoleLoggerEngine.printBanner()
        ConsoleLoggerEngine.info("AppEntry", "Initializing Master Engine in Workspace: ${workspace.absolutePath}")

        masterEngine = Phase25MasterSuiteEngine.getInstance(workspace)
        diagnostics = SystemDiagnosticsCollector(masterEngine)
        commandRegistry = CliCommandRegistry(masterEngine, diagnostics)

        attachSystemListeners()

        if (args.isNotEmpty()) {
            ConsoleLoggerEngine.info("AppEntry", "Non-Interactive Mode Activated.")
            commandRegistry.dispatch(args.joinToString(" "))
            masterEngine.shutdownMasterSuite()
        } else {
            ConsoleLoggerEngine.info("AppEntry", "Interactive Terminal Shell Shell Ready.")
            enterInteractiveShell()
        }
    }

    private fun attachSystemListeners() {
        masterEngine.addListener(object : Phase25MasterSuiteEngine.MasterSuiteEventListener {
            override fun onModuleStateChanged(moduleName: String, newState: Phase25MasterSuiteEngine.CoreModuleState) {
                ConsoleLoggerEngine.debug("ModuleState", "$moduleName ->$newState")
            }

            override fun onOrchestrationProgress(taskId: String, stepMessage: String, percent: Int) {
                ConsoleLoggerEngine.info("Orchestrator", "[$taskId] ($percent\%)$stepMessage")
            }

            override fun onOrchestrationCompleted(result: Phase25MasterSuiteEngine.MasterExecutionResult) {
                ConsoleLoggerEngine.info("Orchestrator", "Task ${result.taskId} execution completed with success=${result.isSuccess}")
            }
        })
    }

    private fun enterInteractiveShell() {
        val scanner = Scanner(System.`in`)
        println("\nType 'help' to inspect commands, or 'exit' to terminate.\n")

        while (isRunning.get()) {
            print("MTO-MANAGER-PHASE26> ")
            if (!scanner.hasNextLine()) break
            val line = scanner.nextLine().trim()

            if (line.equalsIgnoreCase("exit") || line.equalsIgnoreCase("quit")) {
                ConsoleLoggerEngine.info("AppEntry", "Shutting down M.T.O MANAGER Engine Pipeline...")
                masterEngine.shutdownMasterSuite()
                isRunning.set(false)
                break
            }

            if (line.isNotEmpty()) {
                commandRegistry.dispatch(line)
            }
        }
    }

    private fun String.equalsIgnoreCase(other: String) = this.equals(other, ignoreCase = true)
}

fun main(args: Array<String>) {
    val entry = Phase26MainAppEntry()
    entry.start(args)
}
