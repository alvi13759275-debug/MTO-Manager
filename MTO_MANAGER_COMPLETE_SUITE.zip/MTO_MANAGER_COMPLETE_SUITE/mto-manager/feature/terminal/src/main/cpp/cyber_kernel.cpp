#include <jni.h>
#include <string>
#include <vector>
#include <sstream>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <memory>
#include <thread>
#include <chrono>
#include <algorithm>
#include <map>
#include <cstdint>
#include <unistd.h>
#include <sys/sysinfo.h>
#include <sys/statvfs.h>
#include <sys/types.h>
#include <dirent.h>

namespace MtoKernel {

    struct CpuStats {
        uint64_t user, nice, system, idle, iowait, irq, softirq, steal;
    };

    struct ProcessInfo {
        int pid;
        std::string name;
        char state;
        uint64_t memoryUsageBytes;
    };

    class SystemMonitor {
    private:
        CpuStats prevCpuStats{};

        CpuStats readRawCpuStats() {
            std::ifstream procStat("/proc/stat");
            CpuStats stats{};
            std::string label;
            if (procStat.is_open()) {
                procStat >> label >> stats.user >> stats.nice >> stats.system 
                         >> stats.idle >> stats.iowait >> stats.irq 
                         >> stats.softirq >> stats.steal;
            }
            return stats;
        }

    public:
        SystemMonitor() { prevCpuStats = readRawCpuStats(); }

        double calculateCpuUsagePercentage() {
            CpuStats cur = readRawCpuStats();
            uint64_t prevIdle = prevCpuStats.idle + prevCpuStats.iowait;
            uint64_t curIdle = cur.idle + cur.iowait;
            uint64_t prevNonIdle = prevCpuStats.user + prevCpuStats.nice + prevCpuStats.system + 
                                   prevCpuStats.irq + prevCpuStats.softirq + prevCpuStats.steal;
            uint64_t curNonIdle = cur.user + cur.nice + cur.system + 
                                  cur.irq + cur.softirq + cur.steal;

            uint64_t totalDiff = (curIdle + curNonIdle) - (prevIdle + prevNonIdle);
            uint64_t idleDiff = curIdle - prevIdle;
            prevCpuStats = cur;

            if (totalDiff == 0) return 0.0;
            return (static_cast<double>(totalDiff - idleDiff) / static_cast<double>(totalDiff)) * 100.0;
        }

        std::string getMemoryReportJson() {
            struct sysinfo info{};
            std::ostringstream json;
            if (sysinfo(&info) == 0) {
                uint64_t totalRam = info.totalram * info.mem_unit;
                uint64_t freeRam = info.freeram * info.mem_unit;
                uint64_t usedRam = totalRam - freeRam;
                double usedPct = (static_cast<double>(usedRam) / static_cast<double>(totalRam)) * 100.0;
                json << "{\"total_bytes\":" << totalRam << ",\"used_bytes\":" << usedRam 
                     << ",\"free_bytes\":" << freeRam << ",\"used_percentage\":" << std::fixed 
                     << std::setprecision(2) << usedPct << "}";
            } else {
                json << "{\"error\": \"Failed to read sysinfo\"}";
            }
            return json.str();
        }
    };
}

static std::unique_ptr<MtoKernel::SystemMonitor> g_monitor = nullptr;

extern "C" JNIEXPORT void JNICALL
Java_com_mto_terminal_core_CyberKernelBridge_initNativeEngine(JNIEnv* env, jobject) {
    g_monitor = std::make_unique<MtoKernel::SystemMonitor>();
}

extern "C" JNIEXPORT jdouble JNICALL
Java_com_mto_terminal_core_CyberKernelBridge_getCpuUsagePercent(JNIEnv* env, jobject) {
    if (!g_monitor) g_monitor = std::make_unique<MtoKernel::SystemMonitor>();
    return g_monitor->calculateCpuUsagePercentage();
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_mto_terminal_core_CyberKernelBridge_getMemoryUsageJson(JNIEnv* env, jobject) {
    if (!g_monitor) g_monitor = std::make_unique<MtoKernel::SystemMonitor>();
    return env->NewStringUTF(g_monitor->getMemoryReportJson().c_str());
}
