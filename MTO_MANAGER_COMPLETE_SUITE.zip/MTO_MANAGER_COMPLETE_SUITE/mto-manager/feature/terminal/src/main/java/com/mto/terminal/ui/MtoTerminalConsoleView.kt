package com.mto.terminal.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.view.View
import java.util.concurrent.ConcurrentLinkedQueue

class MtoTerminalConsoleView(context: Context) : View(context) {

    private val backgroundPaint = Paint().apply {
        color = Color.BLACK
        style = Paint.Style.FILL
    }

    private val textPaint = Paint().apply {
        color = Color.GREEN
        textSize = 32f
        typeface = Typeface.MONOSPACE
        isAntiAlias = true
    }

    private val cursorPaint = Paint().apply {
        color = Color.GREEN
        style = Paint.Style.FILL
    }

    private val linesQueue = ConcurrentLinkedQueue<String>()
    private var isCursorVisible = true
    private var lastCursorBlink = System.currentTimeMillis()

    init {
        linesQueue.add("M.T.O MANAGER HIGH-PERFORMANCE CANVAS TERMINAL")
        linesQueue.add("Initializing graphics subsystem...")
        linesQueue.add("Ready.")
    }

    fun appendLine(line: String) {
        linesQueue.add(line)
        if (linesQueue.size > 100) {
            linesQueue.poll()
        }
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), backgroundPaint)

        var yPos = 50f
        val lineHeight = 40f

        linesQueue.forEach { line ->
            canvas.drawText(line, 20f, yPos, textPaint)
            yPos += lineHeight
        }

        val currentTime = System.currentTimeMillis()
        if (currentTime - lastCursorBlink > 500) {
            isCursorVisible = !isCursorVisible
            lastCursorBlink = currentTime
        }

        if (isCursorVisible) {
            canvas.drawRect(20f, yPos - 30f, 40f, yPos, cursorPaint)
        }

        postInvalidateDelayed(100)
    }
}
