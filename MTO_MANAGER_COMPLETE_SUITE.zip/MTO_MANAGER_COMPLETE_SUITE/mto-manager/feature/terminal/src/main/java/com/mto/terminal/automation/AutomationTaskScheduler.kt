package com.mto.terminal.automation

import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class AutomationTaskScheduler(private val scriptExecutor: ShellScriptExecutor) {

    data class ScheduledTask(
        val taskId: String,
        val taskName: String,
        val scriptContent: String,
        val intervalSeconds: Long,
        val isRepeatable: Boolean,
        var lastRunTimeMs: Long,
        var runCount: Int
    )

    private val scheduler: ScheduledExecutorService = Executors.newScheduledThreadPool(4)
    private val activeTasks = HashMap<String, ScheduledFuture<*>>()
    private val taskRegistry = HashMap<String, ScheduledTask>()

    fun scheduleTask(
        taskId: String,
        taskName: String,
        scriptContent: String,
        intervalSeconds: Long,
        repeatable: Boolean = true,
        onTaskExecuted: ((String, ShellScriptExecutor.ExecutionResult) -> Unit)? = null
    ) {
        cancelTask(taskId)

        val taskObj = ScheduledTask(
            taskId = taskId,
            taskName = taskName,
            scriptContent = scriptContent,
            intervalSeconds = intervalSeconds,
            isRepeatable = repeatable,
            lastRunTimeMs = 0L,
            runCount = 0
        )
        taskRegistry[taskId] = taskObj

        val runnable = Runnable {
            taskObj.lastRunTimeMs = System.currentTimeMillis()
            taskObj.runCount++

            val result = scriptExecutor.executeScript(scriptContent)
            onTaskExecuted?.invoke(taskId, result)

            if (!repeatable) {
                cancelTask(taskId)
            }
        }

        val future = if (repeatable) {
            scheduler.scheduleAtFixedRate(runnable, intervalSeconds, intervalSeconds, TimeUnit.SECONDS)
        } else {
            scheduler.schedule(runnable, intervalSeconds, TimeUnit.SECONDS)
        }

        activeTasks[taskId] = future
    }

    fun cancelTask(taskId: String) {
        activeTasks[taskId]?.cancel(true)
        activeTasks.remove(taskId)
        taskRegistry.remove(taskId)
    }

    fun getAllTasks(): List<ScheduledTask> {
        return taskRegistry.values.toList()
    }

    fun shutdownScheduler() {
        activeTasks.forEach { (_, future) -> future.cancel(true) }
        activeTasks.clear()
        taskRegistry.clear()
        scheduler.shutdownNow()
    }
}
