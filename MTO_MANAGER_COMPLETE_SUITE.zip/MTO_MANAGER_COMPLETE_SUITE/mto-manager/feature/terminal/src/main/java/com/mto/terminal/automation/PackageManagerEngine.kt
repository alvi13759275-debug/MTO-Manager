package com.mto.terminal.automation

import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

class PackageManagerEngine(private val scriptExecutor: ShellScriptExecutor) {

    enum class PackageType {
        APT,
        PKG,
        PIP,
        NPM
    }

    data class PackageStatus(
        val packageName: String,
        val packageType: PackageType,
        val isInstalled: Boolean,
        val installedVersion: String,
        val availableVersion: String
    )

    data class InstallationResult(
        val packageName: String,
        val isSuccess: Boolean,
        val logs: String
    )

    private val cacheInstalledMap = ConcurrentHashMap<String, PackageStatus>()

    fun checkPackageInstalled(pkgName: String, type: PackageType): PackageStatus {
        val checkCommand = when (type) {
            PackageType.APT -> "dpkg -s $pkgName | grep -E '(Status|Version)'"
            PackageType.PKG -> "pkg status $pkgName | grep -E '(Status|Version)'"
            PackageType.PIP -> "pip show $pkgName | grep Version"
            PackageType.NPM -> "npm list -g --depth=0 $pkgName"
        }

        val result = scriptExecutor.executeScript(checkCommand, timeoutSeconds = 10)
        val isInstalled = result.exitCode == 0 && result.stdoutOutput.contains(pkgName, ignoreCase = true)
        
        var version = "Unknown"
        if (isInstalled) {
            val lines = result.stdoutOutput.lines()
            for (line in lines) {
                if (line.contains("Version:", ignoreCase = true)) {
                    version = line.split(":").getOrNull(1)?.trim() ?: "Unknown"
                }
            }
        }

        val status = PackageStatus(
            packageName = pkgName,
            packageType = type,
            isInstalled = isInstalled,
            installedVersion = version,
            availableVersion = "Latest"
        )

        cacheInstalledMap["${type.name}_$pkgName"] = status
        return status
    }

    fun installPackage(pkgName: String, type: PackageType): InstallationResult {
        val installCmd = when (type) {
            PackageType.APT -> "apt-get update && apt-get install -y $pkgName"
            PackageType.PKG -> "pkg install -y $pkgName"
            PackageType.PIP -> "pip install --upgrade $pkgName"
            PackageType.NPM -> "npm install -g $pkgName"
        }

        val result = scriptExecutor.executeScript(installCmd, timeoutSeconds = 300)
        val success = result.exitCode == 0

        if (success) {
            checkPackageInstalled(pkgName, type)
        }

        return InstallationResult(
            packageName = pkgName,
            isSuccess = success,
            logs = result.stdoutOutput + "\n" + result.stderrOutput
        )
    }

    fun uninstallPackage(pkgName: String, type: PackageType): InstallationResult {
        val removeCmd = when (type) {
            PackageType.APT -> "apt-get remove -y $pkgName"
            PackageType.PKG -> "pkg uninstall -y $pkgName"
            PackageType.PIP -> "pip uninstall -y $pkgName"
            PackageType.NPM -> "npm uninstall -g $pkgName"
        }

        val result = scriptExecutor.executeScript(removeCmd, timeoutSeconds = 120)
        val success = result.exitCode == 0

        if (success) {
            cacheInstalledMap.remove("${type.name}_$pkgName")
        }

        return InstallationResult(
            packageName = pkgName,
            isSuccess = success,
            logs = result.stdoutOutput + "\n" + result.stderrOutput
        )
    }
}
