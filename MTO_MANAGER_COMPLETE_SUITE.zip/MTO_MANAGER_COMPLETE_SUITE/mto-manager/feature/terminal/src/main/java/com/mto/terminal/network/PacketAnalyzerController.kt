package com.mto.terminal.network

import android.net.TrafficStats
import java.io.BufferedReader
import java.io.File
import java.io.FileReader
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class PacketAnalyzerController {

    data class NetworkInterfaceStats(
        val interfaceName: String,
        val rxBytes: Long,
        val txBytes: Long,
        val rxPackets: Long,
        val txPackets: Long,
        val rxErrors: Long,
        val txErrors: Long,
        val rxDropped: Long,
        val txDropped: Long
    )

    data class LiveTrafficMetrics(
        val timestamp: Long,
        val rxSpeedBytesPerSec: Long,
        val txSpeedBytesPerSec: Long,
        val rxPacketSpeedPerSec: Long,
        val txPacketSpeedPerSec: Long,
        val interfaceBreakdown: List<NetworkInterfaceStats>
    )

    data class CapturedPacketHeader(
        val packetId: Long,
        val timestamp: Long,
        val protocol: String,
        val sourceAddress: String,
        val destinationAddress: String,
        val payloadLengthBytes: Int,
        val flags: String
    )

    private val isMonitoring = AtomicBoolean(false)
    private val scheduler: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor()
    private val capturedPacketsBuffer = ConcurrentLinkedQueue<CapturedPacketHeader>()
    private val interfaceHistoryMap = ConcurrentHashMap<String, NetworkInterfaceStats>()

    private val packetCounter = AtomicLong(1)
    private var lastTotalRxBytes = AtomicLong(0)
    private var lastTotalTxBytes = AtomicLong(0)
    private var lastTotalRxPackets = AtomicLong(0)
    private var lastTotalTxPackets = AtomicLong(0)
    private var lastTimestamp = AtomicLong(0)

    fun startAnalyzer(intervalMs: Long = 1000, onMetricsUpdate: (LiveTrafficMetrics) -> Unit) {
        if (isMonitoring.getAndSet(true)) return

        lastTotalRxBytes.set(TrafficStats.getTotalRxBytes())
        lastTotalTxBytes.set(TrafficStats.getTotalTxBytes())
        lastTotalRxPackets.set(TrafficStats.getTotalRxPackets())
        lastTotalTxPackets.set(TrafficStats.getTotalTxPackets())
        lastTimestamp.set(System.currentTimeMillis())

        scheduler.scheduleAtFixedRate({
            if (!isMonitoring.get()) return@scheduleAtFixedRate

            try {
                val currentRxBytes = TrafficStats.getTotalRxBytes()
                val currentTxBytes = TrafficStats.getTotalTxBytes()
                val currentRxPackets = TrafficStats.getTotalRxPackets()
                val currentTxPackets = TrafficStats.getTotalTxPackets()
                val currentTime = System.currentTimeMillis()

                val timeDeltaSec = (currentTime - lastTimestamp.get()) / 1000.0
                if (timeDeltaSec > 0) {
                    val rxSpeed = ((currentRxBytes - lastTotalRxBytes.get()) / timeDeltaSec).toLong()
                    val txSpeed = ((currentTxBytes - lastTotalTxBytes.get()) / timeDeltaSec).toLong()
                    val rxPps = ((currentRxPackets - lastTotalRxPackets.get()) / timeDeltaSec).toLong()
                    val txPps = ((currentTxPackets - lastTotalTxPackets.get()) / timeDeltaSec).toLong()

                    val ifaceStats = parseProcNetDevStats()

                    val metrics = LiveTrafficMetrics(
                        timestamp = currentTime,
                        rxSpeedBytesPerSec = if (rxSpeed < 0) 0 else rxSpeed,
                        txSpeedBytesPerSec = if (txSpeed < 0) 0 else txSpeed,
                        rxPacketSpeedPerSec = if (rxPps < 0) 0 else rxPps,
                        txPacketSpeedPerSec = if (txPps < 0) 0 else txPps,
                        interfaceBreakdown = ifaceStats
                    )

                    lastTotalRxBytes.set(currentRxBytes)
                    lastTotalTxBytes.set(currentTxBytes)
                    lastTotalRxPackets.set(currentRxPackets)
                    lastTotalTxPackets.set(currentTxPackets)
                    lastTimestamp.set(currentTime)

                    onMetricsUpdate(metrics)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }, intervalMs, intervalMs, TimeUnit.MILLISECONDS)
    }

    private fun parseProcNetDevStats(): List<NetworkInterfaceStats> {
        val list = mutableListOf<NetworkInterfaceStats>()
        val procDevFile = File("/proc/net/dev")

        if (procDevFile.exists() && procDevFile.canRead()) {
            try {
                BufferedReader(FileReader(procDevFile)).use { br ->
                    var line: String?
                    var lineCount = 0
                    while (br.readLine().also { line = it } != null) {
                        lineCount++
                        if (lineCount <= 2) continue

                        val parts = line!!.trim().split("\\s+".toRegex())
                        if (parts.size >= 17) {
                            val ifaceName = parts[0].replace(":", "")
                            val rxB = parts[1].toLongOrNull() ?: 0L
                            val rxP = parts[2].toLongOrNull() ?: 0L
                            val rxE = parts[3].toLongOrNull() ?: 0L
                            val rxD = parts[4].toLongOrNull() ?: 0L
                            val txB = parts[9].toLongOrNull() ?: 0L
                            val txP = parts[10].toLongOrNull() ?: 0L
                            val txE = parts[11].toLongOrNull() ?: 0L
                            val txD = parts[12].toLongOrNull() ?: 0L

                            val stat = NetworkInterfaceStats(
                                interfaceName = ifaceName,
                                rxBytes = rxB,
                                txBytes = txB,
                                rxPackets = rxP,
                                txPackets = txP,
                                rxErrors = rxE,
                                txErrors = txE,
                                rxDropped = rxD,
                                txDropped = txD
                            )
                            list.add(stat)
                            interfaceHistoryMap[ifaceName] = stat
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        return list
    }

    fun recordSimulatedPacketHeader(
        protocol: String,
        src: String,
        dest: String,
        payloadSize: Int,
        flags: String
    ) {
        val header = CapturedPacketHeader(
            packetId = packetCounter.getAndIncrement(),
            timestamp = System.currentTimeMillis(),
            protocol = protocol,
            sourceAddress = src,
            destinationAddress = dest,
            payloadLengthBytes = payloadSize,
            flags = flags
        )

        capturedPacketsBuffer.add(header)
        while (capturedPacketsBuffer.size > 1000) {
            capturedPacketsBuffer.poll()
        }
    }

    fun getBufferedPacketHistory(): List<CapturedPacketHeader> {
        return capturedPacketsBuffer.toList()
    }

    fun stopAnalyzer() {
        isMonitoring.set(false)
        scheduler.shutdown()
    }
}
