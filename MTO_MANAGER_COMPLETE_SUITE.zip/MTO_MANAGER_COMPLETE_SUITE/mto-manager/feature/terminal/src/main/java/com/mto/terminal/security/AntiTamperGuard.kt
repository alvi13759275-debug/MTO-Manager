package com.mto.terminal.security

import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

object AntiTamperGuard {

    private val fileRegistry = ConcurrentHashMap<String, String>()
    private val criticalPaths = mutableListOf<File>()

    fun registerCriticalFile(file: File): Boolean {
        if (!file.exists() || !file.isFile) return false
        val hash = computeFileHash(file)
        fileRegistry[file.absolutePath] = hash
        if (!criticalPaths.contains(file)) {
            criticalPaths.add(file)
        }
        return true
    }

    fun computeFileHash(file: File, algorithm: String = "SHA-256"): String {
        val digest = MessageDigest.getInstance(algorithm)
        val buffer = ByteArray(65536)

        FileInputStream(file).use { fis ->
            var bytesRead: Int
            while (fis.read(buffer).also { bytesRead = it } != -1) {
                digest.update(buffer, 0, bytesRead)
            }
        }

        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    fun auditIntegrity(): List<String> {
        val auditReport = mutableListOf<String>()

        for (file in criticalPaths) {
            val expectedHash = fileRegistry[file.absolutePath]
            if (!file.exists()) {
                auditReport.add("MISSING: ${file.name}")
                continue
            }

            val currentHash = computeFileHash(file)
            if (expectedHash != currentHash) {
                auditReport.add("TAMPERED: ${file.name}")
            } else {
                auditReport.add("INTEACT: ${file.name}")
            }
        }

        return auditReport
    }
}
