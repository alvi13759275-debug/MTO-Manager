package com.mto.terminal.network

import java.io.BufferedReader
import java.io.File
import java.io.FileReader
import java.io.InputStreamReader
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.locks.ReentrantReadWriteLock
import kotlin.concurrent.read
import kotlin.concurrent.write

class NetworkScannerEngine {

    enum class ScanMode {
        FAST_PING,
        FULL_PORT_SCAN,
        STEALTH_SYN_ACK,
        SERVICE_DETECTION,
        SUBNET_SWEEP
    }

    enum class PortState {
        OPEN,
        CLOSED,
        FILTERED,
        UNKNOWN
    }

    data class PortDetail(
        val portNumber: Int,
        val state: PortState,
        val serviceName: String,
        val responseTimeMs: Long,
        val banner: String
    )

    data class HostDiscovered(
        val ipAddress: String,
        val macAddress: String,
        val hostName: String,
        val isReachable: Boolean,
        val responseTimeMs: Long,
        val openPorts: List<PortDetail>,
        val osFingerprintGuess: String
    )

    data class SubnetRange(
        val baseIp: String,
        val prefixLength: Int,
        val startIpLong: Long,
        val endIpLong: Long
    )

    private val isScanning = AtomicBoolean(false)
    private val scanLock = ReentrantReadWriteLock()
    private val activeScanExecutor: ThreadPoolExecutor = Executors.newFixedThreadPool(64) as ThreadPoolExecutor
    private val discoveredHostsMap = ConcurrentHashMap<String, HostDiscovered>()
    
    private val totalScannedTargets = AtomicInteger(0)
    private val totalOpenPortsFound = AtomicInteger(0)
    private val scanStartTime = AtomicLong(0)

    private val commonServicesMap = mapOf(
        21 to "FTP",
        22 to "SSH",
        23 to "TELNET",
        25 to "SMTP",
        53 to "DNS",
        80 to "HTTP",
        110 to "POP3",
        143 to "IMAP",
        443 to "HTTPS",
        445 to "SMB",
        1433 to "MSSQL",
        1521 to "ORACLE",
        3306 to "MYSQL",
        3389 to "RDP",
        5432 to "POSTGRES",
        5900 to "VNC",
        6379 to "REDIS",
        8080 to "HTTP-ALT",
        8443 to "HTTPS-ALT",
        9000 to "FASTCGI",
        27017 to "MONGODB"
    )

    fun getLocalIpAddresses(): List<String> {
        val ipList = mutableListOf<String>()
        try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            for (networkInterface in interfaces) {
                if (!networkInterface.isUp || networkInterface.isLoopback) continue
                val addresses = Collections.list(networkInterface.inetAddresses)
                for (address in addresses) {
                    if (!address.isLoopbackAddress && address.hostAddress?.contains(":") == false) {
                        ipList.add(address.hostAddress ?: "")
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return ipList
    }

    fun parseSubnetPrefix(ipWithPrefix: String): SubnetRange? {
        return try {
            val parts = ipWithPrefix.split("/")
            val ipStr = parts[0]
            val prefix = if (parts.size > 1) parts[1].toInt() else 24
            
            val ipLong = ipToLong(InetAddress.getByName(ipStr))
            val mask = (-1L shl (32 - prefix)) and 0xFFFFFFFFL
            val startIp = ipLong and mask
            val endIp = startIp or mask.inv() and 0xFFFFFFFFL

            SubnetRange(ipStr, prefix, startIp, endIp)
        } catch (e: Exception) {
            null
        }
    }

    private fun ipToLong(ip: InetAddress): Long {
        val bytes = ip.address
        var result = 0L
        for (b in bytes) {
            result = (result shl 8) or (b.toInt() and 0xFF).toLong()
        }
        return result
    }

    private fun longToIp(ipLong: Long): String {
        return "${(ipLong shr 24) and 0xFF}.${(ipLong shr 16) and 0xFF}.${(ipLong shr 8) and 0xFF}.${ipLong and 0xFF}"
    }

    fun executeSubnetSweep(
        subnetPrefix: String,
        timeoutMs: Int = 800,
        scanPorts: Boolean = false,
        onHostFound: (HostDiscovered) -> Unit
    ) {
        scanLock.write {
            if (isScanning.getAndSet(true)) return

            discoveredHostsMap.clear()
            totalScannedTargets.set(0)
            totalOpenPortsFound.set(0)
            scanStartTime.set(System.currentTimeMillis())

            val subnetRange = parseSubnetPrefix(subnetPrefix) ?: run {
                isScanning.set(false)
                return
            }

            val totalHostCount = (subnetRange.endIpLong - subnetRange.startIpLong).toInt()
            val completedCount = AtomicInteger(0)

            for (currentIpLong in (subnetRange.startIpLong + 1) until subnetRange.endIpLong) {
                val targetIp = longToIp(currentIpLong)
                activeScanExecutor.execute {
                    try {
                        val startTime = System.currentTimeMillis()
                        val address = InetAddress.getByName(targetIp)
                        val reachable = address.isReachable(timeoutMs)
                        val elapsedTime = System.currentTimeMillis() - startTime

                        if (reachable) {
                            val macAddr = resolveMacAddressFromArpCache(targetIp)
                            val discoveredPorts = if (scanPorts) {
                                scanPortRangeOnTarget(targetIp, listOf(22, 80, 443, 8080, 21, 23, 3389, 445), timeoutMs)
                            } else {
                                emptyList()
                            }

                            val host = HostDiscovered(
                                ipAddress = targetIp,
                                macAddress = macAddr,
                                hostName = address.canonicalHostName,
                                isReachable = true,
                                responseTimeMs = elapsedTime,
                                openPorts = discoveredPorts,
                                osFingerprintGuess = guessOsFromResponse(discoveredPorts)
                            )
                            discoveredHostsMap[targetIp] = host
                            onHostFound(host)
                        }
                    } catch (e: Exception) {
                        // Target unreachable or dropped
                    } finally {
                        totalScannedTargets.incrementAndGet()
                        if (completedCount.incrementAndGet() >= totalHostCount - 1) {
                            isScanning.set(false)
                        }
                    }
                }
            }
        }
    }

    fun scanPortRangeOnTarget(targetIp: String, ports: List<Int>, timeoutMs: Int = 500): List<PortDetail> {
        val openPorts = mutableListOf<PortDetail>()
        val portExecutor = Executors.newFixedThreadPool(16)

        ports.forEach { port ->
            portExecutor.execute {
                val startTime = System.currentTimeMillis()
                try {
                    val socket = Socket()
                    socket.connect(InetSocketAddress(targetIp, port), timeoutMs)
                    val elapsed = System.currentTimeMillis() - startTime

                    val service = commonServicesMap[port] ?: "UNKNOWN"
                    val banner = tryBannerGrab(socket)

                    val detail = PortDetail(
                        portNumber = port,
                        state = PortState.OPEN,
                        serviceName = service,
                        responseTimeMs = elapsed,
                        banner = banner
                    )

                    synchronized(openPorts) {
                        openPorts.add(detail)
                        totalOpenPortsFound.incrementAndGet()
                    }
                    socket.close()
                } catch (e: Exception) {
                    // Port closed or filtered
                }
            }
        }

        portExecutor.shutdown()
        try {
            portExecutor.awaitTermination(10, TimeUnit.SECONDS)
        } catch (e: InterruptedException) {
            portExecutor.shutdownNow()
        }

        return openPorts.sortedBy { it.portNumber }
    }

    private fun tryBannerGrab(socket: Socket): String {
        return try {
            socket.soTimeout = 1000
            val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
            val firstLine = reader.readLine() ?: ""
            firstLine.take(128)
        } catch (e: Exception) {
            "NO_BANNER"
        }
    }

    private fun resolveMacAddressFromArpCache(ipAddress: String): String {
        var mac = "00:00:00:00:00:00"
        try {
            val arpProc = File("/proc/net/arp")
            if (arpProc.exists() && arpProc.canRead()) {
                BufferedReader(FileReader(arpProc)).use { br ->
                    var line: String?
                    while (br.readLine().also { line = it } != null) {
                        val tokens = line!!.trim().split("\\s+".toRegex())
                        if (tokens.size >= 4 && tokens[0] == ipAddress) {
                            mac = tokens[3]
                            break
                        }
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return mac
    }

    private fun guessOsFromResponse(ports: List<PortDetail>): String {
        val portNums = ports.map { it.portNumber }
        return when {
            portNums.contains(445) || portNums.contains(3389) -> "Windows OS (High Probability)"
            portNums.contains(22) -> "Linux/Unix OS (High Probability)"
            portNums.contains(80) || portNums.contains(443) -> "Embedded Network Device / Web Server"
            else -> "Unknown OS"
        }
    }

    fun getScanStatistics(): String {
        return scanLock.read {
            val duration = if (isScanning.get()) {
                System.currentTimeMillis() - scanStartTime.get()
            } else {
                0L
            }
            "Targets Scanned: ${totalScannedTargets.get()} | Active Discovered Hosts: ${discoveredHostsMap.size} | Total Open Ports: ${totalOpenPortsFound.get()} | Scan Duration: ${duration}ms"
        }
    }

    fun stopScan() {
        if (isScanning.get()) {
            activeScanExecutor.queue.clear()
            isScanning.set(false)
        }
    }
}
