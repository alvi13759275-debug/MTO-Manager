package com.mto.terminal.ui

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.mto.terminal.app.MtoMasterEngine

class DashboardLayoutManager(
    private val context: Context,
    private val masterEngine: MtoMasterEngine
) {

    private var statusTextView: TextView? = null

    fun createDashboardView(): View {
        val rootLayout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#121212"))
            setPadding(32, 32, 32, 32)
        }

        val titleView = TextView(context).apply {
            text = "M.T.O MANAGER DASHBOARD"
            textSize = 22f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, 0, 0, 24)
        }
        rootLayout.addView(titleView)

        statusTextView = TextView(context).apply {
            text = "Loading Engine Status..."
            textSize = 14f
            setTextColor(Color.GREEN)
            typeface = android.graphics.Typeface.MONOSPACE
            setBackgroundColor(Color.parseColor("#1E1E1E"))
            setPadding(20, 20, 20, 20)
        }
        rootLayout.addView(statusTextView)

        val btnOverlayOn = Button(context).apply {
            text = "ENABLE OVERLAY HUD"
            setBackgroundColor(Color.parseColor("#008800"))
            setTextColor(Color.WHITE)
            setOnClickListener {
                masterEngine.enableOverlayHudDisplay()
                refreshDiagnostics()
            }
        }
        rootLayout.addView(btnOverlayOn)

        val btnOverlayOff = Button(context).apply {
            text = "DISABLE OVERLAY HUD"
            setBackgroundColor(Color.parseColor("#880000"))
            setTextColor(Color.WHITE)
            setOnClickListener {
                masterEngine.disableOverlayHudDisplay()
                refreshDiagnostics()
            }
        }
        rootLayout.addView(btnOverlayOff)

        refreshDiagnostics()

        return ScrollView(context).apply { addView(rootLayout) }
    }

    fun refreshDiagnostics() {
        val diagnostics = masterEngine.getDetailedEngineDiagnostics()
        statusTextView?.text = diagnostics
    }
}
