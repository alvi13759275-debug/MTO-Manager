package com.mto.terminal.ui

import java.util.Random

class MatrixHudEngine(private val width: Int = 80, private val height: Int = 24) {

    private val glyphSet = "0123456789ABCDEFABCDEFGHIJKLMNOPQRSTUVWXYZ@#$%&*".toCharArray()
    private val random = Random()
    private val drops = IntArray(width) { random.nextInt(height) }

    fun renderFrame(): String {
        val buffer = Array(height) { CharArray(width) { ' ' } }

        for (x in 0 until width) {
            val y = drops[x]
            if (y in 0 until height) {
                buffer[y][x] = glyphSet[random.nextInt(glyphSet.size)]
            }
            drops[x] = (drops[x] + 1) % height
        }

        val frameBuilder = StringBuilder()
        for (row in buffer) {
            frameBuilder.append(String(row)).append("\n")
        }

        return frameBuilder.toString()
    }
}
