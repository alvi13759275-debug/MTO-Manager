package com.mto.terminal.ui

import android.graphics.Color
import java.util.concurrent.ConcurrentHashMap

class ThemeRegistryManager {

    data class CustomThemeSpec(
        val id: String,
        val name: String,
        val backgroundHex: String,
        val textHex: String,
        val accentHex: String
    )

    private val themeMap = ConcurrentHashMap<String, CustomThemeSpec>()

    init {
        registerTheme(CustomThemeSpec("MATRIX", "Matrix Green", "#000000", "#00FF66", "#003311"))
        registerTheme(CustomThemeSpec("CYBER", "Cyberpunk Neon", "#0D0221", "#00F0FF", "#FF007F"))
        registerTheme(CustomThemeSpec("DARULA", "Classic Darula", "#1E1E1E", "#D4D4D4", "#569CD6"))
        registerTheme(CustomThemeSpec("AMBER", "Amber Retro", "#000000", "#FFBF00", "#4D3B00"))
    }

    fun registerTheme(spec: CustomThemeSpec) {
        themeMap[spec.id] = spec
    }

    fun getThemeSpec(id: String): CustomThemeSpec? {
        return themeMap[id]
    }

    fun getAllThemes(): List<CustomThemeSpec> {
        return themeMap.values.toList()
    }

    fun parseColorSafe(hex: String, defaultColor: Int): Int {
        return try {
            Color.parseColor(hex)
        } catch (e: Exception) {
            defaultColor
        }
    }
}
