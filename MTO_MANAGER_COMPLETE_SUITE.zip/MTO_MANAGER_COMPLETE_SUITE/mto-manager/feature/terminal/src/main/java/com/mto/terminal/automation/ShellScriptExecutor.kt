package com.mto.terminal.automation

import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

class ShellScriptExecutor {

    data class ExecutionResult(
        val exitCode: Int,
        val stdoutOutput: String,
        val stderrOutput: String,
        val executionTimeMs: Long,
        val isTimedOut: Boolean
    )

    enum class ShellType {
        BASH,
        SH,
        ZSH,
        ROOT_SU
    }

    private val executorService = Executors.newCachedThreadPool()
    private val activeProcesses = ConcurrentHashMap<Long, Process>()
    private val processIdCounter = java.util.concurrent.atomic.AtomicLong(1)

    fun executeScript(
        scriptContent: String,
        workingDir: File? = null,
        environmentVars: Map<String, String> = emptyMap(),
        shellType: ShellType = ShellType.BASH,
        timeoutSeconds: Long = 60,
        onLiveOutput: ((String) -> Unit)? = null
    ): ExecutionResult {
        val startTime = System.currentTimeMillis()
        val pId = processIdCounter.getAndIncrement()
        var timedOut = false
        var exitCode = -1

        val stdoutBuffer = StringBuilder()
        val stderrBuffer = StringBuilder()

        val shellCommand = when (shellType) {
            ShellType.BASH -> "bash"
            ShellType.SH -> "sh"
            ShellType.ZSH -> "zsh"
            ShellType.ROOT_SU -> "su"
        }

        val processBuilder = ProcessBuilder(shellCommand)
        if (workingDir != null && workingDir.exists()) {
            processBuilder.directory(workingDir)
        }

        val env = processBuilder.environment()
        environmentVars.forEach { (key, value) -> env[key] = value }

        var process: Process? = null
        try {
            process = processBuilder.start()
            activeProcesses[pId] = process

            val writer = OutputStreamWriter(process.outputStream)
            writer.write(scriptContent)
            writer.write("\nexit\n")
            writer.flush()

            val stdoutReader = BufferedReader(InputStreamReader(process.inputStream))
            val stderrReader = BufferedReader(InputStreamReader(process.errorStream))

            val stdoutFuture = executorService.submit {
                var line: String?
                while (stdoutReader.readLine().also { line = it } != null) {
                    synchronized(stdoutBuffer) {
                        stdoutBuffer.append(line).append("\n")
                    }
                    onLiveOutput?.invoke(line!!)
                }
            }

            val stderrFuture = executorService.submit {
                var line: String?
                while (stderrReader.readLine().also { line = it } != null) {
                    synchronized(stderrBuffer) {
                        stderrBuffer.append(line).append("\n")
                    }
                }
            }

            val completed = process.waitFor(timeoutSeconds, TimeUnit.SECONDS)
            if (!completed) {
                timedOut = true
                process.destroyForcibly()
            } else {
                exitCode = process.exitValue()
            }

            stdoutFuture.get(2, TimeUnit.SECONDS)
            stderrFuture.get(2, TimeUnit.SECONDS)

        } catch (e: Exception) {
            stderrBuffer.append("Execution Exception: ").append(e.message)
        } finally {
            process?.let { activeProcesses.remove(pId) }
        }

        val totalTime = System.currentTimeMillis() - startTime

        return ExecutionResult(
            exitCode = exitCode,
            stdoutOutput = stdoutBuffer.toString(),
            stderrOutput = stderrBuffer.toString(),
            executionTimeMs = totalTime,
            isTimedOut = timedOut
        )
    }

    fun killAllActiveProcesses() {
        activeProcesses.forEach { (_, proc) ->
            try {
                proc.destroyForcibly()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        activeProcesses.clear()
    }
}
