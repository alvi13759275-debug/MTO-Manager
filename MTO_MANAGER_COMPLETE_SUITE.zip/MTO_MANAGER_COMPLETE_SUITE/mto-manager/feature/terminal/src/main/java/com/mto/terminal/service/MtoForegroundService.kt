package com.mto.terminal.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import com.mto.terminal.app.MtoMasterEngine
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class MtoForegroundService : Service() {

    enum class ServiceState {
        STOPPED,
        STARTING,
        RUNNING,
        PAUSED,
        STOPPING
    }

    private val binder = LocalBinder()
    private var masterEngine: MtoMasterEngine? = null
    private val isRunning = AtomicBoolean(false)
    private var currentState = ServiceState.STOPPED

    private val CHANNEL_ID = "MTO_FOREGROUND_SERVICE_CHANNEL"
    private val NOTIFICATION_ID = 8801
    private val mainHandler = Handler(Looper.getMainLooper())
    private val serviceExecutor: ScheduledExecutorService = Executors.newScheduledThreadPool(2)

    inner class LocalBinder : Binder() {
        fun getService(): MtoForegroundService = this@MtoForegroundService
    }

    override fun onCreate() {
        super.onCreate()
        currentState = ServiceState.STARTING
        masterEngine = MtoMasterEngine(applicationContext)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START_SERVICE

        when (action) {
            ACTION_START_SERVICE -> handleStartService()
            ACTION_STOP_SERVICE -> handleStopService()
            ACTION_ENABLE_HUD -> handleEnableHud()
            ACTION_DISABLE_HUD -> handleDisableHud()
            ACTION_TOGGLE_HUD -> handleToggleHud()
        }

        return START_STICKY
    }

    private fun handleStartService() {
        if (isRunning.getAndSet(true)) return

        val notification = buildForegroundNotification("M.T.O Engine Active", "System monitoring & Overlay HUD active.")
        startForeground(NOTIFICATION_ID, notification)

        serviceExecutor.execute {
            masterEngine?.bootEngine()
            currentState = ServiceState.RUNNING
            startHeartbeatMonitoring()
        }
    }

    private fun handleStopService() {
        if (!isRunning.get()) return

        currentState = ServiceState.STOPPING
        serviceExecutor.execute {
            masterEngine?.shutdownMasterEngine()
            isRunning.set(false)
            currentState = ServiceState.STOPPED
            mainHandler.post {
                stopForeground(true)
                stopSelf()
            }
        }
    }

    private fun handleEnableHud() {
        serviceExecutor.execute {
            masterEngine?.enableOverlayHudDisplay()
            updateNotificationContent("HUD Overlay Enabled", "Performance HUD running over apps.")
        }
    }

    private fun handleDisableHud() {
        serviceExecutor.execute {
            masterEngine?.disableOverlayHudDisplay()
            updateNotificationContent("HUD Overlay Disabled", "Engine active in background.")
        }
    }

    private fun handleToggleHud() {
        serviceExecutor.execute {
            val diag = masterEngine?.getDetailedEngineDiagnostics() ?: ""
            if (diag.contains("OVERLAY_HUD")) {
                handleDisableHud()
            } else {
                handleEnableHud()
            }
        }
    }

    private fun startHeartbeatMonitoring() {
        serviceExecutor.scheduleAtFixedRate({
            if (isRunning.get()) {
                val stats = masterEngine?.getDetailedEngineDiagnostics() ?: "Engine Running..."
                val memoryLine = stats.lines().find { it.contains("Memory Heap Usage") } ?: "Monitoring Memory"
                updateNotificationContent("M.T.O Engine Running", memoryLine)
            }
        }, 3, 3, TimeUnit.SECONDS)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "M.T.O Foreground Orchestrator",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Monitors background service and active overlay subsystems."
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildForegroundNotification(title: String, message: String): Notification {
        val stopIntent = Intent(this, MtoForegroundService::class.java).apply { action = ACTION_STOP_SERVICE }
        val pendingStopIntent = PendingIntent.getService(
            this, 101, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val toggleHudIntent = Intent(this, MtoForegroundService::class.java).apply { action = ACTION_TOGGLE_HUD }
        val pendingToggleHudIntent = PendingIntent.getService(
            this, 102, toggleHudIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        return builder
            .setContentTitle(title)
            .setContentText(message)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .addAction(android.R.drawable.ic_menu_compass, "Toggle HUD", pendingToggleHudIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Shutdown", pendingStopIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotificationContent(title: String, message: String) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val updatedNotification = buildForegroundNotification(title, message)
        notificationManager.notify(NOTIFICATION_ID, updatedNotification)
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        isRunning.set(false)
        serviceExecutor.shutdownNow()
        masterEngine?.shutdownMasterEngine()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START_SERVICE = "com.mto.terminal.service.ACTION_START"
        const val ACTION_STOP_SERVICE = "com.mto.terminal.service.ACTION_STOP"
        const val ACTION_ENABLE_HUD = "com.mto.terminal.service.ACTION_ENABLE_HUD"
        const val ACTION_DISABLE_HUD = "com.mto.terminal.service.ACTION_DISABLE_HUD"
        const val ACTION_TOGGLE_HUD = "com.mto.terminal.service.ACTION_TOGGLE_HUD"
    }
}
