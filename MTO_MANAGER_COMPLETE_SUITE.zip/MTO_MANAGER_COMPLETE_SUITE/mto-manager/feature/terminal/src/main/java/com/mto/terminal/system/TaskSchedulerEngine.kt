package com.mto.terminal.system

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

class TaskSchedulerEngine {

    private val scheduler = Executors.newScheduledThreadPool(4)
    private val scheduledTasksMap = ConcurrentHashMap<String, ScheduledFuture<*>>()

    fun scheduleCronJob(
        jobId: String,
        initialDelaySeconds: Long,
        intervalSeconds: Long,
        action: () -> Unit
    ): Boolean {
        if (scheduledTasksMap.containsKey(jobId)) {
            cancelCronJob(jobId)
        }

        return try {
            val future = scheduler.scheduleAtFixedRate({
                try {
                    action()
                } catch (e: Exception) {
                    System.err.println("Scheduled Task Execution Error [$jobId]: ${e.localizedMessage}")
                }
            }, initialDelaySeconds, intervalSeconds, TimeUnit.SECONDS)

            scheduledTasksMap[jobId] = future
            true
        } catch (e: Exception) {
            false
        }
    }

    fun cancelCronJob(jobId: String): Boolean {
        val future = scheduledTasksMap.remove(jobId)
        return if (future != null) {
            future.cancel(true)
            true
        } else {
            false
        }
    }

    fun getActiveJobIds(): List<String> = scheduledTasksMap.keys().toList()

    fun shutdownAllTasks() {
        scheduledTasksMap.forEach { (jobId, future) ->
            future.cancel(true)
        }
        scheduledTasksMap.clear()
        scheduler.shutdown()
    }
}
