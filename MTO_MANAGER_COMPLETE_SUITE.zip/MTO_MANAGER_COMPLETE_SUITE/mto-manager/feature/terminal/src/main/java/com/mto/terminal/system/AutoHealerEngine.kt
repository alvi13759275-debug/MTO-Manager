package com.mto.terminal.system

import java.io.File
import java.io.FileOutputStream

object AutoHealerEngine {

    data class DiagnosticReport(
        val totalChecked: Int,
        val repairedPaths: List<String>,
        val failedPaths: List<String>,
        val isHealthy: Boolean
    )

    fun performSystemAuditAndRepair(projectRootDir: File): DiagnosticReport {
        val repairedList = mutableListOf<String>()
        val failedList = mutableListOf<String>()
        var totalCheckedCount = 0

        if (!projectRootDir.exists()) {
            projectRootDir.mkdirs()
            repairedList.add(projectRootDir.absolutePath)
        }

        val requiredDirectories = listOf(
            "app/src/main/java/com/mto/manager",
            "feature/terminal/src/main/cpp",
            "feature/terminal/src/main/java/com/mto/terminal/core",
            "feature/terminal/src/main/java/com/mto/terminal/ai",
            "feature/terminal/src/main/java/com/mto/terminal/security",
            "feature/terminal/src/main/java/com/mto/terminal/network",
            "feature/terminal/src/main/java/com/mto/terminal/system",
            "feature/terminal/src/main/res/values"
        )

        for (dirPath in requiredDirectories) {
            totalCheckedCount++
            val dirFile = File(projectRootDir, dirPath)
            if (!dirFile.exists()) {
                if (dirFile.mkdirs()) {
                    repairedList.add(dirPath)
                } else {
                    failedList.add(dirPath)
                }
            }
        }

        val essentialFilesMap = mapOf(
            "feature/terminal/src/main/cpp/CMakeLists.txt" to getMinimalCmakeContent(),
            "feature/terminal/src/main/res/values/strings.xml" to getMinimalStringsXml()
        )

        for ((filePath, defaultContent) in essentialFilesMap) {
            totalCheckedCount++
            val targetFile = File(projectRootDir, filePath)
            if (!targetFile.exists() || targetFile.length() == 0L) {
                try {
                    targetFile.parentFile?.mkdirs()
                    FileOutputStream(targetFile).use { fos ->
                        fos.write(defaultContent.toByteArray(Charsets.UTF_8))
                    }
                    repairedList.add(filePath)
                } catch (e: Exception) {
                    failedList.add(filePath)
                }
            }
        }

        return DiagnosticReport(
            totalChecked = totalCheckedCount,
            repairedPaths = repairedList,
            failedPaths = failedList,
            isHealthy = failedList.isEmpty()
        )
    }

    private fun getMinimalCmakeContent(): String {
        return """
            cmake_minimum_required(VERSION 3.22.1)
            project("cyberkernel")
            set(CMAKE_CXX_STANDARD 20)
            add_library(cyberkernel SHARED cyber_kernel.cpp)
            find_library(log-lib log)
            target_link_libraries(cyberkernel ${'$'}{log-lib})
        """.trimIndent()
    }

    private fun getMinimalStringsXml(): String {
        return """
            <resources>
                <string name="app_name">M.T.O MANAGER</string>
            </resources>
        """.trimIndent()
    }
}
