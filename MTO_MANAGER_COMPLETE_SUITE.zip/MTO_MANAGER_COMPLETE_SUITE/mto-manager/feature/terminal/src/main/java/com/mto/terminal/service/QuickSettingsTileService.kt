package com.mto.terminal.service

import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.annotation.RequiresApi

@RequiresApi(Build.VERSION_CODES.N)
class QuickSettingsTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        updateTileState(false)
    }

    override fun onClick() {
        super.onClick()
        val tile = qsTile ?: return

        if (tile.state == Tile.STATE_INACTIVE) {
            val intent = Intent(this, MtoForegroundService::class.java).apply {
                action = MtoForegroundService.ACTION_START_SERVICE
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            updateTileState(true)
        } else {
            val intent = Intent(this, MtoForegroundService::class.java).apply {
                action = MtoForegroundService.ACTION_STOP_SERVICE
            }
            startService(intent)
            updateTileState(false)
        }
    }

    private fun updateTileState(isActive: Boolean) {
        val tile = qsTile ?: return
        tile.state = if (isActive) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = if (isActive) "M.T.O Engine [ON]" else "M.T.O Engine [OFF]"
        tile.updateTile()
    }
}
