package com.mto.terminal.network

import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.concurrent.thread

class MeshNetworkNode(private val listeningPort: Int = 8888) {

    private var isRunning = false
    private var serverSocket: ServerSocket? = null
    private val connectedPeers = ConcurrentHashMap<String, Socket>()
    private val threadPool = Executors.newCachedThreadPool()

    data class PeerMessage(
        val senderIp: String,
        val payload: String,
        val timestamp: Long
    )

    fun startNode(onMessageReceived: (PeerMessage) -> Unit) {
        if (isRunning) return
        isRunning = true

        thread {
            try {
                serverSocket = ServerSocket()
                serverSocket?.reuseAddress = true
                serverSocket?.bind(InetSocketAddress(listeningPort))

                while (isRunning) {
                    val clientSocket = serverSocket?.accept() ?: break
                    val remoteAddress = clientSocket.inetAddress.hostAddress ?: "Unknown"
                    connectedPeers[remoteAddress] = clientSocket

                    threadPool.submit {
                        handleClientConnection(clientSocket, remoteAddress, onMessageReceived)
                    }
                }
            } catch (e: Exception) {
                System.err.println("Mesh Node Socket Exception: ${e.localizedMessage}")
            } finally {
                stopNode()
            }
        }
    }

    private fun handleClientConnection(
        socket: Socket,
        remoteAddress: String,
        onMessageReceived: (PeerMessage) -> Unit
    ) {
        try {
            val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
            var incomingLine: String?

            while (socket.isConnected && !socket.isClosed) {
                incomingLine = reader.readLine() ?: break
                val message = PeerMessage(
                    senderIp = remoteAddress,
                    payload = incomingLine,
                    timestamp = System.currentTimeMillis()
                )
                onMessageReceived(message)
            }
        } catch (e: Exception) {
            System.err.println("Peer connection lost with $remoteAddress: ${e.localizedMessage}")
        } finally {
            connectedPeers.remove(remoteAddress)
            try {
                socket.close()
            } catch (ignored: Exception) {}
        }
    }

    fun broadcastMessage(message: String): Int {
        var successCount = 0
        connectedPeers.forEach { (ip, socket) ->
            if (sendDirectPayload(socket, message)) {
                successCount++
            }
        }
        return successCount
    }

    fun sendPayloadToHost(targetIp: String, targetPort: Int, payload: String): Boolean {
        return try {
            val socket = Socket()
            socket.connect(InetSocketAddress(targetIp, targetPort), 3000)
            val success = sendDirectPayload(socket, payload)
            socket.close()
            success
        } catch (e: Exception) {
            false
        }
    }

    private fun sendDirectPayload(socket: Socket, payload: String): Boolean {
        return try {
            val writer = PrintWriter(socket.getOutputStream(), true)
            writer.println(payload)
            !writer.checkError()
        } catch (e: Exception) {
            false
        }
    }

    fun getActivePeerCount(): Int = connectedPeers.size

    fun stopNode() {
        isRunning = false
        try {
            serverSocket?.close()
        } catch (ignored: Exception) {}

        connectedPeers.forEach { (_, socket) ->
            try {
                socket.close()
            } catch (ignored: Exception) {}
        }
        connectedPeers.clear()
        threadPool.shutdown()
    }
}
