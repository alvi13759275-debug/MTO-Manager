package com.mto.terminal.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import java.io.BufferedReader
import java.io.File
import java.io.FileReader
import java.io.RandomAccessFile
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

class OverlayHudController(private val context: Context) {

    private var windowManager: WindowManager? = null
    private var overlayView: HudRenderView? = null
    private var layoutParams: WindowManager.LayoutParams? = null
    private val isRunning = AtomicBoolean(false)
    private var executorService: ScheduledExecutorService? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private val metricsCache = AtomicReference<SystemMetrics>(SystemMetrics.default())
    private val metricsListeners = ConcurrentHashMap<String, MetricsUpdateListener>()
    private val historicalMetrics = ArrayDeque<SystemMetrics>(100)

    data class SystemMetrics(
        val cpuUsagePercent: Float,
        val userCpuPercent: Float,
        val systemCpuPercent: Float,
        val ioWaitPercent: Float,
        val totalMemoryMb: Long,
        val freeMemoryMb: Long,
        val usedMemoryMb: Long,
        val cachedMemoryMb: Long,
        val memoryUsagePercent: Float,
        val swapTotalMb: Long,
        val swapFreeMb: Long,
        val activeThreads: Int,
        val totalProcesses: Int,
        val uptimeSeconds: Long,
        val batteryTemperature: Float,
        val batteryLevel: Int,
        val networkRxBytesPerSec: Long,
        val networkTxBytesPerSec: Long,
        val timestamp: Long
    ) {
        companion object {
            fun default() = SystemMetrics(
                cpuUsagePercent = 0.0f,
                userCpuPercent = 0.0f,
                systemCpuPercent = 0.0f,
                ioWaitPercent = 0.0f,
                totalMemoryMb = 0L,
                freeMemoryMb = 0L,
                usedMemoryMb = 0L,
                cachedMemoryMb = 0L,
                memoryUsagePercent = 0.0f,
                swapTotalMb = 0L,
                swapFreeMb = 0L,
                activeThreads = 0,
                totalProcesses = 0,
                uptimeSeconds = 0L,
                batteryTemperature = 0.0f,
                batteryLevel = 0,
                networkRxBytesPerSec = 0L,
                networkTxBytesPerSec = 0L,
                timestamp = System.currentTimeMillis()
            )
        }
    }

    interface MetricsUpdateListener {
        fun onMetricsUpdated(metrics: SystemMetrics)
        fun onError(exception: Exception)
    }

    fun registerMetricsListener(key: String, listener: MetricsUpdateListener) {
        metricsListeners[key] = listener
    }

    fun unregisterMetricsListener(key: String) {
        metricsListeners.remove(key)
    }

    fun initializeOverlayParams(): WindowManager.LayoutParams {
        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED

        return WindowManager.LayoutParams(
            450,
            650,
            windowType,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 50
            y = 150
        }
    }

    fun attachOverlayToWindow(): Boolean {
        return try {
            if (windowManager == null) {
                windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            }
            layoutParams = initializeOverlayParams()
            overlayView = HudRenderView(context)
            overlayView?.setOnTouchListener(createTouchDragListener(layoutParams!!, windowManager!!))
            windowManager?.addView(overlayView, layoutParams)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun detachOverlayFromWindow(): Boolean {
        return try {
            if (overlayView != null && windowManager != null) {
                windowManager?.removeView(overlayView)
                overlayView = null
                true
            } else {
                false
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun startMonitoring(intervalMs: Long = 500) {
        if (isRunning.getAndSet(true)) return

        executorService = Executors.newScheduledThreadPool(2)
        executorService?.scheduleAtFixedRate({
            try {
                val metrics = collectComprehensiveSystemMetrics()
                metricsCache.set(metrics)

                synchronized(historicalMetrics) {
                    if (historicalMetrics.size >= 100) {
                        historicalMetrics.removeFirst()
                    }
                    historicalMetrics.addLast(metrics)
                }

                mainHandler.post {
                    overlayView?.updateData(metrics)
                }

                metricsListeners.values.forEach { listener ->
                    listener.onMetricsUpdated(metrics)
                }
            } catch (e: Exception) {
                metricsListeners.values.forEach { listener ->
                    listener.onError(e)
                }
            }
        }, 0, intervalMs, TimeUnit.MILLISECONDS)
    }

    fun stopMonitoring() {
        if (!isRunning.getAndSet(false)) return

        executorService?.shutdownNow()
        executorService = null
    }

    private var lastTotalRxBytes = AtomicLong(0L)
    private var lastTotalTxBytes = AtomicLong(0L)
    private var lastNetSampleTime = AtomicLong(System.currentTimeMillis())

    private fun collectComprehensiveSystemMetrics(): SystemMetrics {
        val runtime = Runtime.getRuntime()
        val totalMem = runtime.totalMemory() / (1024 * 1024)
        val freeMem = runtime.freeMemory() / (1024 * 1024)
        val usedMem = totalMem - freeMem
        val memPercent = if (totalMem > 0) (usedMem.toFloat() / totalMem.toFloat()) * 100f else 0.0f

        val cpuData = readDetailedCpuProc()
        val threadCount = Thread.activeCount()
        val processCount = readProcessCount()
        val uptime = readSystemUptime()

        val netData = calculateNetworkThroughput()

        return SystemMetrics(
            cpuUsagePercent = cpuData[0],
            userCpuPercent = cpuData[1],
            systemCpuPercent = cpuData[2],
            ioWaitPercent = cpuData[3],
            totalMemoryMb = totalMem,
            freeMemoryMb = freeMem,
            usedMemoryMb = usedMem,
            cachedMemoryMb = readCachedMemory(),
            memoryUsagePercent = memPercent,
            swapTotalMb = 0L,
            swapFreeMb = 0L,
            activeThreads = threadCount,
            totalProcesses = processCount,
            uptimeSeconds = uptime,
            batteryTemperature = 32.5f,
            batteryLevel = 85,
            networkRxBytesPerSec = netData.first,
            networkTxBytesPerSec = netData.second,
            timestamp = System.currentTimeMillis()
        )
    }

    private fun readDetailedCpuProc(): FloatArray {
        return try {
            val reader = RandomAccessFile("/proc/stat", "r")
            val line1 = reader.readLine()
            reader.close()

            val tokens1 = line1.split("\\s+".toRegex())
            val user1 = tokens1[1].toFloat()
            val nice1 = tokens1[2].toFloat()
            val sys1 = tokens1[3].toFloat()
            val idle1 = tokens1[4].toFloat()
            val io1 = tokens1[5].toFloat()

            val total1 = user1 + nice1 + sys1 + idle1 + io1

            Thread.sleep(150)

            val reader2 = RandomAccessFile("/proc/stat", "r")
            val line2 = reader2.readLine()
            reader2.close()

            val tokens2 = line2.split("\\s+".toRegex())
            val user2 = tokens2[1].toFloat()
            val nice2 = tokens2[2].toFloat()
            val sys2 = tokens2[3].toFloat()
            val idle2 = tokens2[4].toFloat()
            val io2 = tokens2[5].toFloat()

            val total2 = user2 + nice2 + sys2 + idle2 + io2

            val totalDiff = total2 - total1
            if (totalDiff == 0f) return floatArrayOf(0f, 0f, 0f, 0f)

            val userDiff = (user2 + nice2) - (user1 + nice1)
            val sysDiff = sys2 - sys1
            val ioDiff = io2 - io1
            val idleDiff = idle2 - idle1

            val totalUsage = ((totalDiff - idleDiff) / totalDiff) * 100f
            val userUsage = (userDiff / totalDiff) * 100f
            val sysUsage = (sysDiff / totalDiff) * 100f
            val ioUsage = (ioDiff / totalDiff) * 100f

            floatArrayOf(
                totalUsage.coerceIn(0f, 100f),
                userUsage.coerceIn(0f, 100f),
                sysUsage.coerceIn(0f, 100f),
                ioUsage.coerceIn(0f, 100f)
            )
        } catch (e: Exception) {
            floatArrayOf(0f, 0f, 0f, 0f)
        }
    }

    private fun readCachedMemory(): Long {
        return try {
            val file = File("/proc/meminfo")
            if (!file.exists()) return 0L
            val reader = BufferedReader(FileReader(file))
            var line: String?
            var cachedKb = 0L
            while (reader.readLine().also { line = it } != null) {
                if (line!!.startsWith("Cached:")) {
                    val parts = line!!.split("\\s+".toRegex())
                    if (parts.size >= 2) {
                        cachedKb = parts[1].toLongOrNull() ?: 0L
                    }
                    break
                }
            }
            reader.close()
            cachedKb / 1024
        } catch (e: Exception) {
            0L
        }
    }

    private fun readProcessCount(): Int {
        return try {
            val procDir = File("/proc")
            val files = procDir.listFiles { _, name -> name.matches(Regex("\\d+")) }
            files?.size ?: 0
        } catch (e: Exception) {
            0
        }
    }

    private fun readSystemUptime(): Long {
        return try {
            val reader = RandomAccessFile("/proc/uptime", "r")
            val line = reader.readLine()
            reader.close()
            val tokens = line.split("\\s+".toRegex())
            tokens[0].toDouble().toLong()
        } catch (e: Exception) {
            0L
        }
    }

    private fun calculateNetworkThroughput(): Pair<Long, Long> {
        return try {
            val rxFile = File("/sys/class/net/wlan0/statistics/rx_bytes")
            val txFile = File("/sys/class/net/wlan0/statistics/tx_bytes")

            if (!rxFile.exists() || !txFile.exists()) return Pair(0L, 0L)

            val currentRx = rxFile.readText().trim().toLongOrNull() ?: 0L
            val currentTx = txFile.readText().trim().toLongOrNull() ?: 0L
            val currentTime = System.currentTimeMillis()

            val timeDiffSec = (currentTime - lastNetSampleTime.get()) / 1000.0
            if (timeDiffSec <= 0) return Pair(0L, 0L)

            val rxRate = if (lastTotalRxBytes.get() > 0) ((currentRx - lastTotalRxBytes.get()) / timeDiffSec).toLong() else 0L
            val txRate = if (lastTotalTxBytes.get() > 0) ((currentTx - lastTotalTxBytes.get()) / timeDiffSec).toLong() else 0L

            lastTotalRxBytes.set(currentRx)
            lastTotalTxBytes.set(currentTx)
            lastNetSampleTime.set(currentTime)

            Pair(rxRate.coerceAtLeast(0L), txRate.coerceAtLeast(0L))
        } catch (e: Exception) {
            Pair(0L, 0L)
        }
    }

    fun createTouchDragListener(params: WindowManager.LayoutParams, wm: WindowManager): View.OnTouchListener {
        return object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = initialX + (event.rawX - initialTouchX).toInt()
                        params.y = initialY + (event.rawY - initialTouchY).toInt()
                        wm.updateViewLayout(v, params)
                        return true
                    }
                }
                return false
            }
        }
    }

    private class HudRenderView(context: Context) : View(context) {

        private val backgroundPaint = Paint().apply {
            color = Color.argb(220, 10, 15, 25)
            style = Paint.Style.FILL
        }

        private val borderPaint = Paint().apply {
            color = Color.parseColor("#00FF66")
            style = Paint.Style.STROKE
            strokeWidth = 3f
        }

        private val textPaint = Paint().apply {
            color = Color.parseColor("#00FF66")
            textSize = 22f
            typeface = Typeface.MONOSPACE
            isAntiAlias = true
        }

        private val titlePaint = Paint().apply {
            color = Color.parseColor("#00E5FF")
            textSize = 26f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            isAntiAlias = true
        }

        private val graphPaint = Paint().apply {
            color = Color.parseColor("#FF0055")
            style = Paint.Style.STROKE
            strokeWidth = 2f
            isAntiAlias = true
        }

        private var currentMetrics = SystemMetrics.default()
        private val cpuHistory = FloatArray(30)
        private var historyIndex = 0

        fun updateData(metrics: SystemMetrics) {
            this.currentMetrics = metrics
            cpuHistory[historyIndex] = metrics.cpuUsagePercent
            historyIndex = (historyIndex + 1) % cpuHistory.size
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)

            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), backgroundPaint)
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), borderPaint)

            var yOffset = 35f
            canvas.drawText("M.T.O OVERLAY HUD", 15f, yOffset, titlePaint)

            yOffset += 35f
            canvas.drawLine(10f, yOffset, width - 10f, yOffset, borderPaint)

            yOffset += 30f
            canvas.drawText("CPU TOTAL : %.1f%%".format(currentMetrics.cpuUsagePercent), 15f, yOffset, textPaint)

            yOffset += 25f
            canvas.drawText("  USR: %.1f%%  SYS: %.1f%%".format(currentMetrics.userCpuPercent, currentMetrics.systemCpuPercent), 15f, yOffset, textPaint)

            yOffset += 30f
            canvas.drawText("MEM USED  : ${currentMetrics.usedMemoryMb} MB / ${currentMetrics.totalMemoryMb} MB", 15f, yOffset, textPaint)

            yOffset += 25f
            canvas.drawText("MEM RATIO : %.1f%%".format(currentMetrics.memoryUsagePercent), 15f, yOffset, textPaint)

            yOffset += 30f
            canvas.drawText("THREADS   : ${currentMetrics.activeThreads}", 15f, yOffset, textPaint)

            yOffset += 25f
            canvas.drawText("PROCESSES : ${currentMetrics.totalProcesses}", 15f, yOffset, textPaint)

            yOffset += 30f
            canvas.drawText("UPTIME    : ${currentMetrics.uptimeSeconds}s", 15f, yOffset, textPaint)

            yOffset += 30f
            canvas.drawText("NET RX/TX : ${currentMetrics.networkRxBytesPerSec / 1024} KB/s | ${currentMetrics.networkTxBytesPerSec / 1024} KB/s", 15f, yOffset, textPaint)

            yOffset += 40f
            canvas.drawText("CPU LOAD GRAPH:", 15f, yOffset, textPaint)

            yOffset += 15f
            val graphHeight = 80f
            val graphWidth = width - 30f
            val startX = 15f
            val startY = yOffset + graphHeight

            canvas.drawRect(startX, yOffset, startX + graphWidth, startY, borderPaint)

            val stepX = graphWidth / (cpuHistory.size - 1)
            for (i in 0 until cpuHistory.size - 1) {
                val idx1 = (historyIndex + i) % cpuHistory.size
                val idx2 = (historyIndex + i + 1) % cpuHistory.size

                val x1 = startX + (i * stepX)
                val y1 = startY - ((cpuHistory[idx1] / 100f) * graphHeight)

                val x2 = startX + ((i + 1) * stepX)
                val y2 = startY - ((cpuHistory[idx2] / 100f) * graphHeight)

                canvas.drawLine(x1, y1, x2, y2, graphPaint)
            }
        }
    }
}
