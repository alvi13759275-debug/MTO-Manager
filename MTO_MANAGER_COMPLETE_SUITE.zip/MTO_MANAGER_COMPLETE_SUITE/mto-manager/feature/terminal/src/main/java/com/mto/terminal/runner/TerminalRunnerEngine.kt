package com.mto.terminal.runner

import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.util.concurrent.Executors

object TerminalRunnerEngine {

    data class ExecutionResult(
        val exitCode: Int,
        val output: String,
        val error: String,
        val executionTimeMs: Long
    )

    fun executeCommand(command: String, workingDir: File? = null): ExecutionResult {
        val startTime = System.currentTimeMillis()
        return try {
            val process = ProcessBuilder(*command.split("\\s+".toRegex()).toTypedArray())
                .directory(workingDir)
                .redirectErrorStream(false)
                .start()

            val stdoutBuilder = StringBuilder()
            val stderrBuilder = StringBuilder()

            val threadPool = Executors.newFixedThreadPool(2)

            threadPool.submit {
                BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        stdoutBuilder.append(line).append("\n")
                    }
                }
            }

            threadPool.submit {
                BufferedReader(InputStreamReader(process.errorStream)).use { reader ->
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        stderrBuilder.append(line).append("\n")
                    }
                }
            }

            val exitCode = process.waitFor()
            threadPool.shutdown()

            val elapsedTime = System.currentTimeMillis() - startTime
            ExecutionResult(
                exitCode = exitCode,
                output = stdoutBuilder.toString().trim(),
                error = stderrBuilder.toString().trim(),
                executionTimeMs = elapsedTime
            )
        } catch (e: Exception) {
            val elapsedTime = System.currentTimeMillis() - startTime
            ExecutionResult(
                exitCode = -1,
                output = "",
                error = e.localizedMessage ?: "Execution Failure",
                executionTimeMs = elapsedTime
            )
        }
    }
}
