package com.mto.terminal.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.mto.terminal.app.MtoMasterEngine
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

class TerminalUiController(
    private val context: Context,
    private val masterEngine: MtoMasterEngine
) {

    enum class ColorTheme(
        val themeId: String,
        val nameTitle: String,
        val bgColor: Int,
        val textColor: Int,
        val accentColor: Int,
        val promptColor: Int,
        val errorColor: Int
    ) {
        MATRIX_GREEN("THEME_MATRIX", "Matrix Green", Color.BLACK, Color.parseColor("#00FF66"), Color.parseColor("#003311"), Color.parseColor("#33FF00"), Color.parseColor("#FF3333")),
        CYBER_PUNK("THEME_CYBER", "Cyberpunk Neon", Color.parseColor("#0D0221"), Color.parseColor("#00F0FF"), Color.parseColor("#FF007F"), Color.parseColor("#FFE600"), Color.parseColor("#FF0055")),
        CLASSIC_DARULA("THEME_DARULA", "Classic Darula", Color.parseColor("#1E1E1E"), Color.parseColor("#D4D4D4"), Color.parseColor("#569CD6"), Color.parseColor("#CE9178"), Color.parseColor("#F44747")),
        AMBER_RETRO("THEME_AMBER", "Amber Retro", Color.BLACK, Color.parseColor("#FFBF00"), Color.parseColor("#4D3B00"), Color.parseColor("#FF8800"), Color.parseColor("#FF3300"))
    }

    data class LogEntry(
        val id: Int,
        val timestamp: Long,
        val message: String,
        val isSystem: Boolean,
        val isError: Boolean
    )

    private var currentTheme = ColorTheme.MATRIX_GREEN
    private var fontSizePx = 14f
    private val timeFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())
    private val logBuffer = ConcurrentLinkedQueue<LogEntry>()
    private val idCounter = AtomicInteger(1)
    private val isAutoScrollEnabled = AtomicBoolean(true)

    private var terminalContainer: LinearLayout? = null
    private var scrollView: ScrollView? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    fun createTerminalView(): View {
        scrollView = ScrollView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(currentTheme.bgColor)
            isVerticalScrollBarEnabled = true
        }

        terminalContainer = LinearLayout(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }

        scrollView?.addView(terminalContainer)
        
        appendHeaderBanner()
        appendLog("M.T.O MANAGER NATIVE CONSOLE INTERFACE READY", isSystem = true, isError = false)
        appendLog("Active Theme: ${currentTheme.nameTitle}", isSystem = false, isError = false)

        return scrollView!!
    }

    private fun appendHeaderBanner() {
        val banner = """
        ==================================================
        |  M.T.O MANAGER - MODULAR TERMINAL ORCHESTRATOR |
        |  System Version: 2.5.0-PROD                      |
        |  Status: ACTIVE | Engine: ATTACHED              |
        ==================================================
        """.trimIndent()
        
        val textView = TextView(context).apply {
            text = banner
            textSize = fontSizePx
            typeface = Typeface.MONOSPACE
            setTextColor(currentTheme.accentColor)
            setPadding(0, 8, 0, 16)
        }
        terminalContainer?.addView(textView)
    }

    fun appendLog(message: String, isSystem: Boolean = false, isError: Boolean = false) {
        val entry = LogEntry(
            id = idCounter.getAndIncrement(),
            timestamp = System.currentTimeMillis(),
            message = message,
            isSystem = isSystem,
            isError = isError
        )
        logBuffer.add(entry)

        mainHandler.post {
            val timestamp = timeFormat.format(Date(entry.timestamp))
            val formattedLog = "[$timestamp] $message"

            val textView = TextView(context).apply {
                text = formattedLog
                textSize = fontSizePx
                typeface = Typeface.MONOSPACE
                setTextColor(
                    when {
                        isError -> currentTheme.errorColor
                        isSystem -> currentTheme.promptColor
                        else -> currentTheme.textColor
                    }
                )
                setPadding(0, 2, 0, 2)
            }

            terminalContainer?.addView(textView)

            if (isAutoScrollEnabled.get()) {
                scrollView?.post {
                    scrollView?.fullScroll(View.FOCUS_DOWN)
                }
            }
        }
    }

    fun applyTheme(theme: ColorTheme) {
        this.currentTheme = theme
        mainHandler.post {
            scrollView?.setBackgroundColor(theme.bgColor)
            val childCount = terminalContainer?.childCount ?: 0
            for (i in 0 until childCount) {
                val child = terminalContainer?.getChildAt(i) as? TextView
                child?.setTextColor(theme.textColor)
            }
        }
    }

    fun setAutoScroll(enabled: Boolean) {
        isAutoScrollEnabled.set(enabled)
    }

    fun updateFontSize(newSizePx: Float) {
        this.fontSizePx = newSizePx
        mainHandler.post {
            val childCount = terminalContainer?.childCount ?: 0
            for (i in 0 until childCount) {
                val child = terminalContainer?.getChildAt(i) as? TextView
                child?.textSize = newSizePx
            }
        }
    }

    fun clearScreen() {
        mainHandler.post {
            terminalContainer?.removeAllViews()
            logBuffer.clear()
            appendHeaderBanner()
            appendLog("Console buffer cleared.", isSystem = true, isError = false)
        }
    }

    fun exportLogHistory(): String {
        val sb = StringBuilder()
        logBuffer.forEach { entry ->
            val timestamp = timeFormat.format(Date(entry.timestamp))
            sb.append("[$timestamp] [${if (entry.isSystem) "SYS" else "USER"}] ${entry.message}\n")
        }
        return sb.toString()
    }
}
