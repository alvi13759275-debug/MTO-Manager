package com.mto.terminal.network

import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.TimeUnit

class PingTracerouteUtility {

    data class SinglePingReply(
        val sequenceNumber: Int,
        val bytesReceived: Int,
        val ttl: Int,
        val rttMs: Float,
        val ipAddress: String
    )

    data class PingSummaryResult(
        val targetHost: String,
        val packetsTransmitted: Int,
        val packetsReceived: Int,
        val packetLossPercent: Float,
        val minRttMs: Float,
        val avgRttMs: Float,
        val maxRttMs: Float,
        val mdevRttMs: Float,
        val replies: List<SinglePingReply>,
        val rawLog: String
    )

    data class HopInfo(
        val hopNumber: Int,
        val hostName: String,
        val ipAddress: String,
        val rttMs1: Float,
        val rttMs2: Float,
        val rttMs3: Float
    )

    data class TracerouteResult(
        val targetHost: String,
        val isCompleted: Boolean,
        val hops: List<HopInfo>,
        val rawOutput: String
    )

    private val executor = Executors.newCachedThreadPool()

    fun executeAdvancedPing(targetHost: String, count: Int = 4, timeoutSec: Int = 5): PingSummaryResult {
        val repliesList = mutableListOf<SinglePingReply>()
        val rawLogBuilder = StringBuilder()

        var tx = 0
        var rx = 0
        var loss = 100f
        var minRtt = -1f
        var avgRtt = -1f
        var maxRtt = -1f
        var mdevRtt = -1f

        try {
            val command = "ping -c $count -W $timeoutSec $targetHost"
            val process = Runtime.getRuntime().exec(command)
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            var line: String?

            while (reader.readLine().also { line = it } != null) {
                rawLogBuilder.append(line).append("\n")
                val trimmed = line!!.trim()

                if (trimmed.contains("bytes from")) {
                    val parsedReply = parsePingReplyLine(trimmed)
                    if (parsedReply != null) {
                        repliesList.add(parsedReply)
                    }
                } else if (trimmed.contains("packets transmitted")) {
                    val parts = trimmed.split(",")
                    for (part in parts) {
                        val token = part.trim()
                        if (token.contains("packets transmitted")) {
                            tx = token.split(" ")[0].toIntOrNull() ?: 0
                        } else if (token.contains("received")) {
                            rx = token.split(" ")[0].toIntOrNull() ?: 0
                        } else if (token.contains("packet loss")) {
                            loss = token.split("%")[0].trim().toFloatOrNull() ?: 100f
                        }
                    }
                } else if (trimmed.contains("rtt min/avg/max/mdev") || trimmed.contains("round-trip")) {
                    val parts = trimmed.split("=")
                    if (parts.size > 1) {
                        val rttValues = parts[1].trim().split(" ")[0].split("/")
                        if (rttValues.size >= 4) {
                            minRtt = rttValues[0].toFloatOrNull() ?: -1f
                            avgRtt = rttValues[1].toFloatOrNull() ?: -1f
                            maxRtt = rttValues[2].toFloatOrNull() ?: -1f
                            mdevRtt = rttValues[3].toFloatOrNull() ?: -1f
                        }
                    }
                }
            }
            process.waitFor()
        } catch (e: Exception) {
            rawLogBuilder.append("Execution Exception: ").append(e.message)
        }

        return PingSummaryResult(
            targetHost = targetHost,
            packetsTransmitted = tx,
            packetsReceived = rx,
            packetLossPercent = loss,
            minRttMs = minRtt,
            avgRttMs = avgRtt,
            maxRttMs = maxRtt,
            mdevRttMs = mdevRtt,
            replies = repliesList,
            rawLog = rawLogBuilder.toString()
        )
    }

    private fun parsePingReplyLine(line: String): SinglePingReply? {
        return try {
            val parts = line.split(":")
            val bytesStr = parts[0].split(" ")[0]
            val bytes = bytesStr.toIntOrNull() ?: 64

            val ipStr = parts[0].split("from")[1].trim()

            var seq = -1
            var ttl = -1
            var time = -1f

            val metaTokens = parts[1].trim().split(" ")
            for (token in metaTokens) {
                if (token.startsWith("icmp_seq=")) {
                    seq = token.split("=")[1].toIntOrNull() ?: -1
                } else if (token.startsWith("ttl=")) {
                    ttl = token.split("=")[1].toIntOrNull() ?: -1
                } else if (token.startsWith("time=")) {
                    time = token.split("=")[1].toFloatOrNull() ?: -1f
                }
            }

            SinglePingReply(seq, bytes, ttl, time, ipStr)
        } catch (e: Exception) {
            null
        }
    }

    fun executeTraceroute(targetHost: String, maxHops: Int = 30): TracerouteResult {
        val hopsList = mutableListOf<HopInfo>()
        val rawOutput = StringBuilder()
        var completed = false

        try {
            val process = Runtime.getRuntime().exec("traceroute -m $maxHops $targetHost")
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            var line: String?

            while (reader.readLine().also { line = it } != null) {
                rawOutput.append(line).append("\n")
                val trimmed = line!!.trim()

                val hop = parseTracerouteHopLine(trimmed)
                if (hop != null) {
                    hopsList.add(hop)
                    if (hop.ipAddress == targetHost || hop.hostName == targetHost) {
                        completed = true
                    }
                }
            }
            process.waitFor()
        } catch (e: Exception) {
            rawOutput.append("Traceroute Failed: ").append(e.message)
        }

        return TracerouteResult(
            targetHost = targetHost,
            isCompleted = completed,
            hops = hopsList,
            rawOutput = rawOutput.toString()
        )
    }

    private fun parseTracerouteHopLine(line: String): HopInfo? {
        return try {
            val tokens = line.split("\\s+".toRegex())
            if (tokens.size < 2) return null

            val hopNum = tokens[0].toIntOrNull() ?: return null
            val host = tokens[1]
            val ip = if (tokens.size > 2 && tokens[2].startsWith("(")) tokens[2].replace("(", "").replace(")", "") else host

            var rtt1 = -1f
            var rtt2 = -1f
            var rtt3 = -1f

            val rttList = mutableListOf<Float>()
            for (i in 2 until tokens.size) {
                if (tokens[i] == "ms") {
                    val prev = tokens[i - 1].toFloatOrNull()
                    if (prev != null) rttList.add(prev)
                }
            }

            if (rttList.size > 0) rtt1 = rttList[0]
            if (rttList.size > 1) rtt2 = rttList[1]
            if (rttList.size > 2) rtt3 = rttList[2]

            HopInfo(hopNum, host, ip, rtt1, rtt2, rtt3)
        } catch (e: Exception) {
            null
        }
    }
}
