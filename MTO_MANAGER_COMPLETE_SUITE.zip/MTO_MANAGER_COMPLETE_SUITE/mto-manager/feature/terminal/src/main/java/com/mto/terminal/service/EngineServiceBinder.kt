package com.mto.terminal.service

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder

class EngineServiceBinder(private val context: Context) {

    private var boundService: MtoForegroundService? = null
    private var isBound = false

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(className: ComponentName, service: IBinder) {
            val binder = service as MtoForegroundService.LocalBinder
            boundService = binder.getService()
            isBound = true
        }

        override fun onServiceDisconnected(arg0: ComponentName) {
            isBound = false
            boundService = null
        }
    }

    fun bindEngineService() {
        val intent = Intent(context, MtoForegroundService::class.java)
        context.bindService(intent, connection, Context.BIND_AUTO_CREATE)
    }

    fun unbindEngineService() {
        if (isBound) {
            context.unbindService(connection)
            isBound = false
        }
    }

    fun getService(): MtoForegroundService? = boundService
}
