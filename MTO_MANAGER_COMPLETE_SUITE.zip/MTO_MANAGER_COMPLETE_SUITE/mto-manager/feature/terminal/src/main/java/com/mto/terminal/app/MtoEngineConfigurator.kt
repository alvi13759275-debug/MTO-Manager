package com.mto.terminal.app

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Properties

class MtoEngineConfigurator(private val configFile: File) {

    private val properties = Properties()

    fun loadConfiguration(): Boolean {
        if (!configFile.exists()) {
            createDefaultConfiguration()
        }

        return try {
            FileInputStream(configFile).use { fis ->
                properties.load(fis)
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun createDefaultConfiguration() {
        properties.setProperty("engine.overlay.fps", "60")
        properties.setProperty("engine.overlay.opacity", "0.85")
        properties.setProperty("engine.security.pbkdf2_iterations", "100000")
        properties.setProperty("engine.terminal.buffer_size", "8192")
        properties.setProperty("engine.ipc.port", "8999")
        properties.setProperty("engine.heartbeat.interval_ms", "5000")

        saveConfiguration()
    }

    fun saveConfiguration(): Boolean {
        return try {
            FileOutputStream(configFile).use { fos ->
                properties.store(fos, "MTO Engine Architecture Settings")
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun getString(key: String, defaultValue: String): String {
        return properties.getProperty(key, defaultValue)
    }

    fun getInt(key: String, defaultValue: Int): Int {
        return properties.getProperty(key)?.toIntOrNull() ?: defaultValue
    }

    fun getFloat(key: String, defaultValue: Float): Float {
        return properties.getProperty(key)?.toFloatOrNull() ?: defaultValue
    }

    fun setProperty(key: String, value: String) {
        properties.setProperty(key, value)
        saveConfiguration()
    }
}
