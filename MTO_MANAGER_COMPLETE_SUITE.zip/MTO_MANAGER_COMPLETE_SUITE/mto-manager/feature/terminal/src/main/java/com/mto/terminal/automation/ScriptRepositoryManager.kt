package com.mto.terminal.automation

import java.io.File
import java.io.FileReader
import java.io.FileWriter

class ScriptRepositoryManager(private val baseRepoDir: File) {

    data class ScriptMetaData(
        val scriptName: String,
        val scriptPath: String,
        val sizeBytes: Long,
        val isExecutable: Boolean,
        val lastModifiedMs: Long
    )

    init {
        if (!baseRepoDir.exists()) {
            baseRepoDir.mkdirs()
        }
    }

    fun saveScript(scriptName: String, content: String): ScriptMetaData? {
        val file = File(baseRepoDir, scriptName)
        return try {
            FileWriter(file).use { writer ->
                writer.write(content)
            }
            file.setExecutable(true)
            getScriptDetails(file)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun loadScriptContent(scriptName: String): String? {
        val file = File(baseRepoDir, scriptName)
        if (!file.exists() || !file.canRead()) return null
        return try {
            FileReader(file).use { it.readText() }
        } catch (e: Exception) {
            null
        }
    }

    fun listAllScripts(): List<ScriptMetaData> {
        val list = mutableListOf<ScriptMetaData>()
        val files = baseRepoDir.listFiles() ?: arrayOf()
        for (file in files) {
            if (file.isFile) {
                getScriptDetails(file)?.let { list.add(it) }
            }
        }
        return list.sortedBy { it.scriptName }
    }

    fun deleteScript(scriptName: String): Boolean {
        val file = File(baseRepoDir, scriptName)
        return if (file.exists()) file.delete() else false
    }

    private fun getScriptDetails(file: File): ScriptMetaData? {
        if (!file.exists()) return null
        return ScriptMetaData(
            scriptName = file.name,
            scriptPath = file.absolutePath,
            sizeBytes = file.length(),
            isExecutable = file.canExecute(),
            lastModifiedMs = file.lastModified()
        )
    }
}
