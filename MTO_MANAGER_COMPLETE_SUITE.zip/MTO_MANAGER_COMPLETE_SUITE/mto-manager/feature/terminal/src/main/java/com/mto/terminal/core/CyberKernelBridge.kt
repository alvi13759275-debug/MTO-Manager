package com.mto.terminal.core

import org.json.JSONObject

data class MemoryMetrics(
    val totalBytes: Long,
    val usedBytes: Long,
    val freeBytes: Long,
    val usedPercentage: Double
)

object CyberKernelBridge {
    private var isLoaded = false

    init {
        try {
            System.loadLibrary("cyberkernel")
            isLoaded = true
            initNativeEngine()
        } catch (e: UnsatisfiedLinkError) {
            isLoaded = false
        }
    }

    private external fun initNativeEngine()
    private external fun getCpuUsagePercent(): Double
    private external fun getMemoryUsageJson(): String

    fun fetchCpuLoad(): Double = if (isLoaded) getCpuUsagePercent() else 0.0

    fun fetchMemory(): MemoryMetrics {
        if (!isLoaded) return MemoryMetrics(0, 0, 0, 0.0)
        val json = JSONObject(getMemoryUsageJson())
        return MemoryMetrics(
            totalBytes = json.optLong("total_bytes", 0L),
            usedBytes = json.optLong("used_bytes", 0L),
            freeBytes = json.optLong("free_bytes", 0L),
            usedPercentage = json.optDouble("used_percentage", 0.0)
        )
    }
}
