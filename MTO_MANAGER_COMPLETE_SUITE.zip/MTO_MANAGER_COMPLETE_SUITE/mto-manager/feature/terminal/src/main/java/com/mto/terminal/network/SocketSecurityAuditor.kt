package com.mto.terminal.network

import java.io.BufferedReader
import java.io.File
import java.io.FileReader

class SocketSecurityAuditor {

    enum class SocketProtocol {
        TCP,
        TCP6,
        UDP,
        UDP6,
        UNIX_DOMAIN
    }

    data class ActiveSocketEntry(
        val protocol: SocketProtocol,
        val localAddressIp: String,
        val localPort: Int,
        val foreignAddressIp: String,
        val foreignPort: Int,
        val connectionState: String,
        val uid: Int,
        val inode: String,
        val isSuspiciousPort: Boolean
    )

    data class AuditReport(
        val totalActiveSockets: Int,
        val totalListeningSockets: Int,
        val totalEstablishedConnections: Int,
        val suspiciousSocketEntries: List<ActiveSocketEntry>,
        val fullSocketList: List<ActiveSocketEntry>
    )

    private val monitoredPorts = setOf(4444, 5555, 6667, 31337, 12345, 9999, 8888)

    fun performFullSocketAudit(): AuditReport {
        val allSockets = mutableListOf<ActiveSocketEntry>()
        allSockets.addAll(parseProcNetFile("/proc/net/tcp", SocketProtocol.TCP))
        allSockets.addAll(parseProcNetFile("/proc/net/tcp6", SocketProtocol.TCP6))
        allSockets.addAll(parseProcNetFile("/proc/net/udp", SocketProtocol.UDP))
        allSockets.addAll(parseProcNetFile("/proc/net/udp6", SocketProtocol.UDP6))

        val suspicious = allSockets.filter { it.isSuspiciousPort }
        val listening = allSockets.count { it.connectionState == "LISTEN" }
        val established = allSockets.count { it.connectionState == "ESTABLISHED" }

        return AuditReport(
            totalActiveSockets = allSockets.size,
            totalListeningSockets = listening,
            totalEstablishedConnections = established,
            suspiciousSocketEntries = suspicious,
            fullSocketList = allSockets
        )
    }

    private fun parseProcNetFile(filePath: String, protocol: SocketProtocol): List<ActiveSocketEntry> {
        val entries = mutableListOf<ActiveSocketEntry>()
        val file = File(filePath)

        if (file.exists() && file.canRead()) {
            try {
                BufferedReader(FileReader(file)).use { br ->
                    var line: String?
                    var lineNum = 0
                    while (br.readLine().also { line = it } != null) {
                        lineNum++
                        if (lineNum == 1) continue

                        val tokens = line!!.trim().split("\\s+".toRegex())
                        if (tokens.size >= 10) {
                            val localAddrPort = parseHexAddressAndPort(tokens[1])
                            val foreignAddrPort = parseHexAddressAndPort(tokens[2])
                            val stateHex = tokens[3]
                            val uidVal = tokens[7].toIntOrNull() ?: -1
                            val inodeVal = tokens[9]

                            val stateName = mapTcpStateName(stateHex)
                            val isSuspicious = monitoredPorts.contains(localAddrPort.second) || monitoredPorts.contains(foreignAddrPort.second)

                            val entry = ActiveSocketEntry(
                                protocol = protocol,
                                localAddressIp = localAddrPort.first,
                                localPort = localAddrPort.second,
                                foreignAddressIp = foreignAddrPort.first,
                                foreignPort = foreignAddrPort.second,
                                connectionState = stateName,
                                uid = uidVal,
                                inode = inodeVal,
                                isSuspiciousPort = isSuspicious
                            )
                            entries.add(entry)
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        return entries
    }

    private fun parseHexAddressAndPort(hexStr: String): Pair<String, Int> {
        val parts = hexStr.split(":")
        if (parts.size != 2) return Pair("0.0.0.0", 0)

        val hexIp = parts[0]
        val hexPort = parts[1]

        val port = hexPort.toIntOrNull(16) ?: 0
        val ip = if (hexIp.length == 8) {
            val p1 = hexIp.substring(6, 8).toInt(16)
            val p2 = hexIp.substring(4, 6).toInt(16)
            val p3 = hexIp.substring(2, 4).toInt(16)
            val p4 = hexIp.substring(0, 2).toInt(16)
            "$p1.$p2.$p3.$p4"
        } else {
            "IPv6_Address"
        }

        return Pair(ip, port)
    }

    private fun mapTcpStateName(hexState: String): String {
        return when (hexState.uppercase()) {
            "01" -> "ESTABLISHED"
            "02" -> "SYN_SENT"
            "03" -> "SYN_RECV"
            "04" -> "FIN_WAIT1"
            "05" -> "FIN_WAIT2"
            "06" -> "TIME_WAIT"
            "07" -> "CLOSE"
            "08" -> "CLOSE_WAIT"
            "09" -> "LAST_ACK"
            "0A" -> "LISTEN"
            "0B" -> "CLOSING"
            else -> "UNKNOWN ($hexState)"
        }
    }
}
