package com.mto.terminal.ai

class NeuralPredictor {
    private val commandDataset = mapOf(
        "git" to listOf("git status", "git commit -m \"update\"", "git push origin main"),
        "pkg" to listOf("pkg update && pkg upgrade", "pkg install clang", "pkg list-installed"),
        "mto" to listOf("mto --status", "mto --audit", "mto --config"),
        "sys" to listOf("systeminfo", "top -n 1", "df -h")
    )

    fun predictNextCommand(inputPrefix: String): List<String> {
        val cleanInput = inputPrefix.trim().lowercase()
        if (cleanInput.isEmpty()) return emptyList()

        val predictions = mutableListOf<String>()
        commandDataset.forEach { (key, commands) ->
            if (cleanInput.startsWith(key)) {
                predictions.addAll(commands)
            }
        }

        return if (predictions.isNotEmpty()) predictions else listOf("$cleanInput --help", "help $cleanInput")
    }
}
