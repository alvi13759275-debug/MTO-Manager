package com.mto.terminal.security

import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest

object FileHashChecker {
    fun calculateSHA256(file: File): String {
        if (!file.exists()) return "ERROR_FILE_NOT_FOUND"

        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(8192)
        
        FileInputStream(file).use { fis ->
            var bytesRead: Int
            while (fis.read(buffer).also { bytesRead = it } != -1) {
                digest.update(buffer, 0, bytesRead)
            }
        }

        val hashBytes = digest.digest()
        val hexString = StringBuilder()
        for (b in hashBytes) {
            hexString.append(String.format("%02x", b))
        }

        return hexString.toString()
    }
}
