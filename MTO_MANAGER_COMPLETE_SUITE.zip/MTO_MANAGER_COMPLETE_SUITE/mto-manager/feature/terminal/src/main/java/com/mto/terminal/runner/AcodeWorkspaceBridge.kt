package com.mto.terminal.runner

import java.io.File
import org.json.JSONObject

object AcodeWorkspaceBridge {

    fun generateAcodeProjectConfig(projectRootDir: File): Boolean {
        if (!projectRootDir.exists()) return false

        val acodeDir = File(projectRootDir, ".acode")
        if (!acodeDir.exists()) acodeDir.mkdirs()

        val jsonConfig = JSONObject().apply {
            put("name", "M.T.O MANAGER")
            put("type", "android_multi_module")
            put("main_language", "kotlin")
            put("native_support", true)
            put("build_tool", "gradle")
            put("created_at", System.currentTimeMillis())
        }

        val configFile = File(acodeDir, "project.json")
        return try {
            configFile.writeText(jsonConfig.toString(4))
            true
        } catch (e: Exception) {
            false
        }
    }
}
