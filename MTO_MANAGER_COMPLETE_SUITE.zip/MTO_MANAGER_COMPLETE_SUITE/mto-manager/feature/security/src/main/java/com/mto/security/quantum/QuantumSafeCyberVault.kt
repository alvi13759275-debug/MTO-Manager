package com.mto.security.quantum

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

class QuantumSafeCyberVault private constructor(
    private val vaultStorageDirectory: File,
    private val vaultConfig: VaultConfiguration
) {

    data class VaultConfiguration(
        val keySizeBits: Int = 256,
        val gcmTagLengthBits: Int = 128,
        val ivSizeBytes: Int = 12,
        val pbkdf2Iterations: Int = 100000,
        val enableLatticeEncryptionSimulation: Boolean = true,
        val maxSimultaneousEnclaves: Int = 8,
        val auditLogLevel: AuditLevel = AuditLevel.VERBOSE
    )

    enum class AuditLevel {
        NONE, MINIMAL, STANDARD, VERBOSE, FORENSIC_STRICT
    }

    enum class EnclaveState {
        SEALED, UNSEALED, RE_KEYING, COMPROMISED, QUARANTINED, SANITIZING
    }

    enum class ThreatSeverity {
        INFO, LOW, MEDIUM, HIGH, CRITICAL, SYSTEM_BREACH
    }

    data class SecurityEnclave(
        val enclaveId: String = UUID.randomUUID().toString(),
        val enclaveName: String,
        var state: EnclaveState = EnclaveState.SEALED,
        val masterKeyHashSha384: String,
        val salt: ByteArray,
        val associatedFiles: CopyOnWriteArrayList<File> = CopyOnWriteArrayList(),
        val createdAtTimestamp: Long = System.currentTimeMillis(),
        var lastAccessedTimestamp: Long = System.currentTimeMillis(),
        var trustScore: AtomicInteger = AtomicInteger(100)
    )

    data class ForensicsAuditRecord(
        val recordId: String = UUID.randomUUID().toString(),
        val timestamp: Long = System.currentTimeMillis(),
        val enclaveId: String?,
        val eventType: String,
        val severity: ThreatSeverity,
        val sourceAddressOrProcess: String,
        val details: String,
        val checksumSha256: String
    )

    interface VaultAuditEventListener {
        fun onSecurityEventRecorded(record: ForensicsAuditRecord)
        fun onEnclaveStateChanged(enclave: SecurityEnclave, oldState: EnclaveState, newState: EnclaveState)
        fun onThreatDetected(severity: ThreatSeverity, message: String)
    }

    private val activeEnclaves = ConcurrentHashMap<String, SecurityEnclave>()
    private val auditLogs = CopyOnWriteArrayList<ForensicsAuditRecord>()
    private val listeners = CopyOnWriteArrayList<VaultAuditEventListener>()

    private val secureRandom = SecureRandom()
    private val executor = Executors.newFixedThreadPool(vaultConfig.maxSimultaneousEnclaves)
    private val backgroundScanner: ScheduledExecutorService = Executors.newScheduledThreadPool(2)
    private val isVaultActive = AtomicBoolean(true)

    init {
        if (!vaultStorageDirectory.exists()) {
            vaultStorageDirectory.mkdirs()
        }
        startForensicIntegrityScanner()
    }

    fun registerAuditListener(listener: VaultAuditEventListener) {
        listeners.add(listener)
    }

    fun unregisterAuditListener(listener: VaultAuditEventListener) {
        listeners.remove(listener)
    }

    fun createEnclave(enclaveName: String, secretPassphrase: String): String {
        require(secretPassphrase.length >= 12) { "Passphrase must be at least 12 characters for quantum resilience." }

        val salt = ByteArray(32)
        secureRandom.nextBytes(salt)

        val derivedKey = deriveQuantumResistantKey(secretPassphrase, salt)
        val keyHash = computeSha384Hash(derivedKey.encoded)

        val enclave = SecurityEnclave(
            enclaveName = enclaveName,
            masterKeyHashSha384 = keyHash,
            salt = salt
        )

        activeEnclaves[enclave.enclaveId] = enclave
        logAudit(
            enclaveId = enclave.enclaveId,
            eventType = "ENCLAVE_CREATED",
            severity = ThreatSeverity.INFO,
            sourceProcess = Thread.currentThread().name,
            details = "Security Enclave successfully initialized with name: $enclaveName"
        )

        return enclave.enclaveId
    }

    fun encryptFileToVault(
        enclaveId: String,
        inputFile: File,
        secretPassphrase: String,
        deleteOriginal: Boolean = false
    ): File {
        val enclave = activeEnclaves[enclaveId] ?: throw IllegalArgumentException("Enclave not found: $enclaveId")
        if (enclave.state == EnclaveState.QUARANTINED || enclave.state == EnclaveState.COMPROMISED) {
            throw IllegalStateException("Cannot access quarantined or compromised enclave.")
        }

        validatePassphrase(enclave, secretPassphrase)

        val encryptedFile = File(vaultStorageDirectory, "ENC_${inputFile.name}.qsv")
        val derivedKey = deriveQuantumResistantKey(secretPassphrase, enclave.salt)

        val iv = ByteArray(vaultConfig.ivSizeBytes)
        secureRandom.nextBytes(iv)

        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val spec = GCMParameterSpec(vaultConfig.gcmTagLengthBits, iv)
        cipher.init(Cipher.ENCRYPT_MODE, derivedKey, spec)

        FileOutputStream(encryptedFile).use { fos ->
            fos.write(iv) // Write IV at the beginning of the file
            CipherOutputStream(fos, cipher).use { cos ->
                FileInputStream(inputFile).use { fis ->
                    val buffer = ByteArray(64 * 1024)
                    var bytesRead: Int
                    while (fis.read(buffer).also { bytesRead = it } != -1) {
                        cos.write(buffer, 0, bytesRead)
                    }
                }
            }
        }

        enclave.associatedFiles.add(encryptedFile)
        enclave.lastAccessedTimestamp = System.currentTimeMillis()

        if (deleteOriginal) {
            shredAndDeleteFile(inputFile)
        }

        logAudit(
            enclaveId = enclave.enclaveId,
            eventType = "FILE_ENCRYPTED",
            severity = ThreatSeverity.INFO,
            sourceProcess = Thread.currentThread().name,
            details = "File ${inputFile.name} encrypted to ${encryptedFile.name}"
        )

        return encryptedFile
    }

    fun decryptFileFromVault(
        enclaveId: String,
        encryptedFile: File,
        destinationFile: File,
        secretPassphrase: String
    ): Boolean {
        val enclave = activeEnclaves[enclaveId] ?: throw IllegalArgumentException("Enclave not found: $enclaveId")
        if (enclave.state == EnclaveState.QUARANTINED) {
            throw IllegalStateException("Access denied to Quarantined Enclave.")
        }

        validatePassphrase(enclave, secretPassphrase)

        val derivedKey = deriveQuantumResistantKey(secretPassphrase, enclave.salt)

        FileInputStream(encryptedFile).use { fis ->
            val iv = ByteArray(vaultConfig.ivSizeBytes)
            val ivRead = fis.read(iv)
            if (ivRead != vaultConfig.ivSizeBytes) {
                throw IllegalStateException("Invalid encrypted file header.")
            }

            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            val spec = GCMParameterSpec(vaultConfig.gcmTagLengthBits, iv)
            cipher.init(Cipher.DECRYPT_MODE, derivedKey, spec)

            CipherInputStream(fis, cipher).use { cis ->
                FileOutputStream(destinationFile).use { fos ->
                    val buffer = ByteArray(64 * 1024)
                    var bytesRead: Int
                    while (cis.read(buffer).also { bytesRead = it } != -1) {
                        fos.write(buffer, 0, bytesRead)
                    }
                }
            }
        }

        enclave.lastAccessedTimestamp = System.currentTimeMillis()
        logAudit(
            enclaveId = enclave.enclaveId,
            eventType = "FILE_DECRYPTED",
            severity = ThreatSeverity.INFO,
            sourceProcess = Thread.currentThread().name,
            details = "File ${encryptedFile.name} decrypted successfully."
        )

        return true
    }

    private fun shredAndDeleteFile(file: File) {
        if (!file.exists()) return
        val length = file.length()
        RandomAccessFile(file, "rws").use { raf ->
            val fillBuffer = ByteArray(64 * 1024)
            var written = 0L
            while (written < length) {
                secureRandom.nextBytes(fillBuffer)
                val toWrite = if (length - written < fillBuffer.size) (length - written).toInt() else fillBuffer.size
                raf.write(fillBuffer, 0, toWrite)
                written += toWrite
            }
        }
        file.delete()
    }

    private fun validatePassphrase(enclave: SecurityEnclave, passphrase: String) {
        val derivedKey = deriveQuantumResistantKey(passphrase, enclave.salt)
        val computedHash = computeSha384Hash(derivedKey.encoded)

        if (computedHash != enclave.masterKeyHashSha384) {
            val remainingTrust = enclave.trustScore.addAndGet(-25)
            logAudit(
                enclaveId = enclave.enclaveId,
                eventType = "AUTH_FAILURE",
                severity = ThreatSeverity.HIGH,
                sourceProcess = Thread.currentThread().name,
                details = "Passphrase validation failed. Remaining enclave trust score: $remainingTrust"
            )

            if (remainingTrust <= 0) {
                changeEnclaveState(enclave, EnclaveState.QUARANTINED)
                notifyThreat(ThreatSeverity.CRITICAL, "Enclave ${enclave.enclaveName} quarantined due to excessive failed attempts!")
            }
            throw SecurityException("Invalid passphrase provided.")
        }
    }

    private fun deriveQuantumResistantKey(passphrase: String, salt: ByteArray): SecretKey {
        val sha256 = MessageDigest.getInstance("SHA-256")
        var currentHash = sha256.digest((passphrase + bytesToHex(salt)).toByteArray(Charsets.UTF_8))

        // Simulating Multi-Round Key Stretching Pipeline
        for (i in 0 until vaultConfig.pbkdf2Iterations / 10) {
            sha256.update(currentHash)
            sha256.update(salt)
            currentHash = sha256.digest()
        }

        return SecretKeySpec(currentHash, "AES")
    }

    private fun computeSha384Hash(data: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-384")
        return bytesToHex(digest.digest(data))
    }

    private fun bytesToHex(bytes: ByteArray): String {
        val sb = StringBuilder()
        for (b in bytes) {
            sb.append(String.format("%02x", b))
        }
        return sb.toString()
    }

    private fun changeEnclaveState(enclave: SecurityEnclave, newState: EnclaveState) {
        val oldState = enclave.state
        enclave.state = newState
        listeners.forEach { listener ->
            listener.onEnclaveStateChanged(enclave, oldState, newState)
        }
    }

    private fun notifyThreat(severity: ThreatSeverity, message: String) {
        listeners.forEach { listener ->
            listener.onThreatDetected(severity, message)
        }
    }

    private fun logAudit(
        enclaveId: String?,
        eventType: String,
        severity: ThreatSeverity,
        sourceProcess: String,
        details: String
    ) {
        val recordUnsigned = "$enclaveId|$eventType|$severity|$sourceProcess|$details|${System.currentTimeMillis()}"
        val checksum = computeSha384Hash(recordUnsigned.toByteArray(Charsets.UTF_8))

        val record = ForensicsAuditRecord(
            enclaveId = enclaveId,
            eventType = eventType,
            severity = severity,
            sourceAddressOrProcess = sourceProcess,
            details = details,
            checksumSha256 = checksum
        )

        auditLogs.add(record)
        listeners.forEach { listener ->
            listener.onSecurityEventRecorded(record)
        }
    }

    private fun startForensicIntegrityScanner() {
        backgroundScanner.scheduleAtFixedRate({
            if (!isVaultActive.get()) return@scheduleAtFixedRate

            for (enclave in activeEnclaves.values) {
                if (enclave.state == EnclaveState.QUARANTINED) continue

                for (file in enclave.associatedFiles) {
                    if (!file.exists()) {
                        logAudit(
                            enclaveId = enclave.enclaveId,
                            eventType = "FILE_MISSING_ALERT",
                            severity = ThreatSeverity.MEDIUM,
                            sourceProcess = "ForensicIntegrityScanner",
                            details = "Associated file missing: ${file.absolutePath}"
                        )
                    }
                }
            }
        }, 1, 5, TimeUnit.MINUTES)
    }

    fun shutdown() {
        isVaultActive.set(false)
        executor.shutdown()
        backgroundScanner.shutdown()
    }

    companion object {
        @Volatile
        private var INSTANCE: QuantumSafeCyberVault? = null

        fun getInstance(storageDirectory: File, config: VaultConfiguration = VaultConfiguration()): QuantumSafeCyberVault {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: QuantumSafeCyberVault(storageDirectory, config).also { INSTANCE = it }
            }
        }
    }
}
