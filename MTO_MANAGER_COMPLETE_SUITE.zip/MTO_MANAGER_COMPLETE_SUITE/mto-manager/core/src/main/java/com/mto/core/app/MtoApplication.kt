package com.mto.core.app

import android.app.Application
import android.content.Context
import android.content.res.Configuration
import android.os.Process
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

class MtoApplication : Application() {

    enum class AppEnvironment {
        DEVELOPMENT,
        STAGING,
        PRODUCTION
    }

    data class ApplicationMetrics(
        val processId: Int,
        val startTimeMs: Long,
        val environment: AppEnvironment,
        val isDebuggable: Boolean
    )

    private val isInitialized = AtomicBoolean(false)
    private val globalStateRegistry = ConcurrentHashMap<String, Any>()
    private var appStartTime: Long = 0

    override fun onCreate() {
        super.onCreate()
        appStartTime = System.currentTimeMillis()
        initializeCoreSubsystems()
    }

    private fun initializeCoreSubsystems() {
        if (isInitialized.getAndSet(true)) return

        setupUncaughtExceptionHandlers()
        createRequiredDirectoryStructures()
        registerComponentCallbacks()
    }

    private fun setupUncaughtExceptionHandlers() {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            logFatalError(thread, throwable)
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }

    private fun createRequiredDirectoryStructures() {
        val dirs = listOf(
            File(filesDir, "scripts"),
            File(filesDir, "logs"),
            File(filesDir, "cache/modules"),
            File(filesDir, "backups")
        )
        for (dir in dirs) {
            if (!dir.exists()) {
                dir.mkdirs()
            }
        }
    }

    private fun registerComponentCallbacks() {
        registerComponentCallbacks(object : android.content.ComponentCallbacks2 {
            override fun onTrimMemory(level: Int) {
                if (level >= TRIM_MEMORY_MODERATE) {
                    globalStateRegistry.clear()
                    System.gc()
                }
            }

            override fun onConfigurationChanged(newConfig: Configuration) {}

            override fun onLowMemory() {
                globalStateRegistry.clear()
                System.gc()
            }
        })
    }

    private fun logFatalError(thread: Thread, throwable: Throwable) {
        try {
            val logFile = File(filesDir, "logs/crash_log.txt")
            val crashReport = "Time: ${System.currentTimeMillis()}\nThread: ${thread.name}\nException: ${throwable.stackTraceToString()}\n\n"
            logFile.appendText(crashReport)
        } catch (e: Exception) {
            // Memory or I/O failure fallback
        }
    }

    fun getAppMetrics(): ApplicationMetrics {
        return ApplicationMetrics(
            processId = Process.myPid(),
            startTimeMs = appStartTime,
            environment = AppEnvironment.PRODUCTION,
            isDebuggable = (applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0
        )
    }

    fun registerGlobalService(key: String, instance: Any) {
        globalStateRegistry[key] = instance
    }

    fun <T> getGlobalService(key: String): T? {
        @Suppress("UNCHECKED_CAST")
        return globalStateRegistry[key] as? T
    }

    companion object {
        private var instance: MtoApplication? = null

        fun getInstance(): MtoApplication {
            return instance ?: throw IllegalStateException("MtoApplication is not initialized yet.")
        }
    }
}
