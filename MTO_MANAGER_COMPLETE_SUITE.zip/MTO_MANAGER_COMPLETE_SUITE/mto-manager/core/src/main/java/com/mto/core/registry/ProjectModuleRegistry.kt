package com.mto.core.registry

import java.util.concurrent.ConcurrentHashMap

class ProjectModuleRegistry {

    enum class ModuleState {
        UNLOADED,
        LOADING,
        READY,
        ERROR,
        STOPPED
    }

    data class ModuleDescriptor(
        val moduleId: String,
        val moduleName: String,
        val version: String,
        var state: ModuleState,
        val dependencies: List<String>
    )

    private val registryMap = ConcurrentHashMap<String, ModuleDescriptor>()

    init {
        registerDefaultModules()
    }

    private fun registerDefaultModules() {
        registerModule(
            ModuleDescriptor(
                moduleId = "mod_terminal",
                moduleName = "Terminal Execution Core",
                version = "1.0.0",
                state = ModuleState.READY,
                dependencies = emptyList()
            )
        )
        registerModule(
            ModuleDescriptor(
                moduleId = "mod_network",
                moduleName = "Network & Packet Analyzer",
                version = "1.0.0",
                state = ModuleState.READY,
                dependencies = listOf("mod_terminal")
            )
        )
        registerModule(
            ModuleDescriptor(
                moduleId = "mod_automation",
                moduleName = "Shell Automation Scheduler",
                version = "1.0.0",
                state = ModuleState.READY,
                dependencies = listOf("mod_terminal")
            )
        )
        registerModule(
            ModuleDescriptor(
                moduleId = "mod_build",
                moduleName = "Production Build Orchestrator",
                version = "1.0.0",
                state = ModuleState.READY,
                dependencies = listOf("mod_terminal", "mod_automation")
            )
        )
    }

    fun registerModule(descriptor: ModuleDescriptor) {
        registryMap[descriptor.moduleId] = descriptor
    }

    fun updateModuleState(moduleId: String, newState: ModuleState) {
        registryMap[moduleId]?.let {
            it.state = newState
        }
    }

    fun getModule(moduleId: String): ModuleDescriptor? {
        return registryMap[moduleId]
    }

    fun getAllModules(): List<ModuleDescriptor> {
        return registryMap.values.toList().sortedBy { it.moduleId }
    }
}
