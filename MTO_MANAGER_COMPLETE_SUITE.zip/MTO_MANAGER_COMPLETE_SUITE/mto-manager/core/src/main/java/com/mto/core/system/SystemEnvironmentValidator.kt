package com.mto.core.system

import android.os.Build
import java.io.BufferedReader
import java.io.File
import java.io.FileReader

class SystemEnvironmentValidator {

    data class EnvironmentReport(
        val androidVersion: String,
        val apiLevel: Int,
        val cpuArchitecture: String,
        val availableCores: Int,
        val isRootAvailable: Boolean,
        val isTermuxEnvironmentDetected: Boolean,
        val selinuxMode: String
    )

    fun performEnvironmentValidation(): EnvironmentReport {
        return EnvironmentReport(
            androidVersion = Build.VERSION.RELEASE ?: "Unknown",
            apiLevel = Build.VERSION.SDK_INT,
            cpuArchitecture = Build.SUPPORTED_ABIS.firstOrNull() ?: "Unknown",
            availableCores = Runtime.getRuntime().availableProcessors(),
            isRootAvailable = checkRootSuBinary(),
            isTermuxEnvironmentDetected = checkTermuxDirectory(),
            selinuxMode = getSELinuxStatus()
        )
    }

    private fun checkRootSuBinary(): Boolean {
        val paths = arrayOf(
            "/system/app/Superuser.apk",
            "/sbin/su",
            "/system/bin/su",
            "/system/xbin/su",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/system/sd/xbin/su",
            "/system/bin/failsafe/su",
            "/data/local/su"
        )
        for (path in paths) {
            if (File(path).exists()) return true
        }
        return false
    }

    private fun checkTermuxDirectory(): Boolean {
        val termuxDataDir = File("/data/data/com.termux/files/usr")
        return termuxDataDir.exists()
    }

    private fun getSELinuxStatus(): String {
        return try {
            val process = Runtime.getRuntime().exec("getenv SELINUX_USE_TRANSPARENT_PROXY")
            val reader = BufferedReader(java.io.InputStreamReader(process.inputStream))
            val line = reader.readLine() ?: "Enforcing (Default)"
            process.waitFor()
            line
        } catch (e: Exception) {
            "Enforcing"
        }
    }
}
